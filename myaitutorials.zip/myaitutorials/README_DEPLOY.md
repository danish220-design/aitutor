# Deployment to Hostinger via GitHub Actions

This project is configured to automatically deploy to Hostinger whenever you push to the `main` branch.

## Setup Instructions

1. **GitHub Secrets:**
   Go to your GitHub repository settings -> **Secrets and variables** -> **Actions** and add the following secrets:
   - `FTP_SERVER`: Your Hostinger FTP hostname (e.g., `ftp.yourdomain.com`).
   - `FTP_USERNAME`: Your FTP username.
   - `FTP_PASSWORD`: Your FTP password.
   - `VITE_GEMINI_API_KEY`: Your Gemini API Key (if required on the client side).

2. **Hostinger Configuration:**
   - Ensure your domain's document root is set to `public_html`.
   - The `.htaccess` file in the `public` folder will handle routing for the React SPA.

3. **Trigger Deployment:**
   - Simply push your code to the `main` branch, and GitHub Actions will handle the build and upload process.
