/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GraduationCap, Languages, BookOpen, ArrowRight, Sparkles, CheckCircle2, Moon, Sun, Zap, Clock, MessageSquare, Users, Rocket, TrendingDown, X } from 'lucide-react';
import { TutorInterface } from './components/TutorInterface';
import { LandingPage } from './components/LandingPage';
import { SetupView } from './components/SetupView';
import { SubscriptionModal } from './components/SubscriptionModal';
import { Language, ClassLevel, AppState } from './types';
import { syllabus as fallbackSyllabus } from './data/syllabus.js';
import { syllabusService } from './services/syllabusService';
import { sheetsService, User as SheetsUser } from './services/sheetsService';
import { auth, db } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDocFromServer } from 'firebase/firestore';

import { AdminDashboardStats } from './components/AdminDashboardStats';
import { AdminAuth } from './components/AdminAuth';
import { AdminSyllabusManager } from './components/AdminSyllabusManager';
import { AdminSettings } from './components/AdminSettings';
import { AdminKnowledgeBase } from './components/AdminKnowledgeBase';
import { AdminSiteContent } from './components/AdminSiteContent';
import { AdminContactMessages } from './components/AdminContactMessages';
import { AdminUserManagement } from './components/AdminUserManagement';

export default function App() {
  const [user, setUser] = useState<SheetsUser | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [syllabus, setSyllabus] = useState<any>(fallbackSyllabus);

  useEffect(() => {
    const loadSyllabus = async () => {
      try {
        const entries = await syllabusService.getSyllabus();
        if (entries.length > 0) {
          setSyllabus(syllabusService.convertEntriesToMap(entries));
        }
      } catch (error) {
        console.error('Error loading syllabus from Firestore:', error);
      }
    };
    loadSyllabus();
  }, []);
  const [adminTab, setAdminTab] = useState<'stats' | 'settings' | 'kb' | 'site' | 'messages' | 'syllabus' | 'users'>('stats');

  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();

    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        const currentUser = sheetsService.getCurrentUser();
        const currentAdmin = sheetsService.getCurrentAdmin();
        
        if (currentUser && currentUser.uid === firebaseUser.uid) {
          setUser(currentUser);
        } else if (currentAdmin && currentAdmin.uid === firebaseUser.uid) {
          setIsAdminAuthenticated(true);
        } else {
          // If local storage is out of sync, we might need to fetch profile
          // For now, we'll trust the login/signup flow to set local storage
        }
      } else {
        setUser(null);
        setIsAdminAuthenticated(false);
        localStorage.removeItem("user");
        localStorage.removeItem("admin");
      }
      setIsAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  const [state, setState] = useState<AppState>({
    language: 'English',
    classLevel: '10',
    subject: 'English',
    isStarted: false,
    view: 'landing',
  });

  const [showAdmin, setShowAdmin] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme) return savedTheme === 'dark';
      return true; // Default to dark mode
    }
    return true;
  });

  const [freeQuestionsLeft, setFreeQuestionsLeft] = useState(9999);

  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  useEffect(() => {
    localStorage.setItem('tutor_free_questions_left', '9999');
  }, [freeQuestionsLeft]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  const [searchQuery, setSearchQuery] = useState('');

  const handleStart = (cls?: ClassLevel) => {
    if (cls) {
      const hasNewStreams = cls === '11' || cls === '12';
      if (hasNewStreams) {
        const firstStream = Object.keys(syllabus[cls])[0];
        const firstSubject = Object.keys(syllabus[cls][firstStream])[0];
        setState(prev => ({ ...prev, classLevel: cls, stream: firstStream, subject: firstSubject, chapterId: undefined, topicId: undefined, view: 'tutor', isStarted: true }));
      } else {
        const newSubjects = Object.keys(syllabus[cls]);
        const newSubject = newSubjects[0];
        setState(prev => ({ ...prev, classLevel: cls, stream: undefined, subject: newSubject, chapterId: undefined, topicId: undefined, view: 'tutor', isStarted: true }));
      }
    } else {
      setState(prev => ({ ...prev, view: 'setup' }));
    }
  };

  const handleSetupComplete = () => {
    setState(prev => ({ ...prev, view: 'tutor', isStarted: true }));
  };

  const handleBack = () => {
    if (state.view === 'tutor') {
      setState(prev => ({ ...prev, view: 'setup', isStarted: false }));
    } else {
      setState(prev => ({ ...prev, view: 'landing', isStarted: false }));
    }
  };

  const [completedTopicIds, setCompletedTopicIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchCompletedTopics = async () => {
      if (user) {
        try {
          const sessions = await sheetsService.getSessions(user.uid);
          const ids = sessions.map((s: any) => s.topicId).filter(Boolean);
          setCompletedTopicIds(new Set(ids));
        } catch (error) {
          console.error("Error fetching completed topics from Google Sheets", error);
        }
      } else {
        try {
          const index = JSON.parse(localStorage.getItem('tutor_history_index') || '[]');
          const ids = index.map((key: string) => {
            const data = localStorage.getItem(`tutor_session_${key}`);
            return data ? JSON.parse(data).metadata?.topicId : null;
          }).filter(Boolean);
          setCompletedTopicIds(new Set(ids as string[]));
        } catch (e) {
          setCompletedTopicIds(new Set<string>());
        }
      }
    };
    fetchCompletedTopics();
  }, [user, state.view]);

  const hasStreams = state.classLevel === '11' || state.classLevel === '12';
  const selectedClassSyllabus = (state.classLevel && syllabus[state.classLevel])
    ? (hasStreams
        ? (state.stream && state.subject && syllabus[state.classLevel][state.stream] ? syllabus[state.classLevel][state.stream][state.subject] || [] : [])
        : (state.subject ? syllabus[state.classLevel][state.subject] || [] : []))
    : [];

  const selectedChapter = Array.isArray(selectedClassSyllabus) ? selectedClassSyllabus.find(ch => ch.id === state.chapterId) : undefined;
  const selectedTopic = selectedChapter?.topics.find(t => t.id === state.topicId);

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#020617] text-slate-800 dark:text-slate-100 selection:bg-blue-100 font-sans transition-colors duration-300">
      <div className="fixed bottom-6 right-6 z-[150]">
        <button
          onClick={() => setIsDarkMode(!isDarkMode)}
          className="p-4 rounded-2xl bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-cyan-500 dark:hover:text-cyan-400 transition-all shadow-2xl radium-btn"
          aria-label="Toggle theme"
        >
          {isDarkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
        </button>
      </div>

      <AnimatePresence mode="wait">
        {state.view === 'landing' && (
          <motion.div key="landing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <LandingPage 
              onStart={handleStart} 
              onAdminClick={() => setShowAdmin(true)} 
              syllabus={syllabus}
            />
          </motion.div>
        )}

        {state.view === 'setup' && (
          <SetupView 
            state={state}
            setState={setState}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onStart={handleSetupComplete}
            onBack={handleBack}
            completedTopicIds={completedTopicIds}
            freeQuestionsLeft={freeQuestionsLeft}
            setShowSubscriptionModal={setShowSubscriptionModal}
            user={user}
            syllabus={syllabus}
          />
        )}

        {state.view === 'tutor' && (
          <motion.div
            key="tutor"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-screen"
          >
            <TutorInterface
              language={state.language}
              classLevel={state.classLevel}
              stream={state.stream}
              subject={state.subject || 'English'}
              chapterName={selectedChapter?.name}
              topicName={selectedTopic?.name}
              onBack={handleBack}
              freeQuestionsLeft={freeQuestionsLeft}
              setFreeQuestionsLeft={setFreeQuestionsLeft}
              setShowSubscriptionModal={setShowSubscriptionModal}
              user={user}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showSubscriptionModal && (
          <SubscriptionModal 
            classLevel={state.classLevel} 
            onClose={() => setShowSubscriptionModal(false)} 
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAdmin && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-[95vw] lg:max-w-7xl bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-[90vh]"
            >
              <div className="p-6 md:p-8 border-b border-slate-100 dark:border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-slate-50/50 dark:bg-slate-800/50">
                <div className="flex items-center justify-between w-full md:w-auto">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-cyan-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                      <Rocket className="w-5 h-5 md:w-6 md:h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white">Admin Control Center</h2>
                      <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400">Manage API Keys • Knowledge Base • Analytics</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
                  <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl md:mr-4 min-w-max">
                    <button
                      onClick={() => setAdminTab('stats')}
                      className={`px-3 md:px-4 py-2 rounded-xl text-xs font-bold transition-all ${adminTab === 'stats' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                      Analytics
                    </button>
                    <button
                      onClick={() => setAdminTab('kb')}
                      className={`px-3 md:px-4 py-2 rounded-xl text-xs font-bold transition-all ${adminTab === 'kb' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                      Knowledge Base
                    </button>
                    <button
                      onClick={() => setAdminTab('site')}
                      className={`px-3 md:px-4 py-2 rounded-xl text-xs font-bold transition-all ${adminTab === 'site' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                      Site Content
                    </button>
                    <button
                      onClick={() => setAdminTab('messages')}
                      className={`px-3 md:px-4 py-2 rounded-xl text-xs font-bold transition-all ${adminTab === 'messages' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                      Messages
                    </button>
                    <button
                      onClick={() => setAdminTab('syllabus')}
                      className={`px-3 md:px-4 py-2 rounded-xl text-xs font-bold transition-all ${adminTab === 'syllabus' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                      Syllabus
                    </button>
                    <button
                      onClick={() => setAdminTab('users')}
                      className={`px-3 md:px-4 py-2 rounded-xl text-xs font-bold transition-all ${adminTab === 'users' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                      Users
                    </button>
                    <button
                      onClick={() => setAdminTab('settings')}
                      className={`px-3 md:px-4 py-2 rounded-xl text-xs font-bold transition-all ${adminTab === 'settings' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                      Settings
                    </button>
                  </div>
                  <button
                    onClick={() => setShowAdmin(false)}
                    className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors ml-2"
                    title="Close Admin Panel"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 md:space-y-12 scrollbar-hide">
                {!isAdminAuthenticated ? (
                  <AdminAuth onSuccess={() => setIsAdminAuthenticated(true)} />
                ) : (
                  <>
                    {adminTab === 'stats' && (
                      <>
                        <AdminDashboardStats user={user || sheetsService.getCurrentAdmin()} />
                        
                        <div className="grid md:grid-cols-3 gap-6">
                          {[
                            { title: "Avg. API Cost", value: "₹4 - ₹10", sub: "per student / month", icon: Zap, color: "text-purple-500" },
                            { title: "Target Revenue", value: "₹199 - ₹1099", sub: "per student / month", icon: TrendingDown, color: "text-emerald-500" },
                            { title: "Profit Margin", value: "~95%", sub: "Scalable digital asset", icon: Sparkles, color: "text-cyan-500" },
                          ].map((stat, i) => (
                            <div key={i} className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
                              <stat.icon className={`w-6 h-6 mb-4 ${stat.color}`} />
                              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.title}</p>
                              <div className="text-2xl font-bold text-slate-900 dark:text-white">{stat.value}</div>
                              <p className="text-[10px] text-slate-500 mt-1">{stat.sub}</p>
                            </div>
                          ))}
                        </div>

                        <div className="grid lg:grid-cols-2 gap-8">
                          <div className="space-y-6">
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                              <TrendingDown className="w-5 h-5 text-cyan-500" />
                              Gemini Flash Cost Breakdown
                            </h3>
                            <div className="space-y-3">
                              <div className="flex justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/30 border border-slate-100 dark:border-slate-800">
                                <span className="text-sm text-slate-600 dark:text-slate-400">API Rate</span>
                                <span className="text-sm font-bold text-slate-900 dark:text-white">~$0.075 / 1M Tokens</span>
                              </div>
                              <div className="flex justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/30 border border-slate-100 dark:border-slate-800">
                                <span className="text-sm text-slate-600 dark:text-slate-400">Free Tier Limit</span>
                                <span className="text-sm font-bold text-slate-900 dark:text-white">15 RPM (Free)</span>
                              </div>
                              <div className="p-4 rounded-2xl bg-cyan-600 text-white">
                                <p className="text-[10px] uppercase font-bold opacity-70 mb-1">Estimated Monthly Budget</p>
                                <div className="text-2xl font-bold">₹0 - ₹150 / student</div>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-6">
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                              <Sparkles className="w-5 h-5 text-purple-500" />
                              Business Strategy
                            </h3>
                            <div className="space-y-4">
                              {[
                                { title: "Premium Tier", desc: "Charge ₹50 extra for Mock Test Generation and Performance Tracking." },
                                { title: "School Partnerships", desc: "Bulk licenses for coaching centers in rural West Bengal." },
                                { title: "Low Overhead", desc: "No physical building or staff needed. 24/7 automated tutoring." }
                              ].map((item, i) => (
                                <div key={i} className="flex gap-4">
                                  <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-900/20 flex items-center justify-center shrink-0">
                                    <div className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                                  </div>
                                  <div>
                                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">{item.title}</h4>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">{item.desc}</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="p-8 rounded-[2rem] bg-slate-900 text-white relative overflow-hidden">
                          <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 blur-[120px] rounded-full" />
                          <div className="relative z-10">
                            <h3 className="text-xl font-bold mb-4 flex items-center gap-3">
                              <Rocket className="w-6 h-6 text-cyan-400" />
                              Infrastructure Requirements
                            </h3>
                            <div className="grid sm:grid-cols-3 gap-6">
                              {[
                                { label: "AI Engine", val: "Gemini 1.5 Flash" },
                                { label: "Frontend", val: "React + Tailwind" },
                                { label: "Hosting", val: "Vercel / Netlify" }
                              ].map((req, i) => (
                                <div key={i} className="p-4 rounded-2xl bg-white/5 border border-white/10">
                                  <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">{req.label}</p>
                                  <p className="text-sm font-medium">{req.val}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {adminTab === 'settings' && <AdminSettings />}
                    {adminTab === 'kb' && <AdminKnowledgeBase />}
                    {adminTab === 'site' && <AdminSiteContent />}
                    {adminTab === 'messages' && <AdminContactMessages />}
                    {adminTab === 'syllabus' && <AdminSyllabusManager />}
                    {adminTab === 'users' && <AdminUserManagement />}
                  </>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
