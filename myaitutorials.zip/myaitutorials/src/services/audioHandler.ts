/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export class AudioHandler {
  private audioContext: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private gainNode: GainNode | null = null;
  private nextStartTime: number = 0;
  private volume: number = 1.0;
  private isMuted: boolean = false;
  private isMicMuted: boolean = false;
  private activeSources: Set<AudioBufferSourceNode> = new Set();

  constructor(
    private onAudioData: (base64Data: string) => void,
    private onPlaybackChange?: (isPlaying: boolean) => void
  ) {}

  async start(sampleRate: number = 16000) {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Media devices API not supported in this browser or environment.");
      }
      this.audioContext = new AudioContext({ sampleRate });
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.source = this.audioContext.createMediaStreamSource(this.stream);
      
      this.gainNode = this.audioContext.createGain();
      this.gainNode.gain.value = this.isMuted ? 0 : this.volume;
      this.gainNode.connect(this.audioContext.destination);

      // Using ScriptProcessorNode for simplicity in this environment
      // In a real app, AudioWorklet is preferred
      this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);
      
      this.source.connect(this.processor);
      this.processor.connect(this.audioContext.destination);

      this.processor.onaudioprocess = (e) => {
        if (this.isMicMuted) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcmData = this.floatTo16BitPCM(inputData);
        const base64Data = btoa(String.fromCharCode(...new Uint8Array(pcmData.buffer)));
        this.onAudioData(base64Data);
      };
      
      this.nextStartTime = this.audioContext.currentTime;
    } catch (error) {
      console.error("AudioHandler: Failed to start audio.", error);
      if (error instanceof Error && error.name === 'NotFoundError') {
        console.warn("AudioHandler: No microphone found.");
      }
      this.stop();
      throw error;
    }
  }

  stop() {
    this.processor?.disconnect();
    this.source?.disconnect();
    this.gainNode?.disconnect();
    this.stream?.getTracks().forEach(track => track.stop());
    this.stream = null;
    
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(err => console.error("AudioHandler: Error closing context", err));
    }
    this.audioContext = null;
    this.gainNode = null;
  }

  setVolume(value: number) {
    this.volume = value;
    if (this.gainNode && !this.isMuted) {
      this.gainNode.gain.value = value;
    }
  }

  setMute(muted: boolean) {
    this.isMuted = muted;
    if (this.gainNode) {
      this.gainNode.gain.value = muted ? 0 : this.volume;
    }
  }

  setMicMute(muted: boolean) {
    this.isMicMuted = muted;
  }

  playChunk(base64Data: string) {
    if (!this.audioContext || !this.gainNode) return;
    
    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    const pcmData = new Int16Array(bytes.buffer);
    const floatData = new Float32Array(pcmData.length);
    for (let i = 0; i < pcmData.length; i++) {
      floatData[i] = pcmData[i] / 32768.0;
    }

    const buffer = this.audioContext.createBuffer(1, floatData.length, 24000);
    buffer.getChannelData(0).set(floatData);

    const source = this.audioContext.createBufferSource();
    source.buffer = buffer;
    source.connect(this.gainNode);
    
    const startTime = Math.max(this.nextStartTime, this.audioContext.currentTime);
    source.start(startTime);
    this.nextStartTime = startTime + buffer.duration;

    this.activeSources.add(source);
    if (this.activeSources.size === 1) {
      this.onPlaybackChange?.(true);
    }

    source.onended = () => {
      this.activeSources.delete(source);
      if (this.activeSources.size === 0) {
        this.onPlaybackChange?.(false);
      }
    };
  }

  private floatTo16BitPCM(input: Float32Array): Int16Array {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    return output;
  }
}
