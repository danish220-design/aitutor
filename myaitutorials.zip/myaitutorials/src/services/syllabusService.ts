import { 
  collection, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  Timestamp,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../firebase';
import { syllabus as hardcodedSyllabus } from '../data/syllabus.js';

export interface Topic {
  id: string;
  name: string;
}

export interface Chapter {
  id: string;
  name: string;
  topics: Topic[];
}

export interface SyllabusEntry {
  id?: string;
  classLevel: string;
  stream?: string;
  subject: string;
  chapters: Chapter[];
  updatedAt: any;
}

const COLLECTION_NAME = 'syllabus';

export const syllabusService = {
  async getSyllabus(): Promise<SyllabusEntry[]> {
    const q = query(collection(db, COLLECTION_NAME));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as SyllabusEntry[];
  },

  async saveSyllabusEntry(entry: Omit<SyllabusEntry, 'id' | 'updatedAt'>) {
    const data = {
      ...entry,
      updatedAt: serverTimestamp()
    };
    
    // Check if entry already exists (same class, stream, subject)
    const q = query(
      collection(db, COLLECTION_NAME),
      where('classLevel', '==', entry.classLevel),
      where('subject', '==', entry.subject),
      where('stream', '==', entry.stream || null)
    );
    
    const existing = await getDocs(q);
    if (!existing.empty) {
      const docId = existing.docs[0].id;
      await updateDoc(doc(db, COLLECTION_NAME, docId), data);
      return docId;
    } else {
      const docRef = await addDoc(collection(db, COLLECTION_NAME), data);
      return docRef.id;
    }
  },

  async deleteSyllabusEntry(id: string) {
    await deleteDoc(doc(db, COLLECTION_NAME, id));
  },

  async migrateSyllabus() {
    const existing = await this.getSyllabus();
    if (existing.length > 0) {
      console.log('Syllabus already migrated.');
      return;
    }

    console.log('Starting syllabus migration...');
    const entries: Omit<SyllabusEntry, 'id' | 'updatedAt'>[] = [];

    for (const [classLevel, classData] of Object.entries(hardcodedSyllabus)) {
      if (classLevel === '11' || classLevel === '12') {
        // Handle streams
        for (const [stream, subjects] of Object.entries(classData)) {
          for (const [subject, chapters] of Object.entries(subjects)) {
            entries.push({
              classLevel,
              stream,
              subject,
              chapters: chapters as Chapter[]
            });
          }
        }
      } else {
        // Handle direct subjects
        for (const [subject, chapters] of Object.entries(classData)) {
          entries.push({
            classLevel,
            subject,
            chapters: chapters as Chapter[]
          });
        }
      }
    }

    for (const entry of entries) {
      await this.saveSyllabusEntry(entry);
    }
    console.log('Syllabus migration complete.');
  },

  convertEntriesToMap(entries: SyllabusEntry[]) {
    const map: any = {};
    entries.forEach(entry => {
      if (!map[entry.classLevel]) map[entry.classLevel] = {};
      if (entry.stream) {
        if (!map[entry.classLevel][entry.stream]) map[entry.classLevel][entry.stream] = {};
        map[entry.classLevel][entry.stream][entry.subject] = entry.chapters;
      } else {
        map[entry.classLevel][entry.subject] = entry.chapters;
      }
    });
    return map;
  }
};
