import { Language, ClassLevel } from "../types";
import { auth, db } from "../firebase";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  User as FirebaseUser
} from "firebase/auth";
import { 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  collection, 
  query, 
  where, 
  orderBy, 
  deleteDoc, 
  updateDoc,
  serverTimestamp,
  Timestamp,
  addDoc
} from "firebase/firestore";

export interface User {
  uid: string;
  email: string;
  classLevel: ClassLevel;
  language: Language;
  role: 'user' | 'admin';
}

export interface Admin {
  uid: string;
  email: string;
  role: string;
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const sheetsService = {
  async signup(data: { email: string; password: string; classLevel: ClassLevel; language: Language }) {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
      const firebaseUser = userCredential.user;
      
      const userData: User = {
        uid: firebaseUser.uid,
        email: data.email,
        classLevel: data.classLevel,
        language: data.language,
        role: 'user'
      };

      const userRef = doc(db, "users", firebaseUser.uid);
      await setDoc(userRef, {
        ...userData,
        createdAt: serverTimestamp()
      });

      localStorage.setItem("user", JSON.stringify(userData));
      return { token: await firebaseUser.getIdToken(), user: userData };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "users");
      throw error;
    }
  },

  async login(data: { email: string; password: string }) {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, data.email, data.password);
      const firebaseUser = userCredential.user;
      
      const userRef = doc(db, "users", firebaseUser.uid);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        const userData: User = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          role: 'user',
          classLevel: '10',
          language: 'English'
        };
        await setDoc(userRef, {
          ...userData,
          createdAt: serverTimestamp(),
          lastLoginAt: serverTimestamp()
        });
        localStorage.setItem("user", JSON.stringify(userData));
        return { token: await firebaseUser.getIdToken(), user: userData };
      }

      const userData = userSnap.data() as User;
      
      // Update last login
      await updateDoc(userRef, {
        lastLoginAt: serverTimestamp()
      });

      localStorage.setItem("user", JSON.stringify(userData));
      return { token: await firebaseUser.getIdToken(), user: userData };
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "users");
      throw error;
    }
  },

  async adminSignup(data: { email: string; password: string; role: string }) {
    if (data.email !== 'danish220@gmail.com') {
      throw new Error("Unauthorized: Only danish220@gmail.com is allowed to register as an admin.");
    }
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
      const firebaseUser = userCredential.user;
      
      const adminData: User = {
        uid: firebaseUser.uid,
        email: data.email,
        classLevel: '10', // Default for admin
        language: 'English', // Default for admin
        role: 'admin'
      };

      const userRef = doc(db, "users", firebaseUser.uid);
      await setDoc(userRef, {
        ...adminData,
        createdAt: serverTimestamp()
      });

      localStorage.setItem("admin", JSON.stringify(adminData));
      return { token: await firebaseUser.getIdToken(), admin: adminData };
    } catch (error: any) {
      if (error.code === 'auth/email-already-in-use') {
        throw new Error("This email is already registered. Please click the 'Sign in with Google' button below instead of filling out this form.");
      }
      handleFirestoreError(error, OperationType.WRITE, "users");
      throw error;
    }
  },

  async adminLogin(data: { email: string; password: string }) {
    if (data.email !== 'danish220@gmail.com') {
      throw new Error("Unauthorized: Only danish220@gmail.com is allowed to access the Admin Control Center.");
    }
    try {
      const userCredential = await signInWithEmailAndPassword(auth, data.email, data.password);
      const firebaseUser = userCredential.user;
      
      const userRef = doc(db, "users", firebaseUser.uid);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists() || userSnap.data().role !== 'admin') {
        await signOut(auth);
        throw new Error("Unauthorized: Not an admin");
      }

      const adminData = userSnap.data() as User;

      // Update last login
      await updateDoc(userRef, {
        lastLoginAt: serverTimestamp()
      });

      localStorage.setItem("admin", JSON.stringify(adminData));
      return { token: await firebaseUser.getIdToken(), admin: adminData };
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "users");
      throw error;
    }
  },

  async checkAdmin(): Promise<{ exists: boolean }> {
    try {
      const q = query(collection(db, "users"), where("role", "==", "admin"));
      const querySnapshot = await getDocs(q);
      return { exists: !querySnapshot.empty };
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "users");
      throw error;
    }
  },

  async getConfigStatus() {
    return { DATABASE_READY: true, JWT_SECRET: true };
  },

  async saveSession(data: { uid: string; classLevel: string; language: string; subject: string; chapterId: string; chapterName: string; topicId: string; topicName: string; messages: any[] }) {
    try {
      const sessionsRef = collection(db, "sessions");
      const q = query(sessionsRef, where("uid", "==", data.uid), where("topicId", "==", data.topicId));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        const sessionDoc = querySnapshot.docs[0];
        await updateDoc(sessionDoc.ref, {
          ...data,
          timestamp: Date.now()
        });
      } else {
        await addDoc(sessionsRef, {
          ...data,
          timestamp: Date.now()
        });
      }
      return { success: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "sessions");
      throw error;
    }
  },

  async getSessions(uid: string) {
    try {
      const q = query(collection(db, "sessions"), where("uid", "==", uid), orderBy("timestamp", "desc"));
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      }));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "sessions");
      throw error;
    }
  },

  async deleteSession(uid: string, topicName: string) {
    try {
      const q = query(collection(db, "sessions"), where("uid", "==", uid), where("topicName", "==", topicName));
      const querySnapshot = await getDocs(q);
      if (!querySnapshot.empty) {
        await deleteDoc(querySnapshot.docs[0].ref);
      }
      return { success: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, "sessions");
      throw error;
    }
  },

  async getAdminStats() {
    try {
      const usersSnap = await getDocs(collection(db, "users"));
      const sessionsSnap = await getDocs(collection(db, "sessions"));
      
      const now = new Date();
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const midDay = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0, 0);
      
      let loginsAM = 0;
      let loginsPM = 0;
      let liveUsers = 0;
      const fifteenMinsAgo = Date.now() - (15 * 60 * 1000);

      const allUsers = usersSnap.docs.map(doc => ({ ...doc.data(), id: doc.id })) as any[];
      
      allUsers.forEach(user => {
        if (user.lastLoginAt) {
          const loginDate = user.lastLoginAt.toDate();
          if (loginDate >= startOfDay) {
            if (loginDate < midDay) loginsAM++;
            else loginsPM++;
          }
        }
      });

      const allSessions = sessionsSnap.docs.map(doc => doc.data()) as any[];
      const activeUids = new Set();
      allSessions.forEach(session => {
        if (session.timestamp >= fifteenMinsAgo) {
          activeUids.add(session.uid);
        }
      });
      liveUsers = activeUids.size;

      const recentUsers = allUsers
        .sort((a: any, b: any) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))
        .slice(0, 5);

      return {
        totalUsers: usersSnap.size,
        totalSessions: sessionsSnap.size,
        totalMessages: 0,
        loginsAM,
        loginsPM,
        liveUsers,
        recentUsers
      };
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "admin/stats");
      throw error;
    }
  },

  async getAllUsers() {
    try {
      const querySnapshot = await getDocs(collection(db, "users"));
      return querySnapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      }));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "users");
      throw error;
    }
  },

  async deleteUser(uid: string) {
    try {
      await deleteDoc(doc(db, "users", uid));
      // Note: This only deletes the Firestore profile, not the Auth user.
      // Deleting Auth users requires Admin SDK or user re-authentication.
      return { success: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${uid}`);
      throw error;
    }
  },

  async updateUser(uid: string, data: any) {
    try {
      await updateDoc(doc(db, "users", uid), data);
      return { success: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
      throw error;
    }
  },

  async getAdminSettings() {
    try {
      const settingsSnap = await getDoc(doc(db, "settings", "admin"));
      return settingsSnap.exists() ? settingsSnap.data() : {};
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "settings/admin");
      throw error;
    }
  },

  async updateAdminSettings(settings: { gemini_api_key: string }) {
    try {
      await setDoc(doc(db, "settings", "admin"), settings, { merge: true });
      return { success: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "settings/admin");
      throw error;
    }
  },

  async getGeminiKey() {
    try {
      const settings = await this.getAdminSettings();
      // @ts-ignore
      return { apiKey: settings.gemini_api_key || process.env.GEMINI_API_KEY };
    } catch (error) {
      // @ts-ignore
      return { apiKey: process.env.GEMINI_API_KEY || null };
    }
  },

  async saveUserSettings(uid: string, settings: any) {
    try {
      const docRef = doc(db, 'users', uid);
      await updateDoc(docRef, { settings });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
    }
  },

  async getUserSettings(uid: string) {
    try {
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data().settings || {};
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `users/${uid}`);
    }
    return {};
  },

  async getKnowledgeBase(subject?: string, classLevel?: string) {
    try {
      let q = query(collection(db, "knowledge_base"), orderBy("created_at", "desc"));
      if (subject && classLevel) {
        q = query(collection(db, "knowledge_base"), 
          where("subject", "==", subject), 
          where("class_level", "==", classLevel),
          orderBy("created_at", "desc")
        );
      }
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      }));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "knowledge_base");
      throw error;
    }
  },

  async addToKnowledgeBase(data: { question: string; answer_text: string; answer_audio: string; subject: string; class_level: string }) {
    try {
      await addDoc(collection(db, "knowledge_base"), {
        ...data,
        created_at: serverTimestamp()
      });
      return { success: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "knowledge_base");
      throw error;
    }
  },

  async deleteFromKnowledgeBase(id: string) {
    try {
      await deleteDoc(doc(db, "knowledge_base", id));
      return { success: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, "knowledge_base");
      throw error;
    }
  },

  async logout() {
    await signOut(auth);
    localStorage.removeItem("user");
    localStorage.removeItem("admin");
  },

  async loginWithGoogle(isAdmin: boolean = false) {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({
        prompt: 'select_account'
      });
      const userCredential = await signInWithPopup(auth, provider);
      const firebaseUser = userCredential.user;

      const userRef = doc(db, "users", firebaseUser.uid);
      const userSnap = await getDoc(userRef);

      let userData: User;

      if (userSnap.exists()) {
        userData = userSnap.data() as User;
        if (isAdmin && firebaseUser.email !== 'danish220@gmail.com') {
          await signOut(auth);
          throw new Error("Unauthorized: Only danish220@gmail.com is allowed to access the Admin Control Center.");
        }
        // Update last login for existing user
        await updateDoc(userRef, {
          lastLoginAt: serverTimestamp()
        });
      } else {
        if (isAdmin && firebaseUser.email !== 'danish220@gmail.com') {
          await signOut(auth);
          throw new Error("Unauthorized: Only danish220@gmail.com is allowed to access the Admin Control Center.");
        }
        // Create new user profile
        userData = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || "",
          classLevel: '10',
          language: 'English',
          role: firebaseUser.email === 'danish220@gmail.com' ? 'admin' : 'user'
        };

        await setDoc(userRef, {
          ...userData,
          createdAt: serverTimestamp(),
          lastLoginAt: serverTimestamp()
        });
      }

      if (isAdmin || userData.role === 'admin') {
        localStorage.setItem("admin", JSON.stringify(userData));
      } else {
        localStorage.setItem("user", JSON.stringify(userData));
      }

      return { token: await firebaseUser.getIdToken(), user: userData };
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user') {
        throw new Error("The sign-in popup was closed before completion. Please make sure popups are allowed and don't close the window until it finishes.");
      }
      if (error.code === 'auth/operation-not-allowed') {
        throw new Error("Google Sign-In is not enabled in your Firebase project. Please enable it in the Firebase Console (Authentication > Sign-in method).");
      }
      if (error.code === 'auth/unauthorized-domain') {
        throw new Error("This domain is not authorized for Firebase Auth. Please add your App URL to the 'Authorized domains' list in the Firebase Console.");
      }
      
      // If it's not a specific auth error we know, use the general handler
      if (error.code?.startsWith('auth/')) {
        throw new Error(`Authentication Error: ${error.message}`);
      }
      
      handleFirestoreError(error, OperationType.WRITE, "users");
      throw error;
    }
  },

  getCurrentUser(): User | null {
    const user = localStorage.getItem("user");
    return user ? JSON.parse(user) : null;
  },

  getCurrentAdmin(): User | null {
    const admin = localStorage.getItem("admin");
    return admin ? JSON.parse(admin) : null;
  },

  async getSiteContent() {
    try {
      const siteSnap = await getDoc(doc(db, "settings", "site"));
      return siteSnap.exists() ? siteSnap.data() : {
        pricing: "Free for now",
        mobile_no: "+91 8777385844",
        vision: "Empowering every student with AI-driven personalized learning.",
        mission: "To provide accessible, high-quality education through innovative AI technology.",
        email: "support@myaitutorials.com",
        address: "Near Albela Hotel, Tospisa, Kolkata-700039",
        hero_background_url: "https://picsum.photos/seed/west-bengal-students/1200/800",
        about_background_url: "https://picsum.photos/seed/empower-students/1200/800",
        students_count_text: "10,000+ Students Learning Daily",
        coverage_text: "Comprehensive Coverage",
        sm_edu_content: [
          {
            platform: "YouTube",
            title: "How to prepare for WBCHSE Semester 1",
            url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            thumbnail: "https://picsum.photos/seed/youtube1/400/225"
          },
          {
            platform: "Instagram",
            title: "Quick Math Tricks for Class 10",
            url: "https://www.instagram.com/",
            thumbnail: "https://picsum.photos/seed/insta1/400/400"
          }
        ],
        faqs: [
          {
            question: "What is myaitutorials.com?",
            answer: "myaitutorials.com is an AI-powered educational platform specifically designed for West Bengal Board (WBBSE & WBCHSE) students from Class 9 to 12. It acts as a 24/7 personal tutor, explaining concepts, generating notes, and providing interactive practice."
          },
          {
            question: "Is this platform suitable for both English and Bengali medium students?",
            answer: "Yes! Our AI Tutor is multi-lingual. Students can interact and learn in English, Bengali, or even Hinglish, making it comfortable for everyone to grasp complex topics."
          },
          {
            question: "How does the AI Tutor help with exam preparation?",
            answer: "The AI Tutor provides chapter-wise notes, generates mock tests, creates flashcards for quick revision, and even offers visual aids like AI-generated videos to explain difficult concepts clearly."
          },
          {
            question: "Can parents track their child's progress?",
            answer: "Absolutely. The platform includes a daily goal tracker and session history, allowing parents to see what topics their child has studied and how much time they are spending on their education."
          },
          {
            question: "Is there a free trial or free version available?",
            answer: "We offer a basic tier that allows students to experience the core features of the AI Tutor. For unlimited access, voice interactions, and advanced mock tests, we have affordable premium plans."
          }
        ]
      };
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "settings/site");
      throw error;
    }
  },

  async updateSiteContent(content: any) {
    try {
      await setDoc(doc(db, "settings", "site"), {
        ...content,
        updated_at: serverTimestamp()
      }, { merge: true });
      return { success: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "settings/site");
      throw error;
    }
  }
};
