import { GoogleGenAI, Modality } from "@google/genai";
import { Language, ClassLevel } from "../types";
import { sheetsService } from "./sheetsService";

export class GeminiMiddleGroundService {
  private ai: GoogleGenAI | null = null;
  private recognition: any = null;
  private isListening: boolean = false;
  private apiKey: string | null = null;

  constructor(
    private onTranscription: (text: string, isUser: boolean) => void,
    private onPlaybackStatusChange?: (isPlaying: boolean) => void
  ) {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        
        this.recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          this.onTranscription(transcript, true);
          this.handleUserMessage(transcript);
        };

        this.recognition.onend = () => {
          if (this.isListening) {
            this.recognition.start();
          }
        };

        this.recognition.onerror = (event: any) => {
          console.error("Speech recognition error", event.error);
        };
      }
    }
  }

  private async initAI() {
    if (!this.ai) {
      const { apiKey } = await sheetsService.getGeminiKey();
      const finalKey = apiKey || process.env.GEMINI_API_KEY;
      this.apiKey = finalKey;
      if (finalKey) {
        this.ai = new GoogleGenAI({ apiKey: finalKey });
      }
    }
    return this.ai;
  }

  private language: Language = 'English';
  private classLevel: ClassLevel = '10';
  private subject: string = 'English';
  private chapterName?: string;
  private topicName?: string;
  private selectedModel: string = 'gemini-3-flash-preview';

  async connect(language: Language, classLevel: ClassLevel, subject: string, chapterName?: string, topicName?: string, model: string = 'gemini-3-flash-preview') {
    this.language = language;
    this.classLevel = classLevel;
    this.subject = subject;
    this.chapterName = chapterName;
    this.topicName = topicName;
    this.selectedModel = model && model.trim() !== '' ? model : 'gemini-3-flash-preview';
    await this.initAI();
  }

  setMicMute(muted: boolean) {
    this.isListening = !muted;
    if (this.isListening) {
      try {
        this.recognition?.start();
      } catch (e) {}
    } else {
      this.recognition?.stop();
    }
  }

  async handleUserMessage(text: string) {
    const ai = await this.initAI();
    if (!ai) {
      this.onTranscription("I'm sorry, I couldn't connect. Please check your API key in Admin Settings.", false);
      return;
    }

    // 1. Check Knowledge Base (Cache)
    try {
      const kb = await sheetsService.getKnowledgeBase(this.subject, this.classLevel);
      const cached = kb.find((item: any) => 
        item.question.toLowerCase().includes(text.toLowerCase()) || 
        text.toLowerCase().includes(item.question.toLowerCase())
      ) as any;

      if (cached) {
        this.onTranscription(cached.answer_text, false);
        if (cached.answer_audio) {
          this.playBase64Audio(cached.answer_audio);
        } else {
          this.generateAndPlayTTS(cached.answer_text);
        }
        return;
      }
    } catch (e) {
      console.error("KB check failed", e);
    }

    // 2. Call Gemini Flash Lite (The Brain)
    try {
      const systemInstruction = `You are a world-class, highly encouraging, and expert ${this.subject} Tutor for West Bengal Board students.
      Class: ${this.classLevel}, Subject: ${this.subject}, Chapter: ${this.chapterName || 'General'}, Topic: ${this.topicName || 'General'}.
      
      CONTEXT: The West Bengal Council of Higher Secondary Education (WBCHSE) has implemented a SEMESTER SYSTEM for Class 11 and 12. 
      - Class 11 (Semester 1 & 2): Semester 1 is MCQ-based, Semester 2 is Descriptive.
      - Class 12 (Semester 3 & 4): Semester 3 is MCQ-based, Semester 4 is Descriptive.
      Please adapt your teaching style based on the semester context if applicable.
      
      YOUR MISSION: Provide deep, comprehensive, and exam-oriented explanations that help students master the subject.
      
      CORE PRINCIPLES:
      1. COMPREHENSIVENESS: Never give one-sentence answers. Always provide context, definitions, and detailed explanations.
      2. CLARITY: Break down complex concepts into simple, digestible parts using clear headings and bullet points.
      3. LOCAL RELEVANCE: Use real-world examples, analogies, or cultural references relevant to students in West Bengal (e.g., local festivals, geography, or daily life).
      4. EXAM FOCUS: Highlight key points that are important for WBBSE/WBCHSE exams. Use terms like "Important for Exam" or "Key Concept".
      5. INTERACTIVITY: Always ask a follow-up question to check for understanding (e.g., "Does this make sense?", "Would you like me to explain the next part?").
      6. VISUAL SUGGESTION: If a topic is complex (like biological processes, physics experiments, or historical maps), explicitly suggest: "You can click the 'Visuals' button above to see an AI-generated video visualization of this topic."
      
      TONE:
      - Warm, patient, and extremely supportive.
      - Use encouraging phrases like "Excellent question!", "You're doing great!", "Let's explore this together."
      
      FORMATTING RULES:
      - Use # for main headers and ## for sub-headers.
      - Use **bold** for key terms and definitions.
      - Use > for important notes or "Pro-Tips".
      - Use LaTeX-style formatting for mathematical equations (e.g., $$E=mc^2$$).
      - Use code blocks (\`\`\`) for any structured data or formulas.
      - Ensure the response is visually organized and easy to scan.
      
      LANGUAGE:
      - Respond strictly in ${this.language}. If the language is Hinglish, use a natural mix of Hindi and English as spoken in West Bengal.`;

      const response = await ai.models.generateContent({
        model: this.selectedModel,
        contents: text,
        config: { systemInstruction }
      });

      const answerText = response.text || "I'm sorry, I couldn't process that.";
      this.onTranscription(answerText, false);

      // 3. Generate TTS (The Voice)
      this.generateAndPlayTTS(answerText);
    } catch (error: any) {
      console.error("AI Error", error);
      this.onTranscription(`I encountered an error: ${error.message || 'Unknown error'}. Please try again or check your API key.`, false);
    }
  }

  private async generateAndPlayTTS(text: string) {
    const ai = await this.initAI();
    if (!ai) return;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          }
        }
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        this.playBase64Audio(base64Audio);
      }
    } catch (e) {
      console.error("TTS Error", e);
    }
  }

  private playBase64Audio(base64: string) {
    this.onPlaybackStatusChange?.(true);
    const audio = new Audio(`data:audio/wav;base64,${base64}`);
    audio.onended = () => this.onPlaybackStatusChange?.(false);
    audio.play();
  }

  disconnect() {
    this.isListening = false;
    this.recognition?.stop();
  }

  // Dummy methods for compatibility with TutorInterface
  setVolume(v: number) {}
  setMute(m: boolean) {}
}
