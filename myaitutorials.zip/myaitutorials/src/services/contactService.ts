import { collection, addDoc, serverTimestamp, getDocs, query, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';

export interface ContactMessage {
  id?: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt?: any;
}

export const contactService = {
  async sendMessage(message: Omit<ContactMessage, 'id' | 'createdAt'>) {
    try {
      const docRef = await addDoc(collection(db, 'contact_messages'), {
        ...message,
        createdAt: serverTimestamp(),
      });
      return docRef.id;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  },

  async getMessages() {
    try {
      const q = query(collection(db, 'contact_messages'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as ContactMessage[];
    } catch (error) {
      console.error('Error getting messages:', error);
      throw error;
    }
  },

  async deleteMessage(id: string) {
    try {
      await deleteDoc(doc(db, 'contact_messages', id));
    } catch (error) {
      console.error('Error deleting message:', error);
      throw error;
    }
  }
};
