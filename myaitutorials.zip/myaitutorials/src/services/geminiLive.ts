/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Modality, LiveServerMessage } from "@google/genai";
import { AudioHandler } from "./audioHandler";
import { Language, ClassLevel } from "../types";

export class GeminiLiveService {
  private ai: GoogleGenAI;
  private session: any = null;
  private audioHandler: AudioHandler | null = null;
  private isPlaying: boolean = false;

  constructor(
    apiKey: string, 
    private onTranscription: (text: string, isUser: boolean) => void,
    private onPlaybackStatusChange?: (isPlaying: boolean) => void
  ) {
    this.ai = new GoogleGenAI({ apiKey });
  }

  async connect(language: Language, classLevel: ClassLevel, subject: string, chapterName?: string, topicName?: string, sampleRate: number = 16000) {
    const topicContext = chapterName && topicName 
      ? `Currently focusing on Subject: "${subject}", Chapter: "${chapterName}", Topic: "${topicName}".`
      : chapterName 
        ? `Currently focusing on Subject: "${subject}", Chapter: "${chapterName}".`
        : `Currently focusing on Subject: "${subject}".`;

    this.audioHandler = new AudioHandler(
      (base64Data) => {
        if (this.session) {
          this.session.sendRealtimeInput({
            audio: { data: base64Data, mimeType: `audio/pcm;rate=${sampleRate}` }
          });
        }
      },
      (isPlaying) => {
        this.isPlaying = isPlaying;
        this.onPlaybackStatusChange?.(isPlaying);
      }
    );

    const systemInstruction = `You are a specialized ${subject} Tutor for West Bengal Board students (WBBSE and WBCHSE), classes 9 to 12.

Current Session Context (Payload):
- Class: ${classLevel}
- Subject: ${subject}
- Chapter: ${chapterName || 'General'}
- Topic: ${topicName || 'General'}
- Language: ${language}
- Mode: Real-time Voice Tutoring

Teaching Rules:
- Explain concepts, formulas, prose, poetry, or grammar simply based on the subject.
- Give answers in proper West Bengal Board exam style (WBBSE for 9-10, WBCHSE for 11-12).
- Use a clear structure: Introduction, Body (point-wise), and Conclusion where applicable.
- Highlight important keywords and use a marks-friendly format (e.g., breaking down answers into 2+3 or 1+4 marks style).
- Keep the depth and language suitable for school exams.
${topicContext}
- Keep explanations clear, easy, and exam-oriented.
- Help students improve their understanding and appreciation of the subject.
- Use simple, student-friendly language.

Exam Style Guidelines:
- Structure long answers with sub-headings.
- Use bullet points for characteristics, advantages, or steps.
- Provide model answers that would score full marks in a board exam.
- Explain difficult terms simply but keep the technical keywords intact.

General Rules:
- Keep tone supportive, motivating, and like a real teacher/home tutor.
- Respond in the selected language: ${language}.
- For Bengali, use standard, student-friendly Bengali suitable for academic writing.
- Avoid unnecessary complexity while maintaining academic rigor.
- If you are explaining a complex concept, process, or structure that would benefit from a visual aid (like a diagram, a map, or a scientific process), suggest to the student that they can use the "Visuals" button to generate an image or video. For example, say "I can show you a visual for this if you click the Visuals button." or "Would you like to see a video of this process? Just click the Visuals button above."`;

    this.session = await this.ai.live.connect({
      model: "gemini-3.1-flash-live-preview",
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
        },
        systemInstruction,
        outputAudioTranscription: {},
        inputAudioTranscription: {},
      },
      callbacks: {
        onopen: () => {
          this.audioHandler.start(sampleRate);
        },
        onmessage: (message: LiveServerMessage) => {
          const content = message.serverContent as any;
          if (content?.modelTurn?.parts) {
            for (const part of content.modelTurn.parts) {
              if (part.inlineData?.data) {
                this.audioHandler.playChunk(part.inlineData.data);
              }
            }
          }
          
          if (content?.interrupted) {
            // Handle interruption if needed
          }

          // Handle transcriptions
          if (content?.modelTurn?.parts?.[0]?.text) {
             this.onTranscription(content.modelTurn.parts[0].text, false);
          }

          if (content?.userTurn?.parts?.[0]?.text) {
             this.onTranscription(content.userTurn.parts[0].text, true);
          }
        },
        onerror: (error) => {
          console.error("Gemini Live Error:", error);
        },
        onclose: () => {
          this.audioHandler.stop();
        }
      }
    });
  }

  disconnect() {
    if (this.session) {
      this.session.close();
      this.session = null;
    }
    this.audioHandler?.stop();
  }

  setVolume(value: number) {
    this.audioHandler?.setVolume(value);
  }

  setMute(muted: boolean) {
    this.audioHandler?.setMute(muted);
  }

  setMicMute(muted: boolean) {
    this.audioHandler?.setMicMute(muted);
  }
}
