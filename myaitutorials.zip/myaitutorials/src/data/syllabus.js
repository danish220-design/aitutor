export const syllabus = {
  '9': {
    'English': [
      { id: '9-eng-ch1', name: 'Tales of Bhola Grandpa', topics: [{ id: '9-eng-ch1-t1', name: 'Story Summary' }, { id: '9-eng-ch1-t2', name: 'Character Analysis' }] },
      { id: '9-eng-ch2', name: 'All about a Dog', topics: [{ id: '9-eng-ch2-t1', name: 'Theme of Rules' }, { id: '9-eng-ch2-t2', name: 'Grammar: Voice Change' }] },
      { id: '9-eng-ch3', name: 'Autumn', topics: [{ id: '9-eng-ch3-t1', name: 'Poem Analysis' }] },
      { id: '9-eng-ch4', name: 'A Day in the Zoo', topics: [{ id: '9-eng-ch4-t1', name: 'Descriptive Writing' }] },
      { id: '9-eng-ch5', name: 'All Summer in a Day', topics: [{ id: '9-eng-ch5-t1', name: 'Sci-Fi Elements' }] },
      { id: '9-eng-ch6', name: 'Mild the Mist upon the Hill', topics: [{ id: '9-eng-ch6-t1', name: 'Poetic Devices' }] },
    ],
    'Mathematics': [
      { id: '9-math-ch1', name: 'Real Numbers', topics: [{ id: '9-math-ch1-t1', name: 'Rational & Irrational' }] },
      { id: '9-math-ch2', name: 'Laws of Indices', topics: [{ id: '9-math-ch2-t1', name: 'Basic Laws' }] },
      { id: '9-math-ch3', name: 'Graph', topics: [{ id: '9-math-ch3-t1', name: 'Linear Equations' }] },
      { id: '9-math-ch4', name: 'Coordinate Geometry', topics: [{ id: '9-math-ch4-t1', name: 'Distance Formula' }] },
      { id: '9-math-ch5', name: 'Linear Simultaneous Equations', topics: [{ id: '9-math-ch5-t1', name: 'Method of Substitution' }] },
      { id: '9-math-ch10', name: 'Profit and Loss', topics: [{ id: '9-math-ch10-t1', name: 'Cost & Selling Price' }] },
      { id: '9-math-ch15', name: 'Area and Perimeter of Triangle & Quadrilateral', topics: [{ id: '9-math-ch15-t1', name: 'Heron\'s Formula' }] },
      { id: '9-math-ch21', name: 'Logarithm', topics: [{ id: '9-math-ch21-t1', name: 'Properties of Log' }] },
    ],
    'Physical Science': [
      { id: '9-ps-ch1', name: 'Measurement', topics: [{ id: '9-ps-ch1-t1', name: 'Units & Instruments' }] },
      { id: '9-ps-ch2', name: 'Force and Motion', topics: [{ id: '9-ps-ch2-t1', name: 'Newton\'s Laws' }] },
      { id: '9-ps-ch3', name: 'Atomic Structure', topics: [{ id: '9-ps-ch3-t1', name: 'Bohr\'s Model' }] },
      { id: '9-ps-ch4', name: 'Mole Concept', topics: [{ id: '9-ps-ch4-t1', name: 'Avogadro\'s Number' }] },
      { id: '9-ps-ch5', name: 'Energy in Action: Work, Power and Energy', topics: [{ id: '9-ps-ch5-t1', name: 'Kinetic & Potential Energy' }] },
      { id: '9-ps-ch7', name: 'Acids, Bases and Salts', topics: [{ id: '9-ps-ch7-t1', name: 'pH Scale' }] },
    ],
    'Life Science': [
      { id: '9-ls-ch1', name: 'Life and its Diversity', topics: [{ id: '9-ls-ch1-t1', name: 'Taxonomy' }] },
      { id: '9-ls-ch2', name: 'Levels of Organization of Life', topics: [{ id: '9-ls-ch2-t1', name: 'Cell Structure' }] },
      { id: '9-ls-ch3', name: 'Physiological Processes of Life', topics: [{ id: '9-ls-ch3-t1', name: 'Photosynthesis' }, { id: '9-ls-ch3-t2', name: 'Respiration' }] },
      { id: '9-ls-ch4', name: 'Biology and Human Welfare', topics: [{ id: '9-ls-ch4-t1', name: 'Immunity' }] },
    ],
    'History': [
      { id: '9-hist-ch1', name: 'French Revolution', topics: [{ id: '9-hist-ch1-t1', name: 'Causes' }, { id: '9-hist-ch1-t2', name: 'Impact' }] },
      { id: '9-hist-ch2', name: 'Revolutionary Ideals, Napoleon', topics: [{ id: '9-hist-ch2-t1', name: 'Napoleonic Code' }] },
      { id: '9-hist-ch3', name: 'Nineteenth Century Europe', topics: [{ id: '9-hist-ch3-t1', name: 'Nationalism' }] },
    ],
    'Geography': [
      { id: '9-geo-ch1', name: 'Earth as a Planet', topics: [{ id: '9-geo-ch1-t1', name: 'Shape of Earth' }] },
      { id: '9-geo-ch2', name: 'Movements of the Earth', topics: [{ id: '9-geo-ch2-t1', name: 'Rotation & Revolution' }] },
      { id: '9-geo-ch3', name: 'Determination of Location', topics: [{ id: '9-geo-ch3-t1', name: 'Latitude & Longitude' }] },
      { id: '9-geo-ch8', name: 'West Bengal', topics: [{ id: '9-geo-ch8-t1', name: 'Physical Environment' }] },
    ],
  },
  '10': {
    'English': [
      { id: '10-eng-ch1', name: "Father's Help", topics: [{ id: '10-eng-ch1-t1', name: 'Swami’s Dilemma' }] },
      { id: '10-eng-ch2', name: 'Fable', topics: [{ id: '10-eng-ch2-t1', name: 'Moral Lesson' }] },
      { id: '10-eng-ch3', name: 'The Passing Away of Bapu', topics: [{ id: '10-eng-ch3-t1', name: 'Biographical Sketch' }] },
      { id: '10-eng-ch4', name: 'My Own True Family', topics: [{ id: '10-eng-ch4-t1', name: 'Nature Conservation' }] },
      { id: '10-eng-ch5', name: 'Our Runaway Kite', topics: [{ id: '10-eng-ch5-t1', name: 'Family Reunion' }] },
      { id: '10-eng-ch7', name: 'The Cat', topics: [{ id: '10-eng-ch7-t1', name: 'Humorous Essay' }] },
    ],
    'Mathematics': [
      { id: '10-math-ch1', name: 'Quadratic Equations', topics: [{ id: '10-math-ch1-t1', name: 'Nature of Roots' }] },
      { id: '10-math-ch2', name: 'Simple Interest', topics: [{ id: '10-math-ch2-t1', name: 'Interest Calculation' }] },
      { id: '10-math-ch3', name: 'Theorems related to Circle', topics: [{ id: '10-math-ch3-t1', name: 'Angle in a Circle' }] },
      { id: '10-math-ch4', name: 'Rectangular Parallelopiped', topics: [{ id: '10-math-ch4-t1', name: 'Volume & Surface Area' }] },
      { id: '10-math-ch5', name: 'Ratio and Proportion', topics: [{ id: '10-math-ch5-t1', name: 'Properties of Proportion' }] },
      { id: '10-math-ch6', name: 'Compound Interest', topics: [{ id: '10-math-ch6-t1', name: 'Uniform Rate of Increase' }] },
      { id: '10-math-ch23', name: 'Trigonometric Ratios', topics: [{ id: '10-math-ch23-t1', name: 'Identities' }] },
      { id: '10-math-ch25', name: 'Heights and Distances', topics: [{ id: '10-math-ch25-t1', name: 'Applications' }] },
      { id: '10-math-ch26', name: 'Statistics', topics: [{ id: '10-math-ch26-t1', name: 'Mean, Median, Mode' }] },
    ],
    'Physical Science': [
      { id: '10-ps-ch1', name: 'Concerns about our Environment', topics: [{ id: '10-ps-ch1-t1', name: 'Atmosphere' }] },
      { id: '10-ps-ch2', name: 'Behaviour of Gases', topics: [{ id: '10-ps-ch2-t1', name: 'Boyle\'s & Charles\' Law' }] },
      { id: '10-ps-ch3', name: 'Chemical Calculations', topics: [{ id: '10-ps-ch3-t1', name: 'Stoichiometry' }] },
      { id: '10-ps-ch5', name: 'Light', topics: [{ id: '10-ps-ch5-t1', name: 'Refraction & Lenses' }] },
      { id: '10-ps-ch6', name: 'Current Electricity', topics: [{ id: '10-ps-ch6-t1', name: 'Ohm\'s Law' }] },
      { id: '10-ps-ch8', name: 'Periodic Table', topics: [{ id: '10-ps-ch8-t1', name: 'Periodic Properties' }] },
      { id: '10-ps-ch12', name: 'Organic Chemistry', topics: [{ id: '10-ps-ch12-t1', name: 'Hydrocarbons' }] },
    ],
    'Life Science': [
      { id: '10-ls-ch1', name: 'Control and Coordination', topics: [{ id: '10-ls-ch1-t1', name: 'Plant Hormones' }, { id: '10-ls-ch1-t2', name: 'Animal Hormones' }] },
      { id: '10-ls-ch2', name: 'Continuity of life', topics: [{ id: '10-ls-ch2-t1', name: 'Cell Division' }, { id: '10-ls-ch2-t2', name: 'Reproduction' }] },
      { id: '10-ls-ch3', name: 'Heredity', topics: [{ id: '10-ls-ch3-t1', name: 'Mendel\'s Laws' }] },
      { id: '10-ls-ch4', name: 'Evolution and Adaptation', topics: [{ id: '10-ls-ch4-t1', name: 'Darwinism' }] },
      { id: '10-ls-ch5', name: 'Environment and Conservation', topics: [{ id: '10-ls-ch5-t1', name: 'Nitrogen Cycle' }] },
    ],
    'History': [
      { id: '10-hist-ch1', name: 'Ideas of History', topics: [{ id: '10-hist-ch1-t1', name: 'New Social History' }] },
      { id: '10-hist-ch2', name: 'Reform: Characteristics and Observations', topics: [{ id: '10-hist-ch2-t1', name: 'Brahmo Samaj' }] },
      { id: '10-hist-ch3', name: 'Resistance and Rebellion', topics: [{ id: '10-hist-ch3-t1', name: 'Indigo Revolt' }] },
    ],
    'Geography': [
      { id: '10-geo-ch1', name: 'Exogenetic Processes', topics: [{ id: '10-geo-ch1-t1', name: 'Work of River' }] },
      { id: '10-geo-ch2', name: 'Atmosphere', topics: [{ id: '10-geo-ch2-t1', name: 'Structure' }] },
      { id: '10-geo-ch5', name: 'India', topics: [{ id: '10-geo-ch5-t1', name: 'Physical Environment' }, { id: '10-geo-ch5-t2', name: 'Economic Environment' }] },
    ],
  },
  '11': {
    'Science': {
      'English': [
        { id: '11-eng-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-eng-ch1', name: 'Leela\'s Friend' },
          { id: '11-eng-ch2', name: 'Karma' },
          { id: '11-eng-ch3', name: 'Upon Westminster Bridge' }
        ]},
        { id: '11-eng-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-eng-ch4', name: 'Jimmy Valentine' },
          { id: '11-eng-ch5', name: 'Meeting at Night' },
          { id: '11-eng-ch6', name: 'The Sick Rose' }
        ]}
      ],
      'Bengali': [
        { id: '11-ben-ch1', name: 'Kartar Bhoot', topics: [{ id: '11-ben-ch1-t1', name: 'Allegorical Meaning' }] },
        { id: '11-ben-ch2', name: 'Telena Pota Abishkar', topics: [{ id: '11-ben-ch2-t1', name: 'Atmosphere and Setting' }] },
      ],
      'Physics': [
        { id: '11-phy-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-phy-ch1', name: 'Units and Measurements' },
          { id: '11-phy-ch2', name: 'Kinematics' },
          { id: '11-phy-ch3', name: 'Laws of Motion' },
          { id: '11-phy-ch4', name: 'Work, Energy and Power' }
        ]},
        { id: '11-phy-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-phy-ch5', name: 'System of Particles' },
          { id: '11-phy-ch6', name: 'Gravitation' },
          { id: '11-phy-ch7', name: 'Properties of Bulk Matter' },
          { id: '11-phy-ch8', name: 'Thermodynamics' }
        ]}
      ],
      'Chemistry': [
        { id: '11-chem-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-chem-ch1', name: 'Basic Concepts' },
          { id: '11-chem-ch2', name: 'Structure of Atom' },
          { id: '11-chem-ch3', name: 'Classification of Elements' }
        ]},
        { id: '11-chem-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-chem-ch4', name: 'Chemical Bonding' },
          { id: '11-chem-ch6', name: 'Thermodynamics' },
          { id: '11-chem-ch12', name: 'Organic Chemistry' }
        ]}
      ],
      'Biology': [
        { id: '11-bio-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-bio-ch1', name: 'Diversity in Living World' },
          { id: '11-bio-ch2', name: 'Structural Organization' },
          { id: '11-bio-ch3', name: 'Cell Structure' }
        ]},
        { id: '11-bio-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-bio-ch4', name: 'Plant Physiology' },
          { id: '11-bio-ch5', name: 'Human Physiology' }
        ]}
      ],
      'Mathematics': [
        { id: '11-math-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-math-ch1', name: 'Sets and Functions' },
          { id: '11-math-ch2', name: 'Trigonometry' },
          { id: '11-math-ch3', name: 'Algebra (Complex Numbers)' }
        ]},
        { id: '11-math-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-math-ch4', name: 'Coordinate Geometry' },
          { id: '11-math-ch5', name: 'Calculus' },
          { id: '11-math-ch6', name: 'Statistics & Probability' }
        ]}
      ],
      'Computer Science': [
        { id: '11-cs-ch1', name: 'Evolution of Computers', topics: [{ id: '11-cs-ch1-t1', name: 'Generations' }] },
        { id: '11-cs-ch2', name: 'Data Representation', topics: [{ id: '11-cs-ch2-t1', name: 'Number Systems' }, { id: '11-cs-ch2-t2', name: 'Binary Arithmetic' }] },
        { id: '11-cs-ch3', name: 'Boolean Algebra', topics: [{ id: '11-cs-ch3-t1', name: 'Logic Gates' }, { id: '11-cs-ch3-t2', name: 'K-Map' }] },
        { id: '11-cs-ch4', name: 'Visual Basic', topics: [{ id: '11-cs-ch4-t1', name: 'Controls' }] },
      ],
      'Statistics': [
        { id: '11-stat-ch1', name: 'Introduction', topics: [{ id: '11-stat-ch1-t1', name: 'Data Collection' }] },
        { id: '11-stat-ch2', name: 'Measures of Central Tendency', topics: [{ id: '11-stat-ch2-t1', name: 'Mean, Median, Mode' }] },
      ],
    },
    'Arts': {
      'English': [
        { id: '11-eng-sem1-arts', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-eng-ch1-arts', name: 'Leela\'s Friend' },
          { id: '11-eng-ch2-arts', name: 'Karma' }
        ]},
        { id: '11-eng-sem2-arts', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-eng-ch3-arts', name: 'Jimmy Valentine' }
        ]}
      ],
      'Bengali': [
        { id: '11-ben-ch1', name: 'Kartar Bhoot', topics: [{ id: '11-ben-ch1-t1', name: 'Allegorical Meaning' }] },
      ],
      'History': [
        { id: '11-hist-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-hist-ch1', name: 'Understanding History' },
          { id: '11-hist-ch2', name: 'From Primitive Man to Early Civilizations' }
        ]},
        { id: '11-hist-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-hist-ch3', name: 'Evolution of Polity' },
          { id: '11-hist-ch4', name: 'Nature of the State' }
        ]}
      ],
      'Geography': [
        { id: '11-geo-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-geo-ch1', name: 'Geography as a Discipline' },
          { id: '11-geo-ch2', name: 'Principles of Physical Geography' }
        ]},
        { id: '11-geo-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-geo-ch3', name: 'Geomorphic Processes' },
          { id: '11-geo-ch6', name: 'Economic Geography' }
        ]}
      ],
      'Political Science': [
        { id: '11-pol-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-pol-ch1', name: 'Political Science: Subject and its Evolution' },
          { id: '11-pol-ch2', name: 'State' }
        ]},
        { id: '11-pol-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-pol-ch3', name: 'Nationality and Nations' },
          { id: '11-pol-ch4', name: 'Fundamental Concepts' }
        ]}
      ],
      'Philosophy': [
        { id: '11-phil-ch1', name: 'Introduction to Philosophy', topics: [{ id: '11-phil-ch1-t1', name: 'Branches of Philosophy' }] },
        { id: '11-phil-ch2', name: 'Indian Philosophy', topics: [{ id: '11-phil-ch2-t1', name: 'Charvaka' }, { id: '11-phil-ch2-t2', name: 'Nyaya' }] },
      ],
      'Sociology': [
        { id: '11-soc-ch1', name: 'Sociology and its Relationship', topics: [{ id: '11-soc-ch1-t1', name: 'Scope' }] },
      ],
      'Education': [
        { id: '11-edu-ch1', name: 'Concept and Aims of Education', topics: [{ id: '11-edu-ch1-t1', name: 'Individual vs Social Aims' }] },
      ],
      'Psychology': [
        { id: '11-psy-ch1', name: 'Introduction to Psychology', topics: [{ id: '11-psy-ch1-t1', name: 'Methods' }] },
      ],
    },
    'Commerce': {
      'English': [
        { id: '11-eng-sem1-comm', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-eng-ch1-comm', name: 'Leela\'s Friend' }
        ]},
        { id: '11-eng-sem2-comm', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-eng-ch2-comm', name: 'Karma' }
        ]}
      ],
      'Bengali': [
        { id: '11-ben-ch1', name: 'Kartar Bhoot', topics: [{ id: '11-ben-ch1-t1', name: 'Allegorical Meaning' }] },
      ],
      'Accountancy': [
        { id: '11-acc-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-acc-ch1', name: 'Introduction to Accounting' },
          { id: '11-acc-ch2', name: 'Theory Base of Accounting' }
        ]},
        { id: '11-acc-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-acc-ch3', name: 'Recording of Transactions' },
          { id: '11-acc-ch4', name: 'Bank Reconciliation Statement' }
        ]}
      ],
      'Business Studies': [
        { id: '11-bst-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-bst-ch1', name: 'Nature and Purpose of Business' }
        ]},
        { id: '11-bst-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-bst-ch2', name: 'Forms of Business Organizations' }
        ]}
      ],
      'Economics': [
        { id: '11-eco-sem1', name: 'Semester 1 (MCQ Based)', topics: [
          { id: '11-eco-ch1', name: 'Introduction' },
          { id: '11-eco-ch2', name: 'Basic Problems of an Economy' }
        ]},
        { id: '11-eco-sem2', name: 'Semester 2 (Descriptive)', topics: [
          { id: '11-eco-ch3', name: 'Indian Economy' },
          { id: '11-eco-ch4', name: 'Business Economics' }
        ]}
      ],
      'Commercial Law & Preliminaries of Auditing': [
        { id: '11-clpa-ch1', name: 'Law of Contract', topics: [{ id: '11-clpa-ch1-t1', name: 'Offer & Acceptance' }] },
      ],
      'Costing & Taxation': [
        { id: '11-ct-ch1', name: 'Costing Introduction', topics: [{ id: '11-ct-ch1-t1', name: 'Elements of Cost' }] },
      ],
    }
  },
  '12': {
    'Science': {
      'English': [
        { id: '12-eng-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-eng-ch1', name: 'The Eyes Have It' },
          { id: '12-eng-ch2', name: 'Strong Roots' }
        ]},
        { id: '12-eng-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-eng-ch3', name: 'Thank You Ma\'am' },
          { id: '12-eng-ch4', name: 'Three Questions' },
          { id: '12-eng-ch5', name: 'On Killing a Tree' }
        ]}
      ],
      'Bengali': [
        { id: '12-ben-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-ben-ch1', name: 'Ke Bachay Ke Bache' }
        ]},
        { id: '12-ben-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-ben-ch2', name: 'Bhat' }
        ]}
      ],
      'Physics': [
        { id: '12-phy-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-phy-ch1', name: 'Electrostatics' },
          { id: '12-phy-ch2', name: 'Current Electricity' },
          { id: '12-phy-ch3', name: 'Magnetic Effect of Current' },
          { id: '12-phy-ch4', name: 'Magnetism and Matter' }
        ]},
        { id: '12-phy-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-phy-ch5', name: 'Electromagnetic Induction' },
          { id: '12-phy-ch6', name: 'Optics' },
          { id: '12-phy-ch7', name: 'Dual Nature of Matter' },
          { id: '12-phy-ch8', name: 'Atoms and Nuclei' },
          { id: '12-phy-ch9', name: 'Electronic Devices' }
        ]}
      ],
      'Chemistry': [
        { id: '12-chem-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-chem-ch1', name: 'Solid State' },
          { id: '12-chem-ch2', name: 'Solutions' },
          { id: '12-chem-ch3', name: 'Electrochemistry' }
        ]},
        { id: '12-chem-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-chem-ch4', name: 'Chemical Kinetics' },
          { id: '12-chem-ch5', name: 'Surface Chemistry' },
          { id: '12-chem-ch10', name: 'Haloalkanes' },
          { id: '12-chem-ch11', name: 'Alcohols, Phenols' },
          { id: '12-chem-ch14', name: 'Biomolecules' }
        ]}
      ],
      'Biology': [
        { id: '12-bio-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-bio-ch1', name: 'Reproduction' },
          { id: '12-bio-ch2', name: 'Genetics and Evolution' }
        ]},
        { id: '12-bio-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-bio-ch3', name: 'Biology and Human Welfare' },
          { id: '12-bio-ch4', name: 'Biotechnology' },
          { id: '12-bio-ch5', name: 'Ecology' }
        ]}
      ],
      'Mathematics': [
        { id: '12-math-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-math-ch1', name: 'Relations and Functions' },
          { id: '12-math-ch2', name: 'Algebra (Matrices & Determinants)' }
        ]},
        { id: '12-math-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-math-ch3', name: 'Calculus' },
          { id: '12-math-ch4', name: 'Vectors & 3D' },
          { id: '12-math-ch5', name: 'Linear Programming' },
          { id: '12-math-ch6', name: 'Probability' }
        ]}
      ],
      'Computer Science': [
        { id: '12-cs-ch1', name: 'Data Structures', topics: [{ id: '12-cs-ch1-t1', name: 'Stacks & Queues' }, { id: '12-cs-ch1-t2', name: 'Linked Lists' }] },
        { id: '12-cs-ch2', name: 'Networking', topics: [{ id: '12-cs-ch2-t1', name: 'OSI Model' }, { id: '12-cs-ch2-t2', name: 'TCP/IP' }] },
        { id: '12-cs-ch3', name: 'Database Management', topics: [{ id: '12-cs-ch3-t1', name: 'SQL Queries' }, { id: '12-cs-ch3-t2', name: 'Normalization' }] },
        { id: '12-cs-ch4', name: 'Object Oriented Programming', topics: [{ id: '12-cs-ch4-t1', name: 'Classes & Objects' }] },
      ],
      'Statistics': [
        { id: '12-stat-ch1', name: 'Probability Theory', topics: [{ id: '12-stat-ch1-t1', name: 'Conditional Probability' }] },
      ],
    },
    'Arts': {
      'English': [
        { id: '12-eng-sem3-arts', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-eng-ch1-arts', name: 'The Eyes Have It' },
          { id: '12-eng-ch2-arts', name: 'Strong Roots' }
        ]},
        { id: '12-eng-sem4-arts', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-eng-ch3-arts', name: 'Thank You Ma\'am' }
        ]}
      ],
      'Bengali': [
        { id: '12-ben-sem3-arts', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-ben-ch1-arts', name: 'Ke Bachay Ke Bache' }
        ]},
        { id: '12-ben-sem4-arts', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-ben-ch2-arts', name: 'Bhat' }
        ]}
      ],
      'History': [
        { id: '12-hist-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-hist-ch1', name: 'Remembering the Past' },
          { id: '12-hist-ch2', name: 'Colonialism and Imperialism' }
        ]},
        { id: '12-hist-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-hist-ch3', name: 'Nature of Colonial Dominance' },
          { id: '12-hist-ch7', name: 'The Era of the Cold War' }
        ]}
      ],
      'Geography': [
        { id: '12-geo-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-geo-ch1', name: 'Geomorphic Processes' },
          { id: '12-geo-ch6', name: 'Soil' }
        ]},
        { id: '12-geo-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-geo-ch10', name: 'Economic Activities' },
          { id: '12-geo-ch11', name: 'Population and Settlement' }
        ]}
      ],
      'Political Science': [
        { id: '12-pol-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-pol-ch1', name: 'International Relations' },
          { id: '12-pol-ch2', name: 'Post-Second World War Period' }
        ]},
        { id: '12-pol-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-pol-ch5', name: 'Some Major Political Doctrines' }
        ]}
      ],
      'Philosophy': [
        { id: '12-phil-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-phil-ch1', name: 'Argument' }
        ]},
        { id: '12-phil-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-phil-ch2', name: 'Proposition' }
        ]}
      ],
      'Sociology': [
        { id: '12-soc-ch1', name: 'Indian Society', topics: [{ id: '12-soc-ch1-t1', name: 'Unity in Diversity' }] },
      ],
      'Education': [
        { id: '12-edu-ch1', name: 'Psychological Basis of Education', topics: [{ id: '12-edu-ch1-t1', name: 'Learning' }] },
      ],
      'Psychology': [
        { id: '12-psy-ch1', name: 'Intelligence', topics: [{ id: '12-psy-ch1-t1', name: 'Theories' }] },
      ],
    },
    'Commerce': {
      'English': [
        { id: '12-eng-sem3-comm', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-eng-ch1-comm', name: 'The Eyes Have It' }
        ]},
        { id: '12-eng-sem4-comm', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-eng-ch2-comm', name: 'Strong Roots' }
        ]}
      ],
      'Bengali': [
        { id: '12-ben-sem3-comm', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-ben-ch1-comm', name: 'Ke Bachay Ke Bache' }
        ]},
        { id: '12-ben-sem4-comm', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-ben-ch2-comm', name: 'Bhat' }
        ]}
      ],
      'Accountancy': [
        { id: '12-acc-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-acc-ch1', name: 'Accounting for Partnership' }
        ]},
        { id: '12-acc-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-acc-ch2', name: 'Accounting for Share Capital' },
          { id: '12-acc-ch3', name: 'Financial Statement Analysis' }
        ]}
      ],
      'Business Studies': [
        { id: '12-bst-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-bst-ch1', name: 'Principles of Management' },
          { id: '12-bst-ch2', name: 'Business Environment' }
        ]},
        { id: '12-bst-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-bst-ch3', name: 'Planning' },
          { id: '12-bst-ch4', name: 'Organizing' }
        ]}
      ],
      'Economics': [
        { id: '12-eco-sem3', name: 'Semester 3 (MCQ Based)', topics: [
          { id: '12-eco-ch1', name: 'Demand' }
        ]},
        { id: '12-eco-sem4', name: 'Semester 4 (Descriptive)', topics: [
          { id: '12-eco-ch2', name: 'Production and Cost' },
          { id: '12-eco-ch3', name: 'Market Structure' }
        ]}
      ],
      'Commercial Law & Preliminaries of Auditing': [
        { id: '12-clpa-ch1', name: 'Law of Partnership', topics: [{ id: '12-clpa-ch1-t1', name: 'Registration' }] },
        { id: '12-clpa-ch2', name: 'Auditing Introduction', topics: [{ id: '12-clpa-ch2-t1', name: 'Vouching' }] },
      ],
      'Costing & Taxation': [
        { id: '12-ct-ch1', name: 'Cost of Materials', topics: [{ id: '12-ct-ch1-t1', name: 'FIFO & LIFO' }] },
        { id: '12-ct-ch2', name: 'Income from Salary', topics: [{ id: '12-ct-ch2-t1', name: 'Allowances' }] },
      ],
    }
  },

};
