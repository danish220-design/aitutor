import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Plus, 
  Trash2, 
  Edit2, 
  Save, 
  X, 
  ChevronRight, 
  ChevronDown, 
  Layers, 
  GraduationCap, 
  Search,
  RefreshCcw,
  AlertCircle,
  CheckCircle2,
  List
} from 'lucide-react';
import { syllabusService, SyllabusEntry, Chapter, Topic } from '../services/syllabusService';

export const AdminSyllabusManager: React.FC = () => {
  const [entries, setEntries] = useState<SyllabusEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingEntry, setEditingEntry] = useState<SyllabusEntry | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [confirmAction, setConfirmAction] = useState<{ type: 'migrate' | 'delete', id?: string } | null>(null);

  useEffect(() => {
    fetchSyllabus();
  }, []);

  const fetchSyllabus = async () => {
    setIsLoading(true);
    try {
      const data = await syllabusService.getSyllabus();
      setEntries(data);
    } catch (error) {
      console.error('Error fetching syllabus:', error);
      setMessage({ type: 'error', text: 'Failed to load syllabus.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleMigrate = async () => {
    setIsLoading(true);
    try {
      await syllabusService.migrateSyllabus();
      await fetchSyllabus();
      setMessage({ type: 'success', text: 'Migration complete!' });
      setConfirmAction(null);
    } catch (error) {
      console.error('Migration error:', error);
      setMessage({ type: 'error', text: 'Migration failed.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!editingEntry) return;
    if (!editingEntry.classLevel || !editingEntry.subject) {
      setMessage({ type: 'error', text: 'Class and Subject are required.' });
      return;
    }

    setIsSaving(true);
    try {
      const { id, updatedAt, ...entryData } = editingEntry;
      await syllabusService.saveSyllabusEntry(entryData);
      await fetchSyllabus();
      setEditingEntry(null);
      setMessage({ type: 'success', text: 'Syllabus saved successfully!' });
    } catch (error) {
      console.error('Error saving syllabus:', error);
      setMessage({ type: 'error', text: 'Failed to save syllabus.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await syllabusService.deleteSyllabusEntry(id);
      setEntries(entries.filter(e => e.id !== id));
      setMessage({ type: 'success', text: 'Entry deleted.' });
      setConfirmAction(null);
    } catch (error) {
      console.error('Error deleting entry:', error);
      setMessage({ type: 'error', text: 'Failed to delete entry.' });
    }
  };

  const addChapter = () => {
    if (!editingEntry) return;
    const newChapter: Chapter = {
      id: `ch-${Date.now()}`,
      name: 'New Chapter',
      topics: []
    };
    setEditingEntry({
      ...editingEntry,
      chapters: [...editingEntry.chapters, newChapter]
    });
  };

  const updateChapterName = (chapterId: string, name: string) => {
    if (!editingEntry) return;
    setEditingEntry({
      ...editingEntry,
      chapters: editingEntry.chapters.map(ch => 
        ch.id === chapterId ? { ...ch, name } : ch
      )
    });
  };

  const deleteChapter = (chapterId: string) => {
    if (!editingEntry) return;
    setEditingEntry({
      ...editingEntry,
      chapters: editingEntry.chapters.filter(ch => ch.id !== chapterId)
    });
  };

  const addTopic = (chapterId: string) => {
    if (!editingEntry) return;
    const newTopic: Topic = {
      id: `t-${Date.now()}`,
      name: 'New Topic'
    };
    setEditingEntry({
      ...editingEntry,
      chapters: editingEntry.chapters.map(ch => 
        ch.id === chapterId ? { ...ch, topics: [...ch.topics, newTopic] } : ch
      )
    });
  };

  const updateTopicName = (chapterId: string, topicId: string, name: string) => {
    if (!editingEntry) return;
    setEditingEntry({
      ...editingEntry,
      chapters: editingEntry.chapters.map(ch => 
        ch.id === chapterId ? {
          ...ch,
          topics: ch.topics.map(t => t.id === topicId ? { ...t, name } : t)
        } : ch
      )
    });
  };

  const deleteTopic = (chapterId: string, topicId: string) => {
    if (!editingEntry) return;
    setEditingEntry({
      ...editingEntry,
      chapters: editingEntry.chapters.map(ch => 
        ch.id === chapterId ? {
          ...ch,
          topics: ch.topics.filter(t => t.id !== topicId)
        } : ch
      )
    });
  };

  const filteredEntries = entries.filter(e => 
    e.classLevel.includes(searchTerm) ||
    e.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (e.stream && e.stream.toLowerCase().includes(searchTerm.toLowerCase()))
  ).sort((a, b) => {
    const classDiff = parseInt(a.classLevel) - parseInt(b.classLevel);
    if (classDiff !== 0) return classDiff;
    return a.subject.localeCompare(b.subject);
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-cyan-500" />
            Syllabus Manager
          </h3>
          <p className="text-sm text-slate-500 dark:text-slate-400">Manage subjects, chapters, and topics for all classes.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setConfirmAction({ type: 'migrate' })}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-sm font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
          >
            <RefreshCcw className="w-4 h-4" />
            Seed from File
          </button>
          <button 
            onClick={() => setEditingEntry({ classLevel: '10', subject: '', chapters: [], updatedAt: null })}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 text-white text-sm font-bold hover:bg-cyan-700 transition-all shadow-lg shadow-cyan-500/20"
          >
            <Plus className="w-4 h-4" />
            Add Subject
          </button>
        </div>
      </div>

      {message && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl flex items-center gap-3 text-sm font-medium ${
            message.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'
          }`}
        >
          {message.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          {message.text}
          <button onClick={() => setMessage(null)} className="ml-auto p-1 hover:bg-black/5 rounded-lg transition-colors">
            <X className="w-4 h-4" />
          </button>
        </motion.div>
      )}

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input 
          type="text" 
          placeholder="Search by class, stream, or subject..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-6 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 outline-none focus:ring-2 focus:ring-cyan-500/20 focus:border-cyan-500 transition-all"
        />
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <RefreshCcw className="w-8 h-8 text-cyan-500 animate-spin" />
          <p className="text-slate-500 font-medium">Loading syllabus data...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredEntries.map((entry) => (
            <motion.div 
              key={entry.id}
              layout
              className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 hover:shadow-xl hover:shadow-slate-200/50 dark:hover:shadow-none transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-900 dark:text-white font-bold text-lg">
                    {entry.classLevel}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-lg font-bold text-slate-900 dark:text-white">{entry.subject}</h4>
                      {entry.stream && (
                        <span className="px-2 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold uppercase tracking-wider">
                          {entry.stream}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500">{entry.chapters.length} Chapters • {entry.chapters.reduce((acc, ch) => acc + ch.topics.length, 0)} Topics</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setEditingEntry(entry)}
                    className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-cyan-600 transition-colors"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setConfirmAction({ type: 'delete', id: entry.id })}
                    className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirmAction && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[400] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-8 text-center"
            >
              <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h4 className="text-xl font-bold mb-2">Are you sure?</h4>
              <p className="text-slate-500 dark:text-slate-400 mb-8">
                {confirmAction.type === 'migrate' 
                  ? 'This will seed the database from the hardcoded syllabus.js if it is currently empty. This action cannot be undone.'
                  : 'Are you sure you want to delete this syllabus entry? This will remove all associated chapters and topics.'}
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setConfirmAction(null)}
                  className="flex-1 px-6 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-200 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => confirmAction.type === 'migrate' ? handleMigrate() : handleDelete(confirmAction.id!)}
                  className="flex-1 px-6 py-3 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20"
                >
                  Confirm
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Modal */}
      <AnimatePresence>
        {editingEntry && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white dark:bg-slate-900 w-full max-w-4xl max-h-[90vh] rounded-[2.5rem] shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden"
            >
              <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/50">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                    <BookOpen className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">
                      {editingEntry.id ? 'Edit Syllabus' : 'Add New Subject'}
                    </h3>
                    <p className="text-sm text-slate-500">Configure chapters and topics for your students.</p>
                  </div>
                </div>
                <button onClick={() => setEditingEntry(null)} className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 rounded-xl transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Class Level</label>
                    <select 
                      value={editingEntry.classLevel}
                      onChange={(e) => setEditingEntry({ ...editingEntry, classLevel: e.target.value })}
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 outline-none focus:border-cyan-500 transition-colors"
                    >
                      {['9', '10', '11', '12'].map(cls => <option key={cls} value={cls}>Class {cls}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Stream (Optional)</label>
                    <select 
                      value={editingEntry.stream || ''}
                      onChange={(e) => setEditingEntry({ ...editingEntry, stream: e.target.value || undefined })}
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 outline-none focus:border-cyan-500 transition-colors"
                    >
                      <option value="">No Stream</option>
                      <option value="Science">Science</option>
                      <option value="Arts">Arts</option>
                      <option value="Commerce">Commerce</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Subject Name</label>
                    <input 
                      type="text" 
                      value={editingEntry.subject}
                      onChange={(e) => setEditingEntry({ ...editingEntry, subject: e.target.value })}
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 outline-none focus:border-cyan-500 transition-colors"
                      placeholder="e.g. Physics"
                    />
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <Layers className="w-5 h-5 text-cyan-500" />
                      Chapters & Topics
                    </h4>
                    <button 
                      onClick={addChapter}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                    >
                      <Plus className="w-4 h-4" />
                      Add Chapter
                    </button>
                  </div>

                  <div className="space-y-4">
                    {editingEntry.chapters.map((chapter, chIndex) => (
                      <div key={chapter.id} className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 space-y-4">
                        <div className="flex items-center gap-4">
                          <span className="w-8 h-8 rounded-full bg-cyan-100 dark:bg-cyan-900/30 text-cyan-600 dark:text-cyan-400 flex items-center justify-center text-xs font-bold">
                            {chIndex + 1}
                          </span>
                          <input 
                            type="text" 
                            value={chapter.name}
                            onChange={(e) => updateChapterName(chapter.id, e.target.value)}
                            className="flex-1 bg-transparent border-none outline-none font-bold text-slate-900 dark:text-white placeholder:text-slate-400"
                            placeholder="Chapter Name"
                          />
                          <button 
                            onClick={() => deleteChapter(chapter.id)}
                            className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="pl-12 space-y-3">
                          <div className="flex flex-wrap gap-2">
                            {chapter.topics.map((topic) => (
                              <div key={topic.id} className="group/topic flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                                <input 
                                  type="text" 
                                  value={topic.name}
                                  onChange={(e) => updateTopicName(chapter.id, topic.id, e.target.value)}
                                  className="bg-transparent border-none outline-none text-xs font-medium text-slate-600 dark:text-slate-300 w-24 focus:w-40 transition-all"
                                />
                                <button 
                                  onClick={() => deleteTopic(chapter.id, topic.id)}
                                  className="opacity-0 group-hover/topic:opacity-100 p-1 hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 rounded-lg transition-all"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              </div>
                            ))}
                            <button 
                              onClick={() => addTopic(chapter.id)}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-50 dark:bg-cyan-900/20 text-cyan-600 dark:text-cyan-400 text-xs font-bold hover:bg-cyan-100 dark:hover:bg-cyan-900/40 transition-all border border-cyan-100 dark:border-cyan-900/30"
                            >
                              <Plus className="w-3 h-3" />
                              Add Topic
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                    {editingEntry.chapters.length === 0 && (
                      <div className="text-center py-12 bg-slate-50 dark:bg-slate-800/30 rounded-3xl border border-dashed border-slate-200 dark:border-slate-700">
                        <List className="w-8 h-8 text-slate-300 mx-auto mb-3" />
                        <p className="text-slate-400 text-sm">No chapters added yet. Click "Add Chapter" to begin.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-8 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-end gap-4">
                <button 
                  onClick={() => setEditingEntry(null)}
                  className="px-8 py-4 rounded-2xl text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex items-center gap-2 px-10 py-4 rounded-2xl bg-cyan-600 text-white font-bold hover:bg-cyan-700 transition-all shadow-lg shadow-cyan-500/20 disabled:opacity-50"
                >
                  {isSaving ? <RefreshCcw className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                  Save Syllabus
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
