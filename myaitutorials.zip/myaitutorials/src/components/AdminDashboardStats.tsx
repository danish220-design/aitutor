import React, { useEffect, useState } from 'react';
import { Users, MessageSquare, Clock, Activity } from 'lucide-react';
import { sheetsService } from '../services/sheetsService';

export const AdminDashboardStats = ({ user }: { user: any }) => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalSessions: 0,
    totalMessages: 0,
    loginsAM: 0,
    loginsPM: 0,
    liveUsers: 0,
    recentUsers: [] as any[]
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await sheetsService.getAdminStats();
        setStats(data);
      } catch (error) {
        console.error("Error fetching admin stats", error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchStats();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="text-center py-12 text-slate-500">
        Please log in as an administrator to view this dashboard.
      </div>
    );
  }

  if (loading) {
    return (
      <div className="text-center py-12 text-slate-500 animate-pulse">
        Loading platform analytics...
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Activity className="w-6 h-6 text-cyan-500" />
          Platform Analytics
        </h3>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
          <Users className="w-6 h-6 mb-4 text-purple-500" />
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Registered Students</p>
          <div className="text-3xl font-bold text-slate-900 dark:text-white">{stats.totalUsers}</div>
          <p className="text-[10px] text-slate-500 mt-1">Since day one</p>
        </div>
        <div className="p-6 rounded-3xl bg-cyan-600 text-white shadow-lg shadow-cyan-500/20">
          <Activity className="w-6 h-6 mb-4 text-white" />
          <p className="text-xs font-bold opacity-70 uppercase tracking-widest mb-1">Currently Live Study</p>
          <div className="text-3xl font-bold">{stats.liveUsers}</div>
          <p className="text-[10px] opacity-70 mt-1">Active in last 15 mins</p>
        </div>
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
          <Clock className="w-6 h-6 mb-4 text-amber-500" />
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Today's Login Activity</p>
          <div className="flex items-end gap-4">
            <div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">{stats.loginsAM}</div>
              <p className="text-[10px] text-slate-500">12 AM - 12 PM</p>
            </div>
            <div className="w-[1px] h-8 bg-slate-200 dark:bg-slate-700 mb-1" />
            <div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">{stats.loginsPM}</div>
              <p className="text-[10px] text-slate-500">12 PM - 12 AM</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
          <Activity className="w-6 h-6 mb-4 text-cyan-500" />
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Sessions</p>
          <div className="text-3xl font-bold text-slate-900 dark:text-white">{stats.totalSessions}</div>
        </div>
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
          <div className="w-6 h-6 mb-4 text-emerald-500 flex items-center justify-center font-bold text-xl">₹</div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Est. Monthly Revenue</p>
          <div className="text-3xl font-bold text-slate-900 dark:text-white">₹{(stats.totalUsers * 299).toLocaleString()}</div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Clock className="w-5 h-5 text-cyan-500" />
          Recent Signups
        </h3>
        <div className="bg-slate-50 dark:bg-slate-800/30 border border-slate-100 dark:border-slate-800 rounded-2xl overflow-hidden">
          {stats.recentUsers.length > 0 ? (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {stats.recentUsers.map((u, i) => (
                <div key={i} className="p-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white">{u.displayName || 'Anonymous User'}</p>
                    <p className="text-xs text-slate-500">{u.email}</p>
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-2 py-1 bg-cyan-100 dark:bg-cyan-900/30 text-cyan-700 dark:text-cyan-400 text-[10px] font-bold rounded-full uppercase tracking-wider">
                      {u.role || 'user'}
                    </span>
                    <p className="text-[10px] text-slate-400 mt-1">
                      {u.createdAt?.toDate ? u.createdAt.toDate().toLocaleDateString() : (u.createdAt?.seconds ? new Date(u.createdAt.seconds * 1000).toLocaleDateString() : 'N/A')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 text-sm">
              No users found.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
