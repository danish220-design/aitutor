import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Video, Loader2, Sparkles, AlertCircle, Download, PlayCircle } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { sheetsService } from '../services/sheetsService';

interface VideoGenerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  subject?: string;
  topicName?: string;
}

export const VideoGenerationModal: React.FC<VideoGenerationModalProps> = ({ isOpen, onClose, subject, topicName }) => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<string>('');

  useEffect(() => {
    if (isOpen && subject && topicName && !prompt) {
      setPrompt(`An educational 3D animation explaining ${topicName} in ${subject}, clear and visually engaging.`);
    }
  }, [isOpen, subject, topicName]);

  const examplePrompts = [
    `A 3D animation explaining the process of photosynthesis, showing sunlight hitting a leaf and converting to energy.`,
    `A cinematic visualization of the solar system with planets orbiting the sun, educational style.`,
    `A microscopic view of red blood cells flowing through a vein, highly detailed and realistic.`,
    `An animated diagram showing how a four-stroke engine works, with parts moving.`
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setError(null);
    setVideoUrl(null);
    setProgress('Initializing video generation...');

    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const actualKey = apiKey || process.env.GEMINI_API_KEY!;
      const ai = new GoogleGenAI({ apiKey: actualKey });

      setProgress('Sending request to Veo model...');
      
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-lite-generate-preview',
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      let dots = 0;
      const interval = setInterval(() => {
        dots = (dots + 1) % 4;
        setProgress(`Generating video... This usually takes 1-3 minutes${'.'.repeat(dots)}`);
      }, 2000);

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }
      
      clearInterval(interval);

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      
      if (!downloadLink) {
        throw new Error('Failed to retrieve video URL from the response.');
      }

      setProgress('Fetching generated video...');

      const response = await fetch(downloadLink, {
        method: 'GET',
        headers: {
          'x-goog-api-key': actualKey,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch video: ${response.statusText}`);
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setVideoUrl(url);
      setProgress('');
    } catch (err: any) {
      console.error('Video generation error:', err);
      setError(err.message || 'An error occurred during video generation.');
      setProgress('');
    } finally {
      setIsGenerating(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[200] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-3xl overflow-hidden border border-slate-200 dark:border-slate-800 flex flex-col max-h-[90vh]"
        >
          <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-purple-600 dark:text-purple-400">
                <Video className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  AI Video Generator
                  <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-purple-500 to-cyan-500 text-white text-[10px] font-bold uppercase tracking-wider">Veo</span>
                </h2>
                <p className="text-sm text-slate-500 dark:text-slate-400">Create educational videos instantly</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 overflow-y-auto flex-1 custom-scrollbar">
            {!videoUrl && !isGenerating ? (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                    Describe the video you want to generate
                  </label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="E.g., A 3D animation explaining the water cycle..."
                    className="w-full h-32 px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all resize-none text-slate-700 dark:text-slate-200"
                  />
                </div>

                <div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Sparkles className="w-3 h-3" />
                    Example Prompts
                  </p>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {examplePrompts.map((ep, idx) => (
                      <button
                        key={idx}
                        onClick={() => setPrompt(ep)}
                        className="text-left p-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-purple-400 dark:hover:border-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/10 transition-all text-sm text-slate-600 dark:text-slate-300"
                      >
                        {ep}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : isGenerating ? (
              <div className="h-64 flex flex-col items-center justify-center text-center space-y-6">
                <div className="relative">
                  <div className="w-20 h-20 rounded-full border-4 border-slate-100 dark:border-slate-800 border-t-purple-500 animate-spin" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Video className="w-8 h-8 text-purple-500 animate-pulse" />
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Generating your video</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs mx-auto">{progress}</p>
                </div>
              </div>
            ) : videoUrl ? (
              <div className="space-y-6">
                <div className="rounded-2xl overflow-hidden bg-black aspect-video relative border border-slate-200 dark:border-slate-800">
                  <video 
                    src={videoUrl} 
                    controls 
                    autoPlay 
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-slate-500 dark:text-slate-400 flex-1 truncate pr-4">
                    <span className="font-bold">Prompt:</span> {prompt}
                  </p>
                  <a
                    href={videoUrl}
                    download="generated-video.mp4"
                    className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-sm font-bold transition-colors shrink-0"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </a>
                </div>
              </div>
            ) : null}

            {error && (
              <div className="mt-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800/30 rounded-xl flex items-start gap-3 text-red-600 dark:text-red-400">
                <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                <p className="text-sm">{error}</p>
              </div>
            )}
          </div>

          <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-end gap-3">
            {videoUrl ? (
              <button
                onClick={() => {
                  setVideoUrl(null);
                  setPrompt('');
                }}
                className="px-6 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold transition-colors flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Generate Another
              </button>
            ) : (
              <>
                <button
                  onClick={onClose}
                  disabled={isGenerating}
                  className="px-6 py-2.5 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl font-bold transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleGenerate}
                  disabled={!prompt.trim() || isGenerating}
                  className="px-6 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-lg shadow-purple-500/20"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <PlayCircle className="w-4 h-4" />
                      Generate Video
                    </>
                  )}
                </button>
              </>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
