/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  GraduationCap, Languages, BookOpen, ArrowRight, Sparkles, CheckCircle2, 
  Zap, Clock, MessageSquare, Users, Rocket, TrendingDown, Menu, X, 
  Mail, Phone, MapPin, Shield, RefreshCcw, FileText, ChevronRight, Globe, LogOut, MessageCircle,
  Upload, Image as ImageIcon, ChevronDown, HelpCircle, Youtube, Instagram, Facebook, Share2
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { ClassLevel, Language } from '../types';
import { sheetsService, User as SheetsUser } from '../services/sheetsService';

import { contactService } from '../services/contactService';

interface LandingPageProps {
  onStart: (cls?: ClassLevel) => void;
  onAdminClick: () => void;
  syllabus: any;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart, onAdminClick, syllabus }) => {
  const [user, setUser] = useState<SheetsUser | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activePolicy, setActivePolicy] = useState<string | null>(null);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const [selectedSyllabusClass, setSelectedSyllabusClass] = useState<ClassLevel | null>(null);
  const [selectedStream, setSelectedStream] = useState<string>('Science');
  const [selectedPricingClass, setSelectedPricingClass] = useState<ClassLevel>('10');
  const [authMode, setAuthMode] = useState<'login' | 'register' | null>(null);
  const [authClass, setAuthClass] = useState<ClassLevel | ''>('');
  const [heroImage, setHeroImage] = useState<string | null>('https://picsum.photos/seed/west-bengal-students/1200/800');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [siteContent, setSiteContent] = useState<any>(null);

  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);
  const heroFileInputRef = React.useRef<HTMLInputElement>(null);
  const aboutFileInputRef = React.useRef<HTMLInputElement>(null);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  useEffect(() => {
    setUser(sheetsService.getCurrentUser());
    fetchSiteContent();
  }, []);

  const fetchSiteContent = async () => {
    try {
      const content = await sheetsService.getSiteContent();
      setSiteContent(content);
      if (content.hero_background_url) {
        setHeroImage(content.hero_background_url);
      }
    } catch (error) {
      console.error('Error fetching site content:', error);
    }
  };

  const handleHeroUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('File size too large. Please use an image under 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setHeroImage(base64);
      try {
        const currentContent = await sheetsService.getSiteContent();
        await sheetsService.updateSiteContent({ ...currentContent, hero_background_url: base64 });
      } catch (error) {
        console.error("Failed to update hero background:", error);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAboutUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('File size too large. Please use an image under 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      try {
        const currentContent = await sheetsService.getSiteContent();
        await sheetsService.updateSiteContent({ ...currentContent, about_background_url: base64 });
        setSiteContent({ ...currentContent, about_background_url: base64 });
      } catch (error) {
        console.error("Failed to update about background:", error);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthLoading(true);
    setAuthError(null);
    try {
      if (authMode === 'register') {
        const result = await sheetsService.signup({
          email,
          password,
          classLevel: (authClass || '10') as ClassLevel,
          language: 'English'
        });
        setUser(result.user);
      } else {
        const result = await sheetsService.login({ email, password });
        setUser(result.user);
      }
      setAuthMode(null);
      if (authClass) {
        onStart(authClass as ClassLevel);
      } else {
        onStart();
      }
    } catch (error: any) {
      setAuthError(error.message);
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setIsAuthLoading(true);
    setAuthError(null);
    try {
      const result = await sheetsService.loginWithGoogle();
      setUser(result.user);
      setAuthMode(null);
      if (authClass) {
        onStart(authClass as ClassLevel);
      } else {
        onStart();
      }
    } catch (error: any) {
      console.error("Google Auth error:", error);
      let message = error.message || "An error occurred during Google authentication.";
      
      if (message.includes("popup was closed")) {
        message = "Sign-in popup was blocked or closed. If you are using Safari or a strict browser, please open the app in a new tab to sign in.";
      } else if (message.includes("not authorized")) {
        message += `\n\nPlease add this URL to 'Authorized domains' in Firebase Console: ${window.location.origin}`;
      }
      
      setAuthError(message);
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleLogout = () => {
    sheetsService.logout();
    setUser(null);
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email || !contactForm.subject || !contactForm.message) {
      alert('Please fill in all fields');
      return;
    }
    setIsSending(true);
    try {
      await contactService.sendMessage(contactForm);
      setSendSuccess(true);
      setContactForm({ name: '', email: '', subject: '', message: '' });
      setTimeout(() => setSendSuccess(false), 5000);
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Failed to send message. Please try again later.');
    } finally {
      setIsSending(false);
    }
  };

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Classes', href: '#classes' },
    { name: 'Subjects', href: '#subjects' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'SM Content', href: '#sm-content' },
    { name: 'About Us', href: '#about' },
    { name: 'FAQ', href: '#faq' },
    { name: 'Contact Us', href: '#contact' },
  ];

  const faqs = siteContent?.faqs || [
    {
      question: "Is the AI Tutor aligned with the West Bengal Board syllabus?",
      answer: "Yes. The AI Tutor is specifically programmed to follow the WBBSE (Class 9-10) and WBCHSE (Class 11-12) syllabus. It focuses on your specific chapters, highlights exam-important concepts, and uses local examples to make learning relevant for West Bengal students."
    },
    {
      question: "What is myaitutorials.com?",
      answer: "myaitutorials.com is an AI-powered educational platform specifically designed for West Bengal Board (WBBSE & WBCHSE) students from Class 9 to 12. It acts as a 24/7 personal tutor, explaining concepts, generating notes, and providing interactive practice."
    },
    {
      question: "Is this platform suitable for both English and Bengali medium students?",
      answer: "Yes! Our AI Tutor is multi-lingual. Students can interact and learn in English, Bengali, or even Hinglish, making it comfortable for everyone to grasp complex topics."
    },
    {
      question: "How does the AI Tutor help with exam preparation?",
      answer: "The AI Tutor provides chapter-wise notes, generates mock tests, creates flashcards for quick revision, and even offers visual aids like AI-generated videos to explain difficult concepts clearly."
    },
    {
      question: "Can parents track their child's progress?",
      answer: "Absolutely. The platform includes a daily goal tracker and session history, allowing parents to see what topics their child has studied and how much time they are spending on their education."
    },
    {
      question: "Is there a free trial or free version available?",
      answer: "We offer a basic tier that allows students to experience the core features of the AI Tutor. For unlimited access, voice interactions, and advanced mock tests, we have affordable premium plans."
    },
    {
      question: "Do I need to download an app to use this?",
      answer: "No, myaitutorials.com is a web-based application. You can access it directly from any browser on your smartphone, tablet, or computer without needing to download anything."
    }
  ];

  const features = [
    { icon: BookOpen, title: "Syllabus Aligned", desc: "Strictly follows WBBSE & WBCHSE curriculum for Classes 9-12." },
    { icon: Clock, title: "24/7 Availability", desc: "No fixed hours. Study anytime, even at 2 AM before an exam." },
    { icon: MessageSquare, title: "Instant Feedback", desc: "No waiting for the next tuition day to get a doubt cleared." },
    { icon: Sparkles, title: "Personalized Pace", desc: "The AI never gets tired of explaining the same concept 10 times." },
  ];

  const classes = [
    { id: '9', name: 'Class IX', desc: 'Foundation for Madhyamik', icon: GraduationCap },
    { id: '10', name: 'Class X', desc: 'Board Exam Intensive', icon: Rocket },
    { id: '11', name: 'Class XI', desc: 'Stream-Specific Core', icon: BookOpen },
    { id: '12', name: 'Class XII', desc: 'HS Final Preparation', icon: Zap },
  ];

  const subjects = [
    { name: 'English', color: 'bg-blue-500' },
    { name: 'Mathematics', color: 'bg-indigo-500' },
    { name: 'Physical Science', color: 'bg-cyan-500' },
    { name: 'Life Science', color: 'bg-emerald-500' },
    { name: 'History', color: 'bg-amber-500' },
    { name: 'Geography', color: 'bg-orange-500' },
    { name: 'Physics', color: 'bg-violet-500' },
    { name: 'Chemistry', color: 'bg-rose-500' },
    { name: 'Biology', color: 'bg-green-500' },
    { name: 'Accountancy', color: 'bg-sky-500' },
    { name: 'Economics', color: 'bg-yellow-500' },
    { name: 'Pol. Science', color: 'bg-red-500' },
  ];

  const pricing = {
    '9': [
      { name: 'Basic', price: '199', features: ['Foundation Concepts', 'Chapter Notes', 'Text Interaction'] },
      { name: 'Most Popular', price: '399', features: ['All Basic Features', 'Voice Interaction', 'Weekly Quizzes'], popular: true },
      { name: 'Pro', price: '599', features: ['All Popular Features', 'Mock Test Access', 'Personalized Roadmap'] },
    ],
    '10': [
      { name: 'Basic', price: '299', features: ['Madhyamik Prep', 'Chapter Notes', 'Text Interaction'] },
      { name: 'Most Popular', price: '599', features: ['All Basic Features', 'Voice Interaction', 'Previous Year Q&A'], popular: true },
      { name: 'Pro', price: '799', features: ['All Popular Features', 'Full Mock Tests', 'Priority AI Support'] },
    ],
    '11': [
      { name: 'Basic', price: '599', features: ['Stream Specific', 'Chapter Notes', 'Text Interaction'] },
      { name: 'Most Popular', price: '799', features: ['All Basic Features', 'Voice Interaction', 'Advanced Concepts'], popular: true },
      { name: 'Pro', price: '999', features: ['All Popular Features', 'Career Guidance', 'Project Support'] },
    ],
    '12': [
      { name: 'Basic', price: '699', features: ['HS Board Intensive', 'Chapter Notes', 'Text Interaction'] },
      { name: 'Most Popular', price: '899', features: ['All Basic Features', 'Voice Interaction', 'Full Syllabus Quiz'], popular: true },
      { name: 'Pro', price: '1099', features: ['All Popular Features', 'Entrance Prep', '24/7 Priority AI'] },
    ],
  };

  const policies = {
    privacy: {
      title: "Privacy Policy",
      content: "We value your privacy. All voice interactions and learning data are used solely to improve your educational experience. We do not sell your data to third parties."
    },
    refund: {
      title: "Refund Policy",
      content: "We offer a 7-day no-questions-asked refund policy. If you are not satisfied with the AI Tutor, you can request a full refund within the first week of your subscription."
    },
    terms: {
      title: "Terms of Service",
      content: "By using myaitutorials.com, you agree to use the platform for educational purposes. Any misuse of the AI or attempts to reverse engineer the system are strictly prohibited."
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#020617] text-slate-900 dark:text-slate-100 selection:bg-cyan-100 transition-colors duration-300">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-[100] bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl border-b border-slate-200/50 dark:border-slate-800/50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <button 
            onClick={scrollToTop}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <span className="font-serif text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-600 dark:from-white dark:to-slate-400">
              myaitutorials.com
            </span>
          </button>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className="text-sm font-semibold text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors"
              >
                {link.name}
              </a>
            ))}
            <div className="flex items-center gap-4">
              <button 
                onClick={onAdminClick}
                className="text-sm font-bold text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 transition-colors flex items-center gap-1"
              >
                <Shield className="w-4 h-4" />
                Admin
              </button>
              {user ? (
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center text-cyan-700 dark:text-cyan-300 font-bold">
                      {user.email?.charAt(0).toUpperCase()}
                    </div>
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300 hidden lg:block">
                      {user.email?.split('@')[0]}
                    </span>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="text-slate-500 hover:text-red-500 transition-colors"
                    title="Log Out"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <>
                  <button 
                    onClick={() => setAuthMode('login')}
                    className="text-sm font-bold text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors"
                  >
                    Login
                  </button>
                  <button 
                    onClick={() => setAuthMode('register')}
                    className="radium-btn radium-btn-cyan px-6 py-2.5 rounded-full text-sm font-bold"
                  >
                    Get Started
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden p-2 text-slate-600 dark:text-slate-400"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu Overlay */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-2xl"
            >
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="block text-lg font-medium text-slate-900 dark:text-white"
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-4 space-y-4">
                <button 
                  onClick={() => { onAdminClick(); setIsMenuOpen(false); }}
                  className="w-full py-4 rounded-2xl font-bold text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-900/50 flex items-center justify-center gap-2"
                >
                  <Shield className="w-5 h-5" />
                  Admin Dashboard
                </button>
                {user ? (
                  <button 
                    onClick={() => { handleLogout(); setIsMenuOpen(false); }}
                    className="w-full py-4 rounded-2xl font-bold text-red-500 border border-red-200 dark:border-red-900/50 flex items-center justify-center gap-2"
                  >
                    <LogOut className="w-5 h-5" />
                    Log Out
                  </button>
                ) : (
                  <>
                    <button 
                      onClick={() => { setAuthMode('login'); setIsMenuOpen(false); }}
                      className="w-full py-4 rounded-2xl font-bold text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700"
                    >
                      Login
                    </button>
                    <button 
                      onClick={() => { setAuthMode('register'); setIsMenuOpen(false); }}
                      className="w-full radium-btn radium-btn-cyan py-4 rounded-2xl font-bold"
                    >
                      Get Started
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main className="pt-20">
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
          {/* Background Image with Overlay */}
          <div className="absolute inset-0 z-0">
            {heroImage ? (
              <motion.img 
                initial={{ scale: 1.1, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 1.5 }}
                src={heroImage} 
                alt="AI Tutor Background" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full bg-slate-900 flex items-center justify-center">
                <RefreshCcw className="w-12 h-12 text-slate-700 animate-spin" />
              </div>
            )}
            
            {/* Admin Background Control */}
            {user?.role === 'admin' && (
              <div className="absolute bottom-8 right-8 z-20">
                <input 
                  type="file" 
                  ref={heroFileInputRef}
                  onChange={handleHeroUpload}
                  accept="image/*"
                  className="hidden"
                />
                <button 
                  onClick={() => heroFileInputRef.current?.click()}
                  className="flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-md border border-white/30 text-white rounded-xl font-bold hover:bg-white/30 transition-all shadow-xl active:scale-95 group"
                  title="Change Hero Background"
                >
                  <ImageIcon className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                  <span className="hidden sm:inline">Change Background</span>
                </button>
              </div>
            )}
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/30 text-white text-sm font-bold mb-8 backdrop-blur-md"
            >
              <Sparkles className="w-4 h-4" />
              Next-Gen AI Home Tuition
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="font-serif text-5xl md:text-8xl font-bold mb-8 tracking-tight leading-[1.1] text-white"
            >
              Your Personal AI Tutor <br className="hidden md:block" />
              for West Bengal Students
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-lg md:text-2xl text-white max-w-3xl mx-auto mb-12 leading-relaxed font-medium"
            >
              Tailored learning for WBBSE & WBCHSE Class 9-12 students. <br className="hidden md:block" />
              Master your subjects with interactive AI guidance, anytime, anywhere.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-6"
            >
              <button 
                onClick={() => setAuthMode('register')}
                className="w-full sm:w-auto radium-btn radium-btn-cyan px-8 py-4 sm:px-12 sm:py-6 rounded-full text-lg sm:text-xl font-bold flex items-center justify-center gap-3 group shadow-2xl shadow-cyan-500/20"
              >
                Start Learning Now
                <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 group-hover:translate-x-1 transition-transform" />
              </button>
              <a 
                href="#pricing"
                className="w-full sm:w-auto bg-white/10 backdrop-blur-md text-white border border-white/20 px-8 py-4 sm:px-12 sm:py-6 rounded-full text-lg sm:text-xl font-bold hover:bg-white/20 transition-all shadow-xl flex items-center justify-center gap-3 active:scale-95"
              >
                View Plans
              </a>
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white dark:bg-slate-900">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 hover:border-cyan-500/30 transition-all group"
                >
                  <div className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <feature.icon className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">{feature.title}</h3>
                  <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">{feature.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Classes Section */}
        <section id="classes" className="py-24 bg-slate-50/50 dark:bg-[#020617]">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-slate-900 dark:text-white mb-4">
                {siteContent?.coverage_text || "Comprehensive Coverage"}
              </h2>
              <p className="text-slate-600 dark:text-slate-400">Tailored learning paths for every stage of your secondary education.</p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {classes.map((cls) => (
                <button 
                  key={cls.id}
                  onClick={() => setSelectedSyllabusClass(cls.id as ClassLevel)}
                  className="p-8 rounded-[2.5rem] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-purple-500/50 hover:shadow-2xl hover:shadow-purple-500/10 transition-all group"
                >
                  <div className="w-14 h-14 rounded-2xl bg-purple-50 dark:bg-purple-900/20 flex items-center justify-center mb-6 group-hover:rotate-6 transition-transform">
                    <cls.icon className="w-7 h-7 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">{cls.name}</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">{cls.desc}</p>
                  <div className="flex items-center gap-2 text-purple-600 dark:text-purple-400 font-bold text-sm">
                    Explore Syllabus <ChevronRight className="w-4 h-4" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Subjects Section */}
        <section id="subjects" className="py-24 bg-slate-900 dark:bg-slate-950 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 blur-[120px] rounded-full" />
          <div className="max-w-7xl mx-auto px-6 relative z-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
              <div>
                <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4">All Major Subjects</h2>
                <p className="text-slate-400 max-w-xl">From Science to Humanities, our AI is trained on the latest WBBSE and WBCHSE curriculum.</p>
              </div>
              <button 
                onClick={() => setAuthMode('register')}
                className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white px-8 py-4 rounded-full font-bold hover:bg-cyan-400 dark:hover:bg-cyan-500 transition-colors"
              >
                Start Learning
              </button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {subjects.map((sub, i) => (
                <div key={i} className="p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-sm flex flex-col items-center gap-4 hover:bg-white/10 dark:hover:bg-white/20 transition-all cursor-default">
                  <div className={`w-3 h-3 rounded-full ${sub.color}`} />
                  <span className="font-bold text-sm text-center">{sub.name}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-24 bg-slate-50/50 dark:bg-[#020617]">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-slate-900 dark:text-white mb-4">Simple, Transparent Pricing</h2>
              <p className="text-slate-600 dark:text-slate-400 mb-4">Invest in your future with affordable monthly plans.</p>
              {siteContent?.pricing && (
                <div className="inline-block px-4 py-2 bg-cyan-100 dark:bg-cyan-900/30 text-cyan-700 dark:text-cyan-300 rounded-full text-sm font-bold mb-10">
                  {siteContent.pricing}
                </div>
              )}
              
              {/* Class Selector for Pricing */}
              <div className="inline-flex p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 mb-12">
                {['9', '10', '11', '12'].map((cls) => (
                  <button
                    key={cls}
                    onClick={() => setSelectedPricingClass(cls as ClassLevel)}
                    className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${selectedPricingClass === cls ? 'bg-white dark:bg-slate-700 text-cyan-600 dark:text-cyan-400 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                  >
                    Class {cls === '9' ? 'IX' : cls === '10' ? 'X' : cls === '11' ? 'XI' : 'XII'}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {pricing[selectedPricingClass].map((plan, i) => (
                <div key={i} className={`glass-card p-8 rounded-[2.5rem] border transition-all relative flex flex-col ${plan.popular ? 'border-cyan-500 shadow-2xl dark:shadow-[0_0_30px_rgba(0,240,255,0.1)] scale-105 z-10 bg-white dark:bg-slate-800' : 'border-slate-200 dark:border-slate-800'}`}>
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-cyan-600 text-white px-4 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">
                      Most Popular
                    </div>
                  )}
                  <div className="mb-6">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-1">{plan.name}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Perfect for Class {selectedPricingClass === '9' ? 'IX' : selectedPricingClass === '10' ? 'X' : selectedPricingClass === '11' ? 'XI' : 'XII'} students</p>
                  </div>
                  
                  <div className="flex items-baseline gap-1 mb-8">
                    <span className="text-4xl font-bold text-slate-900 dark:text-white">₹{plan.price}</span>
                    <span className="text-slate-500 text-sm">/month</span>
                  </div>
                  
                  <ul className="space-y-4 mb-10 flex-1">
                    {plan.features.map((feat, j) => (
                      <li key={j} className="flex items-center gap-3 text-sm text-slate-600 dark:text-slate-400">
                        <CheckCircle2 className="w-4 h-4 text-cyan-500" />
                        {feat}
                      </li>
                    ))}
                  </ul>
                  
                  <button 
                    onClick={() => {
                      setAuthMode('register');
                      setAuthClass(selectedPricingClass);
                    }}
                    className={`w-full py-4 rounded-2xl font-bold text-sm transition-all radium-btn ${plan.popular ? 'radium-btn-cyan' : 'bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-600'}`}
                  >
                    Get Started
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About Us Section */}
        <section id="about" className="py-24 relative overflow-hidden">
          {/* Background Image for About Section */}
          <div className="absolute inset-0 z-0">
            <img 
              src={siteContent?.about_background_url || "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&q=80"} 
              alt="About Background" 
              className={`w-full h-full object-cover ${siteContent?.about_background_url ? 'opacity-20 dark:opacity-10' : 'opacity-10 dark:opacity-5'}`}
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-white via-white/80 to-white dark:from-slate-900 dark:via-slate-900/80 dark:to-slate-900" />
          </div>

          <div className="max-w-7xl mx-auto px-6 relative z-10">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="font-serif text-4xl md:text-5xl font-bold text-slate-900 dark:text-white">Empowering Every Student in West Bengal</h2>
                  
                  {/* Admin About Background Control */}
                  {user?.role === 'admin' && (
                    <div className="ml-4">
                      <input 
                        type="file" 
                        ref={aboutFileInputRef}
                        onChange={handleAboutUpload}
                        accept="image/*"
                        className="hidden"
                      />
                      <button 
                        onClick={() => aboutFileInputRef.current?.click()}
                        className="p-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-all shadow-sm"
                        title="Change Section Background"
                      >
                        <ImageIcon className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>
                <p className="text-lg text-slate-600 dark:text-slate-400 leading-relaxed">
                  <button onClick={scrollToTop} className="font-bold text-cyan-600 dark:text-cyan-400 hover:underline transition-all">myaitutorials.com</button> was born from a simple mission: to make high-quality, personalized education accessible to every student, regardless of their location or financial background.
                </p>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="p-6 rounded-2xl bg-cyan-50 dark:bg-cyan-900/20 border border-cyan-100 dark:border-cyan-800/30">
                    <h4 className="font-bold text-cyan-900 dark:text-cyan-100 mb-2">Our Vision</h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{siteContent?.vision || "To bridge the gap between rural and urban education using cutting-edge AI."}</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-purple-50 dark:bg-purple-900/20 border border-purple-100 dark:border-purple-800/30">
                    <h4 className="font-bold text-purple-900 dark:text-purple-100 mb-2">Our Mission</h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{siteContent?.mission || "Providing 24/7 support to help students excel in their board exams."}</p>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="aspect-square rounded-[3rem] bg-gradient-to-br from-cyan-100 to-purple-100 dark:from-cyan-900/20 dark:to-purple-900/20 flex items-center justify-center p-12">
                  <div className="w-full h-full rounded-[2rem] bg-white dark:bg-slate-800 shadow-2xl flex flex-col items-center justify-center text-center p-8">
                    <div className="w-20 h-20 bg-cyan-600 rounded-full flex items-center justify-center mb-6 shadow-xl shadow-cyan-500/20">
                      <Users className="w-10 h-10 text-white" />
                    </div>
                    <h4 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
                      {siteContent?.students_count_text?.split(' ')[0] || "10,000+"}
                    </h4>
                    <p className="text-slate-500 dark:text-slate-400">
                      {siteContent?.students_count_text?.split(' ').slice(1).join(' ') || "Students Learning Daily"}
                    </p>
                  </div>
                </div>
                <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-purple-600 rounded-3xl flex flex-col items-center justify-center text-white shadow-xl rotate-6">
                  <span className="text-3xl font-bold">98%</span>
                  <span className="text-[10px] font-bold uppercase tracking-widest">Satisfaction</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SM EDU CONTENT Section */}
        <section id="sm-content" className="py-24 bg-white dark:bg-slate-900 overflow-hidden">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Share2 className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
              </div>
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-slate-900 dark:text-white mb-4">SM EDU CONTENT</h2>
              <p className="text-slate-600 dark:text-slate-400 text-lg max-w-2xl mx-auto">
                Stay updated with our latest educational videos and tips across social media platforms.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {(siteContent?.sm_edu_content || []).map((content: any, index: number) => (
                <motion.a
                  key={index}
                  href={content.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="group relative bg-slate-50 dark:bg-slate-800/50 rounded-[2rem] overflow-hidden border border-slate-100 dark:border-slate-700 hover:border-indigo-500/50 hover:shadow-2xl transition-all"
                >
                  <div className="aspect-video relative overflow-hidden">
                    <img 
                      src={content.thumbnail || `https://picsum.photos/seed/${index}/800/450`} 
                      alt={content.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                      <div className="w-12 h-12 bg-white/90 dark:bg-slate-900/90 rounded-full flex items-center justify-center shadow-xl scale-90 group-hover:scale-100 transition-transform">
                        {content.platform === 'YouTube' && <Youtube className="w-6 h-6 text-red-600" />}
                        {content.platform === 'Instagram' && <Instagram className="w-6 h-6 text-pink-600" />}
                        {content.platform === 'Facebook' && <Facebook className="w-6 h-6 text-blue-600" />}
                      </div>
                    </div>
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-black/50 backdrop-blur-md text-white text-[10px] font-bold rounded-full uppercase tracking-widest">
                        {content.platform}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 line-clamp-2 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                      {content.title}
                    </h3>
                    <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold text-sm">
                      Watch Now <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </motion.a>
              ))}
            </div>
            
            {(siteContent?.sm_edu_content || []).length === 0 && (
              <div className="text-center py-12 bg-slate-50 dark:bg-slate-800/50 rounded-[2rem] border-2 border-dashed border-slate-200 dark:border-slate-700">
                <p className="text-slate-500 dark:text-slate-400">No social media content shared yet.</p>
              </div>
            )}
          </div>
        </section>

        {/* FAQ Section */}
        <section id="faq" className="py-24 bg-white dark:bg-slate-900">
          <div className="max-w-4xl mx-auto px-6">
            <div className="text-center mb-16">
              <div className="w-16 h-16 bg-cyan-100 dark:bg-cyan-900/30 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <HelpCircle className="w-8 h-8 text-cyan-600 dark:text-cyan-400" />
              </div>
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-slate-900 dark:text-white mb-4">Frequently Asked Questions</h2>
              <p className="text-slate-600 dark:text-slate-400 text-lg">Everything you need to know about the platform for students and parents.</p>
            </div>
            
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div 
                  key={index} 
                  className={`border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden transition-all ${openFaqIndex === index ? 'bg-slate-50 dark:bg-slate-800/50 shadow-md' : 'bg-white dark:bg-slate-900 hover:border-cyan-500/30'}`}
                >
                  <button 
                    onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
                    className="w-full px-6 py-5 flex items-center justify-between text-left focus:outline-none"
                  >
                    <span className="font-bold text-slate-900 dark:text-white pr-8">{faq.question}</span>
                    <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform duration-300 flex-shrink-0 ${openFaqIndex === index ? 'rotate-180 text-cyan-500' : ''}`} />
                  </button>
                  <AnimatePresence>
                    {openFaqIndex === index && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <div className="px-6 pb-5 text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800/50 pt-4">
                          {faq.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 bg-slate-50/50 dark:bg-[#020617]">
          <div className="max-w-7xl mx-auto px-6">
            <div className="glass-card p-12 rounded-[3rem] bg-slate-900 text-white border-none overflow-hidden relative">
              <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-cyan-500/10 to-purple-500/10 -z-10" />
              <div className="grid lg:grid-cols-2 gap-16">
                <div className="space-y-8">
                  <h2 className="font-serif text-4xl md:text-5xl font-bold">Contact Us</h2>
                  <p className="text-slate-400 text-lg">Have questions? Our team is here to help you on your learning journey.</p>
                  <div className="space-y-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                        <Mail className="w-6 h-6 text-cyan-400" />
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase font-bold tracking-widest">Email Us</p>
                        <a href={`mailto:${siteContent?.email || "support@myaitutorials.com"}`} className="font-bold hover:text-cyan-400 transition-colors">{siteContent?.email || "support@myaitutorials.com"}</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                        <MessageCircle className="w-6 h-6 text-green-400" />
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase font-bold tracking-widest">WhatsApp Us</p>
                        <a href={`https://wa.me/${(siteContent?.mobile_no || "918777385844").replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="font-bold hover:text-green-400 transition-colors">{siteContent?.mobile_no || "+91 8777385844"}</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                        <Phone className="w-6 h-6 text-purple-400" />
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase font-bold tracking-widest">Call Us</p>
                        <a href={`tel:${(siteContent?.mobile_no || "918777385844").replace(/\D/g, '')}`} className="font-bold hover:text-purple-400 transition-colors">{siteContent?.mobile_no || "+91 8777385844"}</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                        <MapPin className="w-6 h-6 text-emerald-400" />
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 uppercase font-bold tracking-widest">Visit Us</p>
                        <p className="font-bold">{siteContent?.address || "Near Albela Hotel, Tospisa, Kolkata-700039"}</p>
                      </div>
                    </div>
                  </div>
                </div>
                <form className="space-y-4" onSubmit={handleContactSubmit}>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <input 
                      type="text" 
                      placeholder="Your Name" 
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      className="bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-cyan-400 transition-colors w-full" 
                      required
                    />
                    <input 
                      type="email" 
                      placeholder="Email Address" 
                      value={contactForm.email}
                      onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                      className="bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-cyan-400 transition-colors w-full" 
                      required
                    />
                  </div>
                  <input 
                    type="text" 
                    placeholder="Subject" 
                    value={contactForm.subject}
                    onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                    className="bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-cyan-400 transition-colors w-full" 
                    required
                  />
                  <textarea 
                    placeholder="Your Message" 
                    rows={4} 
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    className="bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-cyan-400 transition-colors w-full resize-none" 
                    required
                  />
                  <button 
                    type="submit"
                    disabled={isSending}
                    className={`w-full py-5 rounded-2xl font-bold transition-all ${
                      sendSuccess 
                        ? 'bg-emerald-500 text-white' 
                        : 'radium-btn radium-btn-cyan'
                    }`}
                  >
                    {isSending ? 'Sending...' : sendSuccess ? 'Message Sent!' : 'Send Message'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-800 py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="space-y-6">
              <button 
                onClick={scrollToTop}
                className="flex items-center gap-3 hover:opacity-80 transition-opacity"
              >
                <div className="w-8 h-8 bg-cyan-600 rounded-lg flex items-center justify-center">
                  <GraduationCap className="w-5 h-5 text-white" />
                </div>
                <span className="font-serif text-xl font-bold">myaitutorials.com</span>
              </button>
              <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Revolutionizing home tuition in West Bengal with voice-powered AI. Master your board exams with personalized support.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-6">Quick Links</h4>
              <ul className="space-y-4 text-sm text-slate-500 dark:text-slate-400">
                {navLinks.map(link => (
                  <li key={link.name}><a href={link.href} className="hover:text-cyan-600 transition-colors">{link.name}</a></li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6">Policies</h4>
              <ul className="space-y-4 text-sm text-slate-500 dark:text-slate-400">
                <li><button onClick={() => setActivePolicy('privacy')} className="hover:text-cyan-600 transition-colors">Privacy Policy</button></li>
                <li><button onClick={() => setActivePolicy('refund')} className="hover:text-cyan-600 transition-colors">Refund Policy</button></li>
                <li><button onClick={() => setActivePolicy('terms')} className="hover:text-cyan-600 transition-colors">Terms of Service</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6">Newsletter</h4>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Stay updated with the latest syllabus changes.</p>
              <div className="flex gap-2">
                <input type="email" placeholder="Email" className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 text-sm w-full outline-none focus:border-cyan-400" />
                <button className="p-2 bg-cyan-600 text-white rounded-xl hover:bg-cyan-500 transition-colors">
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
          <div className="pt-8 border-t border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-slate-400">© 2026 <button onClick={scrollToTop} className="hover:text-cyan-600 transition-colors">myaitutorials.com</button>. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Policy Modal */}
      <AnimatePresence>
        {activePolicy && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] max-w-2xl w-full shadow-2xl border border-slate-200 dark:border-slate-800"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold">{policies[activePolicy as keyof typeof policies].title}</h3>
                <button 
                  onClick={() => setActivePolicy(null)} 
                  className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
                  title="Return to main page"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed mb-8">
                {policies[activePolicy as keyof typeof policies].content}
              </p>
              <button 
                onClick={() => setActivePolicy(null)}
                className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 py-4 rounded-2xl font-bold"
              >
                Close
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Syllabus Modal */}
      <AnimatePresence>
        {selectedSyllabusClass && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white dark:bg-slate-900 w-full max-w-5xl max-h-[90vh] rounded-[2.5rem] shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col"
            >
              <div className="p-6 sm:p-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/50">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
                    <BookOpen className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Class {selectedSyllabusClass} Syllabus</h2>
                    <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">WBBSE / WBCHSE Curriculum 2026</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedSyllabusClass(null)}
                  className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
                  title="Return to main page"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 sm:p-8 scrollbar-hide">
                {(selectedSyllabusClass === '11' || selectedSyllabusClass === '12') && (
                  <div className="flex gap-2 mb-8 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl w-fit">
                    {['Science', 'Arts', 'Commerce'].map((stream) => (
                      <button
                        key={stream}
                        onClick={() => setSelectedStream(stream)}
                        className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${
                          selectedStream === stream 
                            ? 'bg-white dark:bg-slate-700 text-purple-600 dark:text-purple-400 shadow-sm' 
                            : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                        }`}
                      >
                        {stream}
                      </button>
                    ))}
                  </div>
                )}

                <div className="grid gap-8">
                  {Object.entries(
                    (selectedSyllabusClass === '11' || selectedSyllabusClass === '12')
                      ? (syllabus[selectedSyllabusClass as keyof typeof syllabus] as any)[selectedStream]
                      : (syllabus[selectedSyllabusClass as keyof typeof syllabus] as any)
                  ).map(([subject, chapters]: [string, any]) => (
                    <div key={subject} className="space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-8 bg-purple-500 rounded-full" />
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white">{subject}</h3>
                      </div>
                      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {chapters.map((chapter: any, chapterIndex: number) => (
                          <div 
                            key={`${subject}-${chapter.id || chapterIndex}`}
                            className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 hover:border-purple-500/30 transition-all group"
                          >
                            <h4 className="font-bold text-slate-900 dark:text-white mb-2 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                              {chapter.name}
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {chapter.topics.map((topic: any, topicIndex: number) => (
                                <span key={`${subject}-${chapter.id || chapterIndex}-${topic.id || topicIndex}`} className="text-[10px] px-2 py-1 rounded-md bg-white dark:bg-slate-700 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-600">
                                  {topic.name}
                                </span>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-6 sm:p-8 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex flex-col sm:flex-row items-center justify-between gap-4">
                <p className="text-sm text-slate-500 dark:text-slate-400">Ready to start learning these topics?</p>
                <button 
                  onClick={() => {
                    setAuthMode('register');
                    setAuthClass(selectedSyllabusClass);
                    setSelectedSyllabusClass(null);
                  }}
                  className="w-full sm:w-auto radium-btn radium-btn-cyan px-8 py-3 rounded-full font-bold flex items-center justify-center gap-2"
                >
                  Start Learning Now
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Auth Modal */}
      <AnimatePresence>
        {authMode && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[2.5rem] shadow-2xl border border-slate-200 dark:border-slate-800 p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold">
                  {authMode === 'login' ? 'Welcome Back' : 'Create Account'}
                </h3>
                <button onClick={() => setAuthMode(null)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleAuth} className="space-y-4">
                {authError && (
                  <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-red-600 dark:text-red-400 text-sm flex flex-col gap-2">
                    <p>{authError}</p>
                    {authError.includes("new tab") && (
                      <button
                        type="button"
                        onClick={() => window.open(window.location.href, '_blank')}
                        className="mt-2 px-4 py-2 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 rounded-lg font-medium text-sm hover:bg-red-200 dark:hover:bg-red-900/60 transition-colors self-start"
                      >
                        Open in New Tab
                      </button>
                    )}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Email Address</label>
                  <input 
                    type="email" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 outline-none focus:border-cyan-500 transition-colors"
                    placeholder="you@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Password</label>
                  <input 
                    type="password" 
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 outline-none focus:border-cyan-500 transition-colors"
                    placeholder="••••••••"
                  />
                </div>

                {authMode === 'register' && (
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Your Class</label>
                    <select 
                      value={authClass}
                      onChange={(e) => setAuthClass(e.target.value as ClassLevel)}
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 outline-none focus:border-cyan-500 transition-colors"
                    >
                      <option value="">Select Class</option>
                      <option value="9">Class IX</option>
                      <option value="10">Class X</option>
                      <option value="11">Class XI</option>
                      <option value="12">Class XII</option>
                    </select>
                  </div>
                )}

                <button 
                  type="submit"
                  disabled={isAuthLoading}
                  className="w-full radium-btn radium-btn-cyan py-5 rounded-2xl font-bold flex items-center justify-center gap-2"
                >
                  {isAuthLoading ? (
                    <RefreshCcw className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      {authMode === 'login' ? 'Login' : 'Create Account'}
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>

                <div className="relative my-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-100 dark:border-slate-800"></div>
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white dark:bg-slate-900 px-2 text-slate-400 font-bold tracking-widest">Or continue with</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleGoogleLogin}
                  disabled={isAuthLoading}
                  className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 disabled:opacity-50"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path
                      fill="currentColor"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="currentColor"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="currentColor"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
                    />
                    <path
                      fill="currentColor"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  Google
                </button>

                <p className="text-center text-sm text-slate-500 dark:text-slate-400">
                  {authMode === 'login' ? "Don't have an account?" : "Already have an account?"}
                  <button 
                    type="button"
                    onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
                    className="ml-2 text-cyan-600 dark:text-cyan-400 font-bold hover:underline"
                  >
                    {authMode === 'login' ? 'Sign Up' : 'Login'}
                  </button>
                </p>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
