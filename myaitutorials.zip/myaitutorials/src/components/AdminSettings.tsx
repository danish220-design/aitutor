import React, { useState, useEffect } from 'react';
import { Settings, Save, Loader2, Key, ShieldCheck } from 'lucide-react';
import { sheetsService } from '../services/sheetsService';

export const AdminSettings: React.FC = () => {
  const [apiKey, setApiKey] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const settings = await sheetsService.getAdminSettings();
        setApiKey(settings.gemini_api_key || '');
      } catch (error) {
        console.error("Failed to fetch settings", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setMessage(null);
    try {
      await sheetsService.updateAdminSettings({ gemini_api_key: apiKey });
      setMessage({ text: 'Settings saved successfully!', type: 'success' });
    } catch (error: any) {
      setMessage({ text: error.message || 'Failed to save settings', type: 'error' });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 text-cyan-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Settings className="w-6 h-6 text-cyan-500" />
          <h3 className="text-xl font-bold text-slate-900 dark:text-white">API Configuration</h3>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6 max-w-2xl">
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-500 uppercase tracking-widest">
            <Key className="w-4 h-4" />
            Gemini API Key
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            This key powers the AI Tutor's brain and voice. You can get a free key from 
            <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-cyan-500 hover:underline ml-1">
              Google AI Studio
            </a>.
          </p>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="AI Studio API Key (starts with AIza...)"
            className="w-full px-6 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-cyan-500 outline-none transition-all"
          />
          <div className="flex items-center gap-2 text-[10px] text-amber-600 dark:text-amber-400">
            <ShieldCheck className="w-3 h-3" />
            Stored securely in your local database.
          </div>
        </div>

        {message && (
          <div className={`p-4 rounded-2xl text-sm font-medium ${
            message.type === 'success' ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800' : 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border border-red-100 dark:border-red-800'
          }`}>
            {message.text}
          </div>
        )}

        <button
          type="submit"
          disabled={isSaving}
          className="radium-btn radium-btn-cyan px-8 py-4 rounded-2xl font-bold flex items-center gap-2 disabled:opacity-50"
        >
          {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
          Save Configuration
        </button>
      </form>
    </div>
  );
};
