import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Video, X, Loader2, Sparkles, AlertCircle, PlayCircle, Download } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface VideoGeneratorProps {
  onClose: () => void;
  initialPrompt?: string;
}

export const VideoGenerator: React.FC<VideoGeneratorProps> = ({ onClose, initialPrompt = '' }) => {
  const [prompt, setPrompt] = useState(initialPrompt);
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState<boolean | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('');

  const suggestions = [
    { label: "Photosynthesis", prompt: "A detailed 3D animation showing the process of photosynthesis in a leaf, with sunlight hitting the chlorophyll and oxygen being released." },
    { label: "Volcano Eruption", prompt: "A cross-section view of a volcano erupting, showing the movement of magma from the chamber to the surface and the formation of a lava flow." },
    { label: "Cell Mitosis", prompt: "A microscopic view of a human cell undergoing mitosis, showing the chromosomes aligning and pulling apart into two new nuclei." },
    { label: "Magnetic Fields", prompt: "A slow-motion visualization of a magnet's magnetic field lines interacting with iron filings, showing the invisible forces in action." },
    { label: "Solar System", prompt: "A cinematic fly-through of our solar system, showing the relative sizes and orbits of the planets around the sun." }
  ];

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio && window.aistudio.hasSelectedApiKey) {
        const has = await window.aistudio.hasSelectedApiKey();
        setHasKey(has);
      } else {
        // Fallback if not in AI Studio environment
        setHasKey(!!process.env.API_KEY);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    if (window.aistudio && window.aistudio.openSelectKey) {
      await window.aistudio.openSelectKey();
      // Assume success after triggering
      setHasKey(true);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setError(null);
    setVideoUrl(null);
    setStatusMessage('Initializing video generation...');

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        throw new Error("API key is missing. Please select a paid API key.");
      }

      const ai = new GoogleGenAI({ apiKey });
      
      setStatusMessage('Sending request to Veo model...');
      
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-lite-generate-preview',
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      setStatusMessage('Generating video... This may take a few minutes.');
      
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        setStatusMessage('Still generating... Crafting the perfect visual aid.');
        operation = await ai.operations.getVideosOperation({operation: operation});
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      
      if (!downloadLink) {
        throw new Error("Failed to retrieve video URL from the response.");
      }

      setStatusMessage('Fetching generated video...');

      const response = await fetch(downloadLink, {
        method: 'GET',
        headers: {
          'x-goog-api-key': apiKey,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch video: ${response.statusText}`);
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setVideoUrl(url);
      setStatusMessage('');
    } catch (err: any) {
      console.error("Video generation error:", err);
      if (err.message?.includes("Requested entity was not found")) {
        setError("API key issue. Please re-select your API key.");
        setHasKey(false);
      } else {
        setError(err.message || "An unexpected error occurred during video generation.");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[300] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 md:p-6">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-white dark:bg-slate-900 rounded-[2rem] max-w-3xl w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-100 dark:bg-cyan-900/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold">AI Video Generator</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Create engaging visual aids for your lessons</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
            title="Close video generator"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1">
          {hasKey === false ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h4 className="text-xl font-bold mb-2">API Key Required</h4>
              <p className="text-slate-500 dark:text-slate-400 mb-6 max-w-md mx-auto">
                To generate high-quality videos using the Veo model, you need to provide a paid Google Gemini API key.
              </p>
              <button 
                onClick={handleSelectKey}
                className="px-6 py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-medium transition-colors shadow-lg shadow-cyan-500/25"
              >
                Select API Key
              </button>
              <p className="mt-4 text-xs text-slate-400">
                <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="underline hover:text-cyan-500">
                  Learn more about billing
                </a>
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  What do you want to visualize?
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g., A detailed 3D animation showing the process of photosynthesis in a leaf..."
                  className="w-full h-32 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-cyan-500 outline-none resize-none"
                  disabled={isGenerating}
                />
                
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest w-full mb-1 flex items-center gap-2">
                    <Sparkles className="w-3 h-3 text-cyan-500" />
                    Try these educational prompts:
                  </span>
                  {suggestions.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => setPrompt(s.prompt)}
                      disabled={isGenerating}
                      className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-cyan-900/30 text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 rounded-lg text-xs font-medium transition-all border border-slate-200 dark:border-slate-700 hover:border-cyan-200 dark:hover:border-cyan-800"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {error && (
                <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-red-600 dark:text-red-400 text-sm flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                  <p>{error}</p>
                </div>
              )}

              {isGenerating ? (
                <div className="flex flex-col items-center justify-center py-12 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
                  <Loader2 className="w-10 h-10 text-cyan-500 animate-spin mb-4" />
                  <p className="text-lg font-medium text-slate-700 dark:text-slate-300">{statusMessage}</p>
                  <p className="text-sm text-slate-500 mt-2">This process typically takes 1-3 minutes.</p>
                </div>
              ) : videoUrl ? (
                <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-black relative group">
                  <video 
                    src={videoUrl} 
                    controls 
                    className="w-full aspect-video object-contain"
                    autoPlay
                  />
                  <a 
                    href={videoUrl} 
                    download="generated-visual-aid.mp4"
                    className="absolute top-4 right-4 p-2 bg-black/50 hover:bg-black/70 text-white rounded-lg backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2 text-sm font-medium"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </a>
                </div>
              ) : null}

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl font-medium transition-colors"
                  disabled={isGenerating}
                >
                  Cancel
                </button>
                <button
                  onClick={handleGenerate}
                  disabled={!prompt.trim() || isGenerating}
                  className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-300 dark:disabled:bg-slate-700 disabled:cursor-not-allowed text-white rounded-xl font-medium transition-colors shadow-lg shadow-cyan-500/25 flex items-center gap-2"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      Generate Video
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
