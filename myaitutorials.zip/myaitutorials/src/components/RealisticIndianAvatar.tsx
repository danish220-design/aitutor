import React, { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export type AvatarMood = 'neutral' | 'happy' | 'serious' | 'thinking' | 'encouraging' | 'surprised';

interface RealisticIndianAvatarProps {
  isSpeaking: boolean;
  mood?: AvatarMood;
  isOptimized?: boolean;
}

export const RealisticIndianAvatar: React.FC<RealisticIndianAvatarProps> = ({ 
  isSpeaking, 
  mood = 'neutral',
  isOptimized = false
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoError, setVideoError] = useState(false);
  const [isBlinking, setIsBlinking] = useState(false);
  const [lookOffset, setLookOffset] = useState({ x: 0, y: 0 });

  // Blinking logic
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    let blinkEndTimeoutId: NodeJS.Timeout;
    
    const triggerBlink = () => {
      setIsBlinking(true);
      // Blink duration is very short
      blinkEndTimeoutId = setTimeout(() => setIsBlinking(false), 120);
      
      // Random interval between blinks, more frequent when speaking
      const nextBlinkDelay = isSpeaking 
        ? Math.random() * 2500 + 1500 // 1.5-4s when speaking
        : Math.random() * 6000 + 4000; // 4-10s when idle
        
      timeoutId = setTimeout(triggerBlink, nextBlinkDelay);
    };

    timeoutId = setTimeout(triggerBlink, 2000);
    
    return () => {
      clearTimeout(timeoutId);
      clearTimeout(blinkEndTimeoutId);
    };
  }, [isSpeaking]);

  // Eye movement (saccades) logic
  useEffect(() => {
    if (isOptimized) {
      setLookOffset({ x: 0, y: 0 });
      return;
    }

    let timeoutId: NodeJS.Timeout;
    
    const triggerSaccade = () => {
      // Most of the time look at center, occasionally look away
      // Saccades are more frequent and slightly larger when speaking
      const shouldLookAway = Math.random() > (isSpeaking ? 0.6 : 0.8);
      
      if (shouldLookAway) {
        // Subtle offset: -3 to 3 degrees for X, -1.5 to 1.5 for Y
        const x = (Math.random() - 0.5) * (isSpeaking ? 6 : 4);
        const y = (Math.random() - 0.5) * (isSpeaking ? 3 : 2);
        
        setLookOffset({ x, y });
        
        // Hold the look for a short time (fixation)
        timeoutId = setTimeout(() => {
          setLookOffset({ x: 0, y: 0 });
          scheduleNext();
        }, Math.random() * 1000 + 300);
      } else {
        setLookOffset({ x: 0, y: 0 });
        scheduleNext();
      }
    };

    const scheduleNext = () => {
      const nextDelay = isSpeaking 
        ? Math.random() * 1500 + 500  // 0.5-2s when speaking
        : Math.random() * 4000 + 2000; // 2-6s when idle
      timeoutId = setTimeout(triggerSaccade, nextDelay);
    };

    timeoutId = setTimeout(triggerSaccade, 1000);
    
    return () => clearTimeout(timeoutId);
  }, [isSpeaking, isOptimized]);

  useEffect(() => {
    if (videoRef.current && !videoError) {
      if (isSpeaking && !isOptimized) {
        // Normal speed when speaking to show active hand/neck movements
        videoRef.current.playbackRate = 1.0;
        videoRef.current.play().catch(() => {});
      } else {
        // Slow down significantly when listening or in optimized mode
        // to simulate idle breathing and minimal movement
        videoRef.current.playbackRate = isOptimized ? 0.15 : 0.25;
        videoRef.current.play().catch(() => {});
      }
    }
  }, [isSpeaking, videoError, isOptimized]);

  // Define mood-based styles
  const moodStyles = {
    happy: {
      filter: 'sepia(0.1) saturate(1.3) brightness(1.05)',
      scale: 1.03,
      y: -2,
      rotate: 1,
      glowColor: 'rgba(251, 191, 36, 0.35)', // Warm amber glow
      breathingSpeed: 3.5,
      eyeScale: 1.05
    },
    encouraging: {
      filter: 'sepia(0.05) saturate(1.2) brightness(1.02)',
      scale: 1.02,
      y: -1,
      rotate: 0.5,
      glowColor: 'rgba(245, 158, 11, 0.25)', // Warm orange glow
      breathingSpeed: 4,
      eyeScale: 1.02
    },
    serious: {
      filter: 'contrast(1.15) saturate(0.85) brightness(0.92)',
      scale: 1,
      y: 2,
      rotate: -0.5,
      glowColor: 'rgba(30, 64, 175, 0.2)', // Cool blue glow
      breathingSpeed: 5,
      eyeScale: 0.95
    },
    thinking: {
      filter: 'contrast(1.05) saturate(0.95) brightness(0.98)',
      scale: 1,
      y: 1,
      rotate: -1,
      glowColor: 'rgba(139, 92, 246, 0.2)', // Purple glow
      breathingSpeed: 6,
      eyeScale: 1
    },
    surprised: {
      filter: 'saturate(1.1) brightness(1.1)',
      scale: 1.05,
      y: -4,
      rotate: 0,
      glowColor: 'rgba(255, 255, 255, 0.3)', // White glow
      breathingSpeed: 2.5,
      eyeScale: 1.2
    },
    neutral: {
      filter: 'none',
      scale: 1,
      y: 0,
      rotate: 0,
      glowColor: 'transparent',
      breathingSpeed: 4.5,
      eyeScale: 1
    }
  };

  const currentMoodStyle = moodStyles[mood];

  return (
    <div className="relative w-full h-full rounded-full overflow-hidden bg-slate-50 dark:bg-slate-900 shadow-inner border-2 border-white/80 dark:border-white/20 transition-all duration-700">
      {/* Dynamic Mood Glow */}
      <motion.div 
        className="absolute inset-0 z-10 pointer-events-none"
        animate={{ backgroundColor: currentMoodStyle.glowColor }}
        transition={{ duration: 1 }}
      />
      
      {/* Subtle Eyelid Blink Effect (Top) */}
      <motion.div 
        className="absolute top-0 left-0 w-full z-20 pointer-events-none origin-top bg-black/20"
        initial={{ scaleY: 0 }}
        animate={{ scaleY: isBlinking ? 1 : 0 }}
        transition={{ duration: 0.08, ease: "easeInOut" }}
        style={{ height: '45%' }}
      />
      {/* Subtle Eyelid Blink Effect (Bottom) */}
      <motion.div 
        className="absolute bottom-0 left-0 w-full z-20 pointer-events-none origin-bottom bg-black/20"
        initial={{ scaleY: 0 }}
        animate={{ scaleY: isBlinking ? 1 : 0 }}
        transition={{ duration: 0.08, ease: "easeInOut" }}
        style={{ height: '55%' }}
      />

      {/* Subtle Facial Expression Overlays */}
      <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden">
        {/* Eyebrows Simulation - More nuanced */}
        <motion.div 
          className="absolute top-[37%] left-[27%] w-[20%] h-[4px] bg-black/15 blur-[2px] rounded-full"
          animate={{ 
            y: mood === 'happy' || mood === 'encouraging' ? -6 : mood === 'serious' ? 4 : mood === 'surprised' ? -8 : mood === 'thinking' ? -2 : 0,
            rotate: mood === 'happy' || mood === 'encouraging' ? -8 : mood === 'serious' ? 10 : mood === 'surprised' ? -4 : mood === 'thinking' ? -12 : 0,
            scaleX: mood === 'happy' || mood === 'encouraging' ? 1.15 : mood === 'serious' ? 0.85 : mood === 'surprised' ? 1.2 : 1,
            opacity: mood === 'neutral' ? 0.05 : 0.3
          }}
          transition={{ type: "spring", stiffness: 120, damping: 18 }}
        />
        <motion.div 
          className="absolute top-[37%] right-[27%] w-[20%] h-[4px] bg-black/15 blur-[2px] rounded-full"
          animate={{ 
            y: mood === 'happy' || mood === 'encouraging' ? -6 : mood === 'serious' ? 4 : mood === 'surprised' ? -8 : mood === 'thinking' ? -2 : 0,
            rotate: mood === 'happy' || mood === 'encouraging' ? 8 : mood === 'serious' ? -10 : mood === 'surprised' ? 4 : mood === 'thinking' ? 4 : 0,
            scaleX: mood === 'happy' || mood === 'encouraging' ? 1.15 : mood === 'serious' ? 0.85 : mood === 'surprised' ? 1.2 : 1,
            opacity: mood === 'neutral' ? 0.05 : 0.3
          }}
          transition={{ type: "spring", stiffness: 120, damping: 18 }}
        />

        {/* Eye Widening Simulation */}
        <motion.div 
          className="absolute top-[42%] left-[32%] w-[10%] h-[8%] bg-white/5 blur-[4px] rounded-full"
          animate={{ 
            scale: currentMoodStyle.eyeScale,
            opacity: mood === 'surprised' ? 0.4 : 0
          }}
        />
        <motion.div 
          className="absolute top-[42%] right-[32%] w-[10%] h-[8%] bg-white/5 blur-[4px] rounded-full"
          animate={{ 
            scale: currentMoodStyle.eyeScale,
            opacity: mood === 'surprised' ? 0.4 : 0
          }}
        />

        {/* Mouth Movement Simulation (Talking) - Subtle shadow pulses */}
        <motion.div 
          className="absolute bottom-[28%] left-1/2 -translate-x-1/2 w-[18%] h-[10%] bg-black/10 blur-[6px] rounded-[50%]"
          animate={isSpeaking ? {
            scaleY: [0.8, 1.4, 0.9, 1.3, 0.8],
            scaleX: [1, 1.1, 0.9, 1.05, 1],
            opacity: [0.15, 0.35, 0.2, 0.35, 0.15],
            y: [0, 1.5, -1, 0.8, 0]
          } : {
            scaleY: mood === 'surprised' ? 1.2 : 0.7,
            scaleX: mood === 'happy' || mood === 'encouraging' ? 1.1 : 1,
            opacity: mood === 'surprised' ? 0.2 : 0,
            y: 0
          }}
          transition={isSpeaking ? {
            repeat: Infinity,
            duration: 0.4,
            ease: "easeInOut"
          } : { duration: 0.6 }}
        />

        {/* Mouth Corner Lifts (Happy/Encouraging) */}
        <motion.div 
          className="absolute bottom-[30%] left-[38%] w-[6%] h-[6%] bg-black/5 blur-[4px] rounded-full"
          animate={{ 
            y: mood === 'happy' || mood === 'encouraging' ? -5 : 0,
            x: mood === 'happy' || mood === 'encouraging' ? -3 : 0,
            opacity: mood === 'happy' || mood === 'encouraging' ? 0.25 : 0
          }}
          transition={{ duration: 0.8 }}
        />
        <motion.div 
          className="absolute bottom-[30%] right-[38%] w-[6%] h-[6%] bg-black/5 blur-[4px] rounded-full"
          animate={{ 
            y: mood === 'happy' || mood === 'encouraging' ? -5 : 0,
            x: mood === 'happy' || mood === 'encouraging' ? 3 : 0,
            opacity: mood === 'happy' || mood === 'encouraging' ? 0.25 : 0
          }}
          transition={{ duration: 0.8 }}
        />

        {/* Cheek/Mouth Lift Simulation (Happy/Encouraging) */}
        <motion.div 
          className="absolute bottom-[35%] left-1/2 -translate-x-1/2 w-[40%] h-[15%] bg-white/10 blur-[10px] rounded-[50%]"
          animate={{ 
            scale: mood === 'happy' || mood === 'encouraging' ? 1.15 : 0.9,
            y: mood === 'happy' || mood === 'encouraging' ? -6 : 0,
            opacity: mood === 'happy' || mood === 'encouraging' ? 0.35 : 0
          }}
          transition={{ duration: 0.8 }}
        />

        {/* Brow Furrow Shadow (Serious/Thinking) */}
        <motion.div 
          className="absolute top-[35%] left-1/2 -translate-x-1/2 w-[20%] h-[10%] bg-black/5 blur-[8px] rounded-[50%]"
          animate={{ 
            scaleY: mood === 'serious' ? 1.3 : mood === 'thinking' ? 1.1 : 0.8,
            opacity: mood === 'serious' ? 0.45 : mood === 'thinking' ? 0.25 : 0
          }}
          transition={{ duration: 0.8 }}
        />

        {/* Thinking Eye Direction Simulation */}
        <motion.div 
          className="absolute top-[40%] left-[35%] w-[4%] h-[4%] bg-white/20 blur-[2px] rounded-full"
          animate={{ 
            x: mood === 'thinking' ? -4 : 0,
            y: mood === 'thinking' ? -6 : 0,
            opacity: mood === 'thinking' ? 0.6 : 0
          }}
        />
        <motion.div 
          className="absolute top-[40%] right-[35%] w-[4%] h-[4%] bg-white/20 blur-[2px] rounded-full"
          animate={{ 
            x: mood === 'thinking' ? -4 : 0,
            y: mood === 'thinking' ? -6 : 0,
            opacity: mood === 'thinking' ? 0.6 : 0
          }}
        />
      </div>

      {!videoError ? (
        <motion.div
          className="w-full h-full"
          animate={{ 
            filter: currentMoodStyle.filter,
            scale: isSpeaking 
              ? (isOptimized ? currentMoodStyle.scale * 1.02 : currentMoodStyle.scale * 1.05) 
              : currentMoodStyle.scale,
            y: [currentMoodStyle.y, currentMoodStyle.y + 1, currentMoodStyle.y],
            rotate: isOptimized ? currentMoodStyle.rotate * 0.2 : currentMoodStyle.rotate,
            rotateY: lookOffset.x,
            rotateX: -lookOffset.y,
          }}
          transition={{ 
            filter: { duration: 1.5 },
            scale: { duration: 1.5 },
            rotate: { duration: 1.5 },
            rotateY: { duration: 0.2, ease: "easeOut" },
            rotateX: { duration: 0.2, ease: "easeOut" },
            y: { repeat: Infinity, duration: currentMoodStyle.breathingSpeed, ease: "easeInOut" }
          }}
        >
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            loop
            muted
            playsInline
            onError={() => setVideoError(true)}
            poster="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80"
          >
            {/* Using a high-quality stock video of a professional woman talking on camera to simulate a real AI video feed */}
            <source src="https://assets.mixkit.co/videos/preview/mixkit-portrait-of-a-woman-talking-on-video-call-5150-large.mp4" type="video/mp4" />
          </video>
        </motion.div>
      ) : (
        /* Fallback if video fails to load */
        <motion.img
          src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80"
          alt="Real AI Tutor"
          className="w-full h-full object-cover origin-center"
          animate={
            isSpeaking 
              ? { 
                  scale: isOptimized ? [1.05, 1.06, 1.05] : [1.05, 1.08, 1.05], 
                  y: isOptimized 
                    ? [currentMoodStyle.y, currentMoodStyle.y + 0.5, currentMoodStyle.y]
                    : [currentMoodStyle.y, currentMoodStyle.y - 2, currentMoodStyle.y],
                  filter: currentMoodStyle.filter,
                  rotateY: lookOffset.x,
                  rotateX: -lookOffset.y,
                  rotate: isOptimized ? currentMoodStyle.rotate * 0.2 : currentMoodStyle.rotate,
                } 
              : { 
                  scale: [1.05, 1.06, 1.05], 
                  y: [currentMoodStyle.y, currentMoodStyle.y + 1, currentMoodStyle.y],
                  filter: currentMoodStyle.filter,
                  rotateY: lookOffset.x,
                  rotateX: -lookOffset.y,
                  rotate: isOptimized ? currentMoodStyle.rotate * 0.2 : currentMoodStyle.rotate,
                }
          }
          transition={{ 
            repeat: Infinity, 
            duration: isSpeaking ? 2 : 4, 
            ease: "easeInOut",
            rotateY: { repeat: 0, duration: 0.2 },
            rotateX: { repeat: 0, duration: 0.2 }
          }}
          referrerPolicy="no-referrer"
        />
      )}

      {/* Gradient overlay for text visibility */}
      <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/70 to-transparent pointer-events-none z-20" />
      
      {/* Live Status Indicator */}
      <motion.div 
        className="absolute bottom-5 left-0 right-0 flex justify-center items-center gap-2 z-30"
        animate={{ opacity: isSpeaking ? 1 : 0.7 }}
      >
        <div className={`w-2 h-2 rounded-full ${isSpeaking ? 'bg-cyan-400 animate-pulse shadow-[0_0_10px_rgba(0,240,255,0.8)]' : 'bg-slate-500'}`} />
        <span className="text-white text-[10px] font-bold tracking-wider uppercase drop-shadow-md radium-text-cyan">
          {isSpeaking ? 'Live AI Video' : 'Listening...'}
        </span>
      </motion.div>

      {/* Mood Badge (Subtle) */}
      <AnimatePresence>
        {mood !== 'neutral' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute top-4 right-4 z-40 bg-slate-900/40 backdrop-blur-md px-2 py-0.5 rounded-full border border-cyan-500/30 shadow-[0_0_8px_rgba(0,240,255,0.2)]"
          >
            <span className="text-[8px] text-cyan-400 font-bold uppercase tracking-tighter">
              {mood}
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

