import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, RotateCw, CheckCircle2, ChevronLeft, ChevronRight, Shuffle, Sparkles, GraduationCap } from 'lucide-react';
import { Flashcard } from '../types';

interface FlashcardsProps {
  cards: Flashcard[];
  onClose: () => void;
  topicName?: string;
  subject?: string;
}

export const Flashcards: React.FC<FlashcardsProps> = ({ cards: initialCards, onClose, topicName, subject }) => {
  const [cards, setCards] = useState<Flashcard[]>(initialCards);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [learnedCount, setLearnedCount] = useState(0);

  useEffect(() => {
    setLearnedCount(cards.filter(c => c.isLearned).length);
  }, [cards]);

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % cards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + cards.length) % cards.length);
  };

  const handleShuffle = () => {
    setIsFlipped(false);
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setCurrentIndex(0);
  };

  const toggleLearned = (id: string) => {
    setCards(prev => prev.map(card => 
      card.id === id ? { ...card, isLearned: !card.isLearned } : card
    ));
  };

  const currentCard = cards[currentIndex];

  return (
    <div className="fixed inset-0 z-[250] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/50">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Topic Flashcards</h2>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                {subject} • {topicName || 'General'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="px-8 pt-6">
          <div className="flex justify-between items-end mb-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
              Learning Progress
            </span>
            <span className="text-sm font-bold text-purple-600 dark:text-purple-400">
              {learnedCount} / {cards.length} Learned
            </span>
          </div>
          <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${(learnedCount / cards.length) * 100}%` }}
              className="h-full bg-gradient-to-r from-purple-600 to-cyan-500 rounded-full"
            />
          </div>
        </div>

        {/* Card Area */}
        <div className="flex-1 p-8 flex flex-col items-center justify-center min-h-[300px]">
          <div 
            className="relative w-full max-w-md aspect-[4/3] cursor-pointer perspective-1000"
            onClick={() => setIsFlipped(!isFlipped)}
          >
            <motion.div
              initial={false}
              animate={{ rotateY: isFlipped ? 180 : 0 }}
              transition={{ duration: 0.6, type: "spring", stiffness: 260, damping: 20 }}
              className="w-full h-full preserve-3d"
            >
              {/* Front */}
              <div className="absolute inset-0 backface-hidden bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-[2rem] p-8 flex flex-col items-center justify-center text-center shadow-xl">
                <div className="absolute top-6 left-6 opacity-10">
                  <GraduationCap className="w-12 h-12" />
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white leading-tight">
                  {currentCard.term}
                </h3>
                <p className="mt-6 text-xs font-bold text-purple-500 uppercase tracking-widest animate-pulse">
                  Click to see definition
                </p>
              </div>

              {/* Back */}
              <div 
                className="absolute inset-0 backface-hidden bg-slate-900 dark:bg-slate-950 border-2 border-purple-500/30 rounded-[2rem] p-8 flex flex-col items-center justify-center text-center shadow-xl overflow-y-auto"
                style={{ transform: 'rotateY(180deg)' }}
              >
                <div className="absolute top-6 left-6 opacity-20">
                  <Sparkles className="w-8 h-8 text-purple-400" />
                </div>
                <p className="text-lg sm:text-xl text-slate-100 leading-relaxed">
                  {currentCard.definition}
                </p>
                <div className="mt-8 pt-6 border-t border-white/10 w-full">
                  <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                    Definition / Explanation
                  </p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Card Controls */}
          <div className="mt-8 flex items-center gap-4">
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleLearned(currentCard.id);
              }}
              className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold transition-all ${
                currentCard.isLearned 
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' 
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-600'
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
              {currentCard.isLearned ? 'Learned!' : 'Mark as Learned'}
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsFlipped(!isFlipped);
              }}
              className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-purple-500 transition-all"
              title="Flip Card"
            >
              <RotateCw className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Footer Navigation */}
        <div className="p-8 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={handleShuffle}
              className="p-3 rounded-xl hover:bg-white dark:hover:bg-slate-700 text-slate-400 hover:text-purple-500 transition-all shadow-sm"
              title="Shuffle Cards"
            >
              <Shuffle className="w-5 h-5" />
            </button>
            <span className="text-sm font-bold text-slate-400 ml-2">
              Card {currentIndex + 1} of {cards.length}
            </span>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrev}
              className="p-3 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:text-purple-500 transition-all shadow-sm"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={handleNext}
              className="p-3 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:text-purple-500 transition-all shadow-sm"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
