import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, CheckCircle2, X } from 'lucide-react';
import { ClassLevel } from '../types';

interface SubscriptionModalProps {
  classLevel: ClassLevel;
  onClose: () => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ classLevel, onClose }) => {
  const getPricingPlans = (level: ClassLevel) => {
    switch (level) {
      case '9':
        return [
          { name: 'Basic', price: '₹199', features: ['Unlimited Questions', 'Basic Notes'] },
          { name: 'Most Popular', price: '₹399', features: ['Unlimited Questions', 'Detailed Notes', 'Practice Tests'] },
          { name: 'Pro', price: '₹599', features: ['Everything in Popular', 'Video Generation', 'Priority Support'] }
        ];
      case '10':
        return [
          { name: 'Basic', price: '₹299', features: ['Unlimited Questions', 'Basic Notes'] },
          { name: 'Most Popular', price: '₹599', features: ['Unlimited Questions', 'Detailed Notes', 'Practice Tests'] },
          { name: 'Pro', price: '₹799', features: ['Everything in Popular', 'Video Generation', 'Priority Support'] }
        ];
      case '11':
        return [
          { name: 'Basic', price: '₹599', features: ['Unlimited Questions', 'Basic Notes'] },
          { name: 'Most Popular', price: '₹799', features: ['Unlimited Questions', 'Detailed Notes', 'Practice Tests'] },
          { name: 'Pro', price: '₹999', features: ['Everything in Popular', 'Video Generation', 'Priority Support'] }
        ];
      case '12':
        return [
          { name: 'Basic', price: '₹699', features: ['Unlimited Questions', 'Basic Notes'] },
          { name: 'Most Popular', price: '₹899', features: ['Unlimited Questions', 'Detailed Notes', 'Practice Tests'] },
          { name: 'Pro', price: '₹1099', features: ['Everything in Popular', 'Video Generation', 'Priority Support'] }
        ];
      default:
        return [];
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100] flex items-center justify-center p-4 overflow-y-auto"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="glass-card relative rounded-3xl p-6 sm:p-8 max-w-4xl w-full text-center my-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl"
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
        <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-orange-500/30">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-2">
          Free Trial Ended
        </h2>
        <p className="text-slate-600 dark:text-slate-300 mb-8 max-w-xl mx-auto">
          You've used all your free questions. Upgrade to a paid subscription to continue learning with your AI Tutor for Class {classLevel}.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 text-left">
          {getPricingPlans(classLevel).map((plan, index) => (
            <div 
              key={plan.name} 
              className={`relative p-6 rounded-2xl border ${
                plan.name === 'Most Popular' 
                  ? 'bg-gradient-to-b from-cyan-50 to-white dark:from-cyan-900/20 dark:to-slate-800 border-cyan-400 shadow-xl shadow-cyan-500/10 scale-105 z-10' 
                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
              }`}
            >
              {plan.name === 'Most Popular' && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-[10px] font-bold uppercase tracking-wider py-1 px-3 rounded-full">
                  Most Popular
                </div>
              )}
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-2">{plan.name}</h3>
              <div className="text-3xl font-bold text-slate-900 dark:text-white mb-6">
                {plan.price}<span className="text-sm font-normal text-slate-500 dark:text-slate-400">/mo</span>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <button
                onClick={() => {
                  alert(`Selected ${plan.name} plan for ${plan.price}. Subscription flow would start here.`);
                  onClose();
                }}
                className={`w-full py-2.5 px-4 rounded-xl font-medium transition-all ${
                  plan.name === 'Most Popular'
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/25'
                    : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-900 dark:text-white'
                }`}
              >
                Choose Plan
              </button>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="text-sm text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 transition-colors"
        >
          Maybe Later
        </button>
      </motion.div>
    </motion.div>
  );
};
