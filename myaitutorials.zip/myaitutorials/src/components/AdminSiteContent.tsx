import React, { useState, useEffect, useRef } from 'react';
import { sheetsService } from '../services/sheetsService';
import { Save, Loader2, Globe, Phone, Mail, MapPin, Target, Eye, DollarSign, Image as ImageIcon, Users, Layout, Upload, Sparkles, Youtube, Instagram, Facebook, Share2 } from 'lucide-react';
import { motion } from 'motion/react';

export const AdminSiteContent: React.FC = () => {
  const [content, setContent] = useState<any>({
    pricing: '',
    mobile_no: '',
    vision: '',
    mission: '',
    email: '',
    address: '',
    hero_background_url: '',
    about_background_url: '',
    logo_url: '',
    students_count_text: '',
    coverage_text: ''
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const aboutFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchContent();
  }, []);

  const fetchContent = async () => {
    try {
      const data = await sheetsService.getSiteContent();
      setContent(data);
    } catch (error) {
      console.error('Error fetching site content:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      setMessage({ type: 'error', text: 'File size too large. Please use an image under 2MB.' });
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setContent({ ...content, hero_background_url: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleAboutFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      setMessage({ type: 'error', text: 'File size too large. Please use an image under 2MB.' });
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setContent({ ...content, about_background_url: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    try {
      await sheetsService.updateSiteContent(content);
      setMessage({ type: 'success', text: 'Site content updated successfully!' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update site content.' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <Globe className="w-8 h-8 text-indigo-600" />
          <h2 className="text-2xl font-bold text-gray-900">Website Content Management</h2>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6 bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Contact Us Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              <Phone className="w-5 h-5 text-indigo-500" /> Contact Us Details
            </h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mobile Number</label>
              <input
                type="text"
                value={content.mobile_no}
                onChange={(e) => setContent({ ...content, mobile_no: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                placeholder="+91 8777385844"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              <input
                type="email"
                value={content.email}
                onChange={(e) => setContent({ ...content, email: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                placeholder="support@myaitutorials.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Office Address</label>
              <textarea
                value={content.address}
                onChange={(e) => setContent({ ...content, address: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all h-24"
                placeholder="Full address..."
              />
            </div>
          </div>

          {/* Business Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              <Target className="w-5 h-5 text-indigo-500" /> Business Information
            </h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                <DollarSign className="w-4 h-4" /> Pricing Information
              </label>
              <input
                type="text"
                value={content.pricing}
                onChange={(e) => setContent({ ...content, pricing: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                placeholder="e.g. ₹499/month"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                <Eye className="w-4 h-4" /> Vision
              </label>
              <textarea
                value={content.vision}
                onChange={(e) => setContent({ ...content, vision: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all h-24"
                placeholder="Our long-term vision..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                <Target className="w-4 h-4" /> Mission
              </label>
              <textarea
                value={content.mission}
                onChange={(e) => setContent({ ...content, mission: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all h-24"
                placeholder="Our current mission..."
              />
            </div>
          </div>
        </div>

        {/* Hero Section Customization */}
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 space-y-4">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
            <Layout className="w-5 h-5 text-indigo-500" /> Hero Section Customization
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Logo Image */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" /> Site Logo
                </label>
                <div className="flex flex-col gap-3">
                  <input
                    type="text"
                    value={content.logo_url || ''}
                    onChange={(e) => setContent({ ...content, logo_url: e.target.value })}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                    placeholder="Paste logo image URL here..."
                  />
                </div>
                <p className="text-xs text-slate-500 mt-2">Paste a URL to set the site logo.</p>
              </div>
              {content.logo_url && (
                <div className="mt-2 rounded-xl overflow-hidden border border-gray-200 h-20 w-20 relative group bg-slate-100 flex items-center justify-center">
                  <img 
                    src={content.logo_url} 
                    alt="Logo Preview" 
                    className="max-w-full max-h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" /> Hero Background Image
                </label>
                <div className="flex flex-col gap-3">
                  <input
                    type="text"
                    value={content.hero_background_url}
                    onChange={(e) => setContent({ ...content, hero_background_url: e.target.value })}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                    placeholder="Paste image URL here..."
                  />
                  
                  <div className="flex items-center gap-2">
                    <input 
                      type="file" 
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept="image/*"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition-all"
                    >
                      <Upload className="w-4 h-4" />
                      Upload Image
                    </button>
                  </div>
                </div>
                <p className="text-xs text-slate-500 mt-2">Upload a file or paste a URL to set the background.</p>
              </div>
              {content.hero_background_url && (
                <div className="mt-2 rounded-xl overflow-hidden border border-gray-200 h-40 relative group">
                  <img 
                    src={content.hero_background_url} 
                    alt="Hero Preview" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <p className="text-white text-xs font-bold">Current Hero Background</p>
                  </div>
                </div>
              )}
            </div>

            {/* About Us Background */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" /> About Us Background
                </label>
                <div className="flex flex-col gap-3">
                  <input
                    type="text"
                    value={content.about_background_url}
                    onChange={(e) => setContent({ ...content, about_background_url: e.target.value })}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                    placeholder="Paste image URL here..."
                  />
                  
                  <div className="flex items-center gap-2">
                    <input 
                      type="file" 
                      ref={aboutFileInputRef}
                      onChange={handleAboutFileUpload}
                      accept="image/*"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => aboutFileInputRef.current?.click()}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition-all"
                    >
                      <Upload className="w-4 h-4" />
                      Upload Image
                    </button>
                  </div>
                </div>
                <p className="text-xs text-slate-500 mt-2">Customize the "Empowering Every Student" section background.</p>
              </div>
              {content.about_background_url && (
                <div className="mt-2 rounded-xl overflow-hidden border border-gray-200 h-40 relative group">
                  <img 
                    src={content.about_background_url} 
                    alt="About Preview" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <p className="text-white text-xs font-bold">Current About Background</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Stats and Coverage */}
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 space-y-4">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-500" /> Platform Statistics & Headlines
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                  <Users className="w-4 h-4" /> Students Count Text
                </label>
                <input
                  type="text"
                  value={content.students_count_text}
                  onChange={(e) => setContent({ ...content, students_count_text: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  placeholder="10,000+ Students Learning Daily"
                />
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                  <Target className="w-4 h-4" /> Coverage Text
                </label>
                <input
                  type="text"
                  value={content.coverage_text}
                  onChange={(e) => setContent({ ...content, coverage_text: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  placeholder="Comprehensive Coverage"
                />
              </div>
            </div>
          </div>
        </div>

        {/* SM EDU CONTENT Section */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <Share2 className="w-5 h-5 text-indigo-500" />
            SM EDU CONTENT (Social Media)
          </h3>
          <div className="space-y-4">
            {(content.sm_edu_content || []).map((sm: any, index: number) => (
              <div key={index} className="p-4 border border-gray-200 rounded-xl space-y-3 bg-slate-50/50">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    {sm.platform === 'YouTube' && <Youtube className="w-4 h-4 text-red-600" />}
                    {sm.platform === 'Instagram' && <Instagram className="w-4 h-4 text-pink-600" />}
                    {sm.platform === 'Facebook' && <Facebook className="w-4 h-4 text-blue-600" />}
                    <h4 className="font-bold text-sm text-gray-700">Content #{index + 1}</h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const newContent = [...(content.sm_edu_content || [])];
                      newContent.splice(index, 1);
                      setContent({ ...content, sm_edu_content: newContent });
                    }}
                    className="text-red-500 hover:text-red-700 text-sm font-bold"
                  >
                    Remove
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-500 mb-1">Platform</label>
                    <select
                      value={sm.platform}
                      onChange={(e) => {
                        const newContent = [...(content.sm_edu_content || [])];
                        newContent[index].platform = e.target.value;
                        setContent({ ...content, sm_edu_content: newContent });
                      }}
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm"
                    >
                      <option value="YouTube">YouTube</option>
                      <option value="Instagram">Instagram</option>
                      <option value="Facebook">Facebook</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 mb-1">Title</label>
                    <input
                      type="text"
                      value={sm.title}
                      onChange={(e) => {
                        const newContent = [...(content.sm_edu_content || [])];
                        newContent[index].title = e.target.value;
                        setContent({ ...content, sm_edu_content: newContent });
                      }}
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm"
                      placeholder="Video Title"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-1">URL (Link)</label>
                  <input
                    type="text"
                    value={sm.url}
                    onChange={(e) => {
                      const newContent = [...(content.sm_edu_content || [])];
                      newContent[index].url = e.target.value;
                      setContent({ ...content, sm_edu_content: newContent });
                    }}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm"
                    placeholder="https://youtube.com/..."
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-1">Thumbnail URL</label>
                  <input
                    type="text"
                    value={sm.thumbnail}
                    onChange={(e) => {
                      const newContent = [...(content.sm_edu_content || [])];
                      newContent[index].thumbnail = e.target.value;
                      setContent({ ...content, sm_edu_content: newContent });
                    }}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm"
                    placeholder="https://picsum.photos/..."
                  />
                </div>
              </div>
            ))}
            <button
              type="button"
              onClick={() => {
                const newContent = [...(content.sm_edu_content || []), { platform: 'YouTube', title: '', url: '', thumbnail: '' }];
                setContent({ ...content, sm_edu_content: newContent });
              }}
              className="w-full py-3 border-2 border-dashed border-gray-300 rounded-xl text-gray-500 font-bold hover:border-indigo-500 hover:text-indigo-500 transition-colors"
            >
              + Add Social Media Content
            </button>
          </div>
        </div>

        {/* FAQs Section */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <Eye className="w-5 h-5 text-indigo-500" />
            Frequently Asked Questions
          </h3>
          <div className="space-y-4">
            {(content.faqs || []).map((faq: any, index: number) => (
              <div key={index} className="p-4 border border-gray-200 rounded-xl space-y-3">
                <div className="flex justify-between items-center">
                  <h4 className="font-bold text-sm text-gray-700">FAQ #{index + 1}</h4>
                  <button
                    type="button"
                    onClick={() => {
                      const newFaqs = [...(content.faqs || [])];
                      newFaqs.splice(index, 1);
                      setContent({ ...content, faqs: newFaqs });
                    }}
                    className="text-red-500 hover:text-red-700 text-sm font-bold"
                  >
                    Remove
                  </button>
                </div>
                <input
                  type="text"
                  value={faq.question}
                  onChange={(e) => {
                    const newFaqs = [...(content.faqs || [])];
                    newFaqs[index].question = e.target.value;
                    setContent({ ...content, faqs: newFaqs });
                  }}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  placeholder="Question"
                />
                <textarea
                  value={faq.answer}
                  onChange={(e) => {
                    const newFaqs = [...(content.faqs || [])];
                    newFaqs[index].answer = e.target.value;
                    setContent({ ...content, faqs: newFaqs });
                  }}
                  rows={2}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  placeholder="Answer"
                />
              </div>
            ))}
            <button
              type="button"
              onClick={() => {
                const newFaqs = [...(content.faqs || []), { question: '', answer: '' }];
                setContent({ ...content, faqs: newFaqs });
              }}
              className="w-full py-3 border-2 border-dashed border-gray-300 rounded-xl text-gray-500 font-bold hover:border-indigo-500 hover:text-indigo-500 transition-colors"
            >
              + Add FAQ
            </button>
          </div>
        </div>

        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-4 rounded-xl text-sm ${
              message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
            }`}
          >
            {message.text}
          </motion.div>
        )}

        <div className="flex justify-end pt-4">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-8 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-200"
          >
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            Save Changes
          </button>
        </div>
      </form>
    </div>
  );
};
