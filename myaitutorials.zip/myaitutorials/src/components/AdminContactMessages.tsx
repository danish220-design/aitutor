import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, User, Calendar, Trash2, MessageSquare, ChevronDown, ChevronUp, Search, RefreshCcw } from 'lucide-react';
import { contactService, ContactMessage } from '../services/contactService';

export const AdminContactMessages: React.FC = () => {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    setIsLoading(true);
    try {
      const data = await contactService.getMessages();
      setMessages(data);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this message?')) return;
    try {
      await contactService.deleteMessage(id);
      setMessages(messages.filter(m => m.id !== id));
    } catch (error) {
      console.error('Error deleting message:', error);
      alert('Failed to delete message');
    }
  };

  const filteredMessages = messages.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.message.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (timestamp: any) => {
    if (!timestamp) return 'Just now';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleString();
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <MessageSquare className="w-6 h-6 text-cyan-500" />
            Contact Us Messages
          </h3>
          <p className="text-sm text-slate-500 dark:text-slate-400">View and manage inquiries from your students.</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 sm:flex-none">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search messages..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm outline-none focus:border-cyan-400 w-full md:w-64"
            />
          </div>
          <button 
            onClick={fetchMessages}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-cyan-500 transition-colors flex items-center justify-center"
            title="Refresh messages"
          >
            <RefreshCcw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 space-y-4">
          <RefreshCcw className="w-10 h-10 text-cyan-500 animate-spin" />
          <p className="text-slate-500 font-medium">Loading messages...</p>
        </div>
      ) : filteredMessages.length === 0 ? (
        <div className="text-center py-20 bg-slate-50 dark:bg-slate-800/30 rounded-[2rem] border border-dashed border-slate-200 dark:border-slate-700">
          <Mail className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-4" />
          <p className="text-slate-500 font-medium">No messages found.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredMessages.map((msg) => (
            <div 
              key={msg.id}
              className={`group bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-3xl overflow-hidden transition-all ${expandedId === msg.id ? 'ring-2 ring-cyan-500/20 shadow-xl' : 'hover:border-cyan-500/30'}`}
            >
              <div 
                className="p-6 cursor-pointer flex items-center justify-between gap-4"
                onClick={() => setExpandedId(expandedId === msg.id ? null : msg.id)}
              >
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <div className="w-12 h-12 rounded-2xl bg-slate-50 dark:bg-slate-700 flex items-center justify-center shrink-0">
                    <User className="w-6 h-6 text-slate-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-bold text-slate-900 dark:text-white truncate">{msg.name}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">
                        {formatDate(msg.createdAt).split(',')[0]}
                      </span>
                    </div>
                    <p className="text-sm text-slate-500 dark:text-slate-400 truncate font-medium">{msg.subject}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={(e) => handleDelete(msg.id!, e)}
                    className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors md:opacity-0 group-hover:opacity-100"
                    title="Delete message"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                  {expandedId === msg.id ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                </div>
              </div>

              <AnimatePresence>
                {expandedId === msg.id && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6 pt-2 border-t border-slate-100 dark:border-slate-700/50">
                      <div className="grid md:grid-cols-2 gap-6 mb-6">
                        <div className="space-y-1">
                          <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Email Address</p>
                          <a href={`mailto:${msg.email}`} className="text-sm font-bold text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-2">
                            <Mail className="w-4 h-4" />
                            {msg.email}
                          </a>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Received At</p>
                          <p className="text-sm font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            {formatDate(msg.createdAt)}
                          </p>
                        </div>
                      </div>
                      <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                        <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest mb-3">Message Content</p>
                        <p className="text-slate-600 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
                          {msg.message}
                        </p>
                      </div>
                      <div className="mt-6 flex justify-end">
                        <a 
                          href={`mailto:${msg.email}?subject=Re: ${msg.subject}`}
                          className="px-6 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-bold text-sm hover:scale-105 transition-transform"
                        >
                          Reply via Email
                        </a>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
