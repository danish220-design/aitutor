/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GraduationCap, Languages, BookOpen, ArrowRight, Sparkles, CheckCircle2, X, ChevronRight, ChevronDown, Target } from 'lucide-react';
import { AppState, Language, ClassLevel } from '../types';
import { DailyGoalTracker } from './DailyGoalTracker';

interface SetupViewProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onStart: () => void;
  onBack: () => void;
  completedTopicIds: Set<string>;
  freeQuestionsLeft: number;
  setShowSubscriptionModal: (show: boolean) => void;
  user?: any;
  syllabus: any;
}

export const SetupView: React.FC<SetupViewProps> = ({
  state,
  setState,
  searchQuery,
  setSearchQuery,
  onStart,
  onBack,
  completedTopicIds,
  freeQuestionsLeft,
  setShowSubscriptionModal,
  user,
  syllabus
}) => {
  const [syllabusData, setSyllabusData] = useState<any>(syllabus);
  const [expandedSubjectIds, setExpandedSubjectIds] = useState<Set<string>>(new Set());
  const [expandedChapterIds, setExpandedChapterIds] = useState<Set<string>>(new Set());
  const [showDailyGoalTracker, setShowDailyGoalTracker] = useState(false);

  const toggleSubject = (subjectName: string) => {
    setExpandedSubjectIds(prev => {
      const next = new Set(prev);
      if (next.has(subjectName)) next.delete(subjectName);
      else next.add(subjectName);
      return next;
    });
  };

  const toggleChapter = (chapterId: string) => {
    setExpandedChapterIds(prev => {
      const next = new Set(prev);
      if (next.has(chapterId)) next.delete(chapterId);
      else next.add(chapterId);
      return next;
    });
  };

  useEffect(() => {
    setSyllabusData(syllabus);
  }, [syllabus]);

  const languages: Language[] = ['English', 'Hinglish', 'Bengali'];
  const classes: ClassLevel[] = ['9', '10', '11', '12'];
  
  if (!syllabusData) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-600 dark:text-slate-400 font-medium">Loading syllabus data...</p>
        </div>
      </div>
    );
  }

  const hasStreams = state.classLevel === '11' || state.classLevel === '12';
  const streams = hasStreams ? Object.keys(syllabusData[state.classLevel]) : [];
  const subjects = hasStreams 
    ? (state.stream ? Object.keys(syllabusData[state.classLevel][state.stream]) : [])
    : Object.keys(syllabusData[state.classLevel]);

  const filteredSyllabus = subjects.map(subName => {
    const chapters = hasStreams
      ? (syllabusData[state.classLevel][state.stream!]?.[subName] || [])
      : (syllabusData[state.classLevel][subName] || []);
    
    const filteredChapters = chapters.filter(ch => 
      ch.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ch.topics.some(t => t.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      subName.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return {
      name: subName,
      chapters: filteredChapters
    };
  }).filter(s => s.chapters.length > 0);
  
  // Auto-expand if it matches search query or if it's the selected one
  useEffect(() => {
    if (searchQuery && filteredSyllabus.length > 0) {
      const firstSub = filteredSyllabus[0];
      setExpandedSubjectIds(prev => new Set([...Array.from(prev), firstSub.name]));
      if (firstSub.chapters.length > 0) {
        setExpandedChapterIds(prev => new Set([...Array.from(prev), firstSub.chapters[0].id]));
      }
    } else if (state.subject && state.chapterId && expandedSubjectIds.size === 0) {
      setExpandedSubjectIds(new Set([state.subject]));
      setExpandedChapterIds(new Set([state.chapterId]));
    }
  }, [searchQuery, filteredSyllabus, state.subject, state.chapterId]);

  const selectedChapter = filteredSyllabus.flatMap(s => s.chapters).find(ch => ch.id === state.chapterId);
  const selectedTopic = selectedChapter?.topics.find(t => t.id === state.topicId);

  return (
    <motion.main
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-6xl mx-auto px-6 py-12 md:py-20"
    >
      <header className="mb-12 md:mb-16 text-center relative">
        <div className="absolute left-0 top-0 flex items-center gap-2">
          <button 
            onClick={onBack}
            className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
            title="Return to main page"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="absolute right-0 top-0 flex items-center gap-2">
          <button
            onClick={() => setShowDailyGoalTracker(true)}
            className="flex items-center gap-2 bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-emerald-100 dark:border-emerald-900/30 px-3 py-2 rounded-xl text-xs font-medium text-emerald-600 dark:text-emerald-400 shadow-sm dark:shadow-[0_0_10px_rgba(16,185,129,0.1)] hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors"
            title="Daily Goals"
          >
            <Target className="w-4 h-4" />
            <span className="hidden sm:inline">Daily Goals</span>
          </button>
        </div>
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border border-slate-200 dark:border-cyan-500/30 text-cyan-600 dark:text-cyan-400 text-xs sm:text-sm font-medium mb-6 shadow-sm dark:shadow-[0_0_15px_rgba(0,240,255,0.2)]"
        >
          <Sparkles className="w-4 h-4 text-cyan-500 dark:text-cyan-400" />
          <span className="dark:radium-text-cyan">AI Powered Learning</span>
        </motion.div>
        <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-bold mb-4 tracking-tight leading-tight text-slate-900 dark:text-white dark:radium-text-cyan">
          Setup Your Session
        </h1>
        <p className="text-slate-600 dark:text-slate-400 text-lg sm:text-xl font-medium mb-4">
          Choose your subject and topic to begin
        </p>
      </header>

      <div className="grid lg:grid-cols-3 gap-8 md:gap-10 mb-16">
        <div className="space-y-8 md:space-y-10">
          <section className="glass-card rounded-3xl p-6">
            <div className="flex items-center gap-3 mb-4 md:mb-6">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-900/20 text-blue-500 dark:text-blue-400 flex items-center justify-center shrink-0 shadow-sm">
                <Languages className="w-5 h-5" />
              </div>
              <h2 className="font-display text-xl font-semibold text-slate-800 dark:text-slate-200">Language</h2>
            </div>
            <div className="grid grid-cols-1 gap-2 sm:gap-3">
              {languages.map((lang) => (
                <button
                  key={lang}
                  onClick={() => setState(prev => ({ ...prev, language: lang }))}
                  className={`group relative p-4 rounded-2xl border transition-all text-left min-h-[56px] radium-btn ${
                    state.language === lang
                      ? 'bg-cyan-600 border-cyan-400 text-white shadow-lg dark:shadow-[0_0_20px_rgba(0,240,255,0.3)]'
                      : 'bg-white/40 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 text-slate-600 dark:text-slate-400 hover:border-cyan-500/50 hover:bg-white/80 dark:hover:bg-slate-700/80 hover:text-cyan-600 dark:hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{lang}</span>
                    {state.language === lang && (
                      <motion.div layoutId="lang-check" className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </section>

          <section className="glass-card rounded-3xl p-6">
            <div className="flex items-center gap-3 mb-4 md:mb-6">
              <div className="w-10 h-10 rounded-2xl bg-purple-50 dark:bg-purple-900/20 text-purple-500 dark:text-purple-400 flex items-center justify-center shrink-0 shadow-sm">
                <GraduationCap className="w-5 h-5" />
              </div>
              <h2 className="font-display text-xl font-semibold text-slate-800 dark:text-slate-200">Class</h2>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              {classes.map((cls) => (
                <button
                  key={cls}
                  onClick={() => {
                    const hasNewStreams = cls === '11' || cls === '12';
                    if (hasNewStreams) {
                      const firstStream = Object.keys(syllabusData[cls])[0];
                      const firstSubject = Object.keys(syllabusData[cls][firstStream])[0];
                      setState(prev => ({ ...prev, classLevel: cls, stream: firstStream, subject: firstSubject, chapterId: undefined, topicId: undefined }));
                    } else {
                      const newSubjects = Object.keys(syllabusData[cls]);
                      const newSubject = newSubjects.includes(state.subject || '') ? state.subject : newSubjects[0];
                      setState(prev => ({ ...prev, classLevel: cls, stream: undefined, subject: newSubject, chapterId: undefined, topicId: undefined }));
                    }
                  }}
                  className={`group relative p-4 rounded-2xl border transition-all text-center min-h-[56px] radium-btn ${
                    state.classLevel === cls
                      ? 'bg-purple-600 border-purple-400 text-white shadow-lg dark:shadow-[0_0_20px_rgba(189,0,255,0.3)]'
                      : 'bg-white/40 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 text-slate-600 dark:text-slate-400 hover:border-purple-500/50 hover:bg-white/80 dark:hover:bg-slate-700/80 hover:text-purple-600 dark:hover:text-white'
                  }`}
                >
                  <span className="font-medium text-lg">Class {cls}</span>
                  {state.classLevel === cls && (
                    <motion.div layoutId="class-check" className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white" />
                  )}
                </button>
              ))}
            </div>
          </section>

          {hasStreams && (
            <section className="glass-card rounded-3xl p-6">
              <div className="flex items-center gap-3 mb-4 md:mb-6">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-900/20 text-amber-500 dark:text-amber-400 flex items-center justify-center shrink-0 shadow-sm">
                  <Sparkles className="w-5 h-5" />
                </div>
                <h2 className="font-display text-xl font-semibold text-slate-800 dark:text-slate-200">Stream</h2>
              </div>
              <div className="grid grid-cols-1 gap-2 sm:gap-3">
                {streams.map((str) => {
                  const isSelected = state.stream === str;
                  const colors = {
                    'Science': {
                      active: 'bg-emerald-500 border-emerald-400 text-white shadow-lg dark:shadow-[0_0_20px_rgba(0,255,159,0.3)]',
                      inactive: 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800/30 text-emerald-600 dark:text-emerald-400 hover:border-emerald-500 hover:bg-emerald-100 dark:hover:bg-emerald-900/40',
                    },
                    'Arts': {
                      active: 'bg-pink-500 border-pink-400 text-white shadow-lg dark:shadow-[0_0_20px_rgba(236,72,153,0.3)]',
                      inactive: 'bg-pink-50 dark:bg-pink-900/20 border-pink-100 dark:border-pink-800/30 text-pink-600 dark:text-pink-400 hover:border-pink-500 hover:bg-pink-100 dark:hover:bg-pink-900/40',
                    },
                    'Commerce': {
                      active: 'bg-orange-500 border-orange-400 text-white shadow-lg dark:shadow-[0_0_20px_rgba(249,115,22,0.3)]',
                      inactive: 'bg-orange-50 dark:bg-orange-900/20 border-orange-100 dark:border-orange-800/30 text-orange-600 dark:text-orange-400 hover:border-orange-500 hover:bg-orange-100 dark:hover:bg-orange-900/40',
                    }
                  }[str as keyof typeof colors] || {
                    active: 'bg-amber-500 border-amber-400 text-white shadow-lg',
                    inactive: 'bg-white/40 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 text-slate-600 dark:text-slate-400 hover:border-amber-500/50 hover:bg-white/80 dark:hover:bg-slate-700/80 hover:text-white',
                  };

                  return (
                    <button
                      key={str}
                      onClick={() => {
                        const firstSubject = Object.keys(syllabusData[state.classLevel][str])[0];
                        setState(prev => ({ ...prev, stream: str, subject: firstSubject, chapterId: undefined, topicId: undefined }));
                      }}
                      className={`group relative p-4 rounded-2xl border transition-all text-left min-h-[56px] radium-btn ${
                        isSelected ? colors.active : colors.inactive
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{str}</span>
                        {isSelected && (
                          <motion.div layoutId="stream-check" className="w-2 h-2 rounded-full bg-white" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>
          )}
        </div>

        <section className="lg:col-span-2 glass-card rounded-3xl p-6 flex flex-col">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 flex items-center justify-center shrink-0 shadow-sm">
                <BookOpen className="w-5 h-5" />
              </div>
              <h2 className="font-display text-xl font-semibold text-slate-800 dark:text-slate-200">Select Lesson Topic</h2>
            </div>
            <div className="relative w-full sm:w-auto">
              <input
                type="text"
                placeholder="Search chapters or topics..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-white/80 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-700 rounded-full px-6 py-3 text-sm focus:ring-2 focus:ring-blue-400 focus:border-blue-400 outline-none w-full sm:w-64 shadow-sm transition-all dark:text-slate-200"
              />
            </div>
          </div>

          <div className="flex-1 bg-white/30 dark:bg-slate-900/30 border border-white/40 dark:border-slate-800/40 rounded-2xl p-4 sm:p-6 overflow-y-auto scrollbar-hide min-h-[400px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={`${state.classLevel}-${state.stream || 'none'}-${searchQuery}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                {filteredSyllabus.map((subject) => {
                  const isSubjectExpanded = expandedSubjectIds.has(subject.name);
                  const isSubjectSelected = state.subject === subject.name;
                  
                  return (
                    <div key={subject.name} className="space-y-3">
                      <button
                        onClick={() => toggleSubject(subject.name)}
                        className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all ${
                          isSubjectSelected 
                            ? 'bg-cyan-50 dark:bg-cyan-900/20 border-cyan-400 dark:border-cyan-500 shadow-sm' 
                            : 'bg-white/40 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 hover:border-cyan-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isSubjectSelected ? 'bg-cyan-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}>
                            <BookOpen className="w-4 h-4" />
                          </div>
                          <span className={`font-display font-bold ${isSubjectSelected ? 'text-cyan-700 dark:text-cyan-300' : 'text-slate-700 dark:text-slate-300'}`}>
                            {subject.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{subject.chapters.length} Chapters</span>
                          {isSubjectExpanded ? <ChevronDown className="w-5 h-5 text-slate-400" /> : <ChevronRight className="w-5 h-5 text-slate-400" />}
                        </div>
                      </button>

                      <AnimatePresence>
                        {isSubjectExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="ml-4 space-y-3 border-l-2 border-slate-100 dark:border-slate-800 pl-4"
                          >
                            {subject.chapters.map((chapter) => {
                              const isChapterExpanded = expandedChapterIds.has(chapter.id);
                              const isChapterSelected = state.chapterId === chapter.id;
                              const completedTopicsCount = chapter.topics.filter(t => completedTopicIds.has(t.id)).length;
                              const isChapterCompleted = completedTopicsCount === chapter.topics.length;

                              return (
                                <div key={chapter.id} className="space-y-2">
                                  <button
                                    onClick={() => toggleChapter(chapter.id)}
                                    className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${
                                      isChapterSelected 
                                        ? 'bg-white dark:bg-slate-800 border-cyan-300 dark:border-cyan-700 shadow-sm' 
                                        : 'bg-white/20 dark:bg-slate-800/20 border-transparent hover:bg-white/40 dark:hover:bg-slate-800/40'
                                    }`}
                                  >
                                    <div className="flex items-center gap-3">
                                      {isChapterCompleted ? (
                                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                      ) : (
                                        <div className="w-4 h-4 rounded-full border-2 border-slate-200 dark:border-slate-700" />
                                      )}
                                      <span className={`text-sm font-semibold ${isChapterSelected ? 'text-slate-900 dark:text-white' : 'text-slate-600 dark:text-slate-400'}`}>
                                        {chapter.name}
                                      </span>
                                    </div>
                                    {isChapterExpanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                                  </button>

                                  <AnimatePresence>
                                    {isChapterExpanded && (
                                      <motion.div
                                        initial={{ height: 0, opacity: 0 }}
                                        animate={{ height: 'auto', opacity: 1 }}
                                        exit={{ height: 0, opacity: 0 }}
                                        className="ml-7 grid grid-cols-1 sm:grid-cols-2 gap-2"
                                      >
                                        {chapter.topics.map((topic) => {
                                          const isTopicCompleted = completedTopicIds.has(topic.id);
                                          const isTopicActive = state.topicId === topic.id;

                                          return (
                                            <button
                                              key={topic.id}
                                              onClick={() => setState(prev => ({ ...prev, subject: subject.name, chapterId: chapter.id, topicId: topic.id }))}
                                              className={`flex items-center justify-between p-3 rounded-xl border transition-all text-left ${
                                                isTopicActive
                                                  ? 'bg-cyan-600 border-cyan-400 text-white shadow-md'
                                                  : isTopicCompleted
                                                    ? 'bg-emerald-50/30 dark:bg-emerald-900/10 border-emerald-100 dark:border-emerald-800/30 text-slate-600 dark:text-slate-400'
                                                    : 'bg-white/40 dark:bg-slate-800/40 border-slate-100 dark:border-slate-700/60 text-slate-500 dark:text-slate-500 hover:border-cyan-200 hover:text-cyan-600'
                                              }`}
                                            >
                                              <div className="flex items-center gap-2 overflow-hidden">
                                                {isTopicCompleted && <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 ${isTopicActive ? 'text-white' : 'text-emerald-500'}`} />}
                                                <span className="text-xs font-medium truncate">{topic.name}</span>
                                              </div>
                                              {isTopicActive && <div className="w-1.5 h-1.5 rounded-full bg-white shrink-0" />}
                                            </button>
                                          );
                                        })}
                                      </motion.div>
                                    )}
                                  </AnimatePresence>
                                </div>
                              );
                            })}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
                {filteredSyllabus.length === 0 && (
                  <div className="text-center py-12 text-slate-400 font-medium">
                    No subjects or topics found matching your search.
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </section>
      </div>

      <div className="flex flex-col items-center gap-6 px-4">
        <button
          onClick={onStart}
          className="group w-full sm:w-auto radium-btn radium-btn-cyan px-8 sm:px-12 py-4 sm:py-5 rounded-full text-lg sm:text-xl font-semibold flex items-center justify-center gap-4"
        >
          Start Learning
          <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 transition-transform group-hover:translate-x-2" />
        </button>
        
        {/* Free questions UI removed */}

        {state.topicId && (
          <p className="text-slate-500 dark:text-slate-400 text-sm text-center bg-white/60 dark:bg-slate-800/60 px-6 py-2 rounded-full border border-slate-200 dark:border-slate-700/60 shadow-sm">
            Focusing on: <span className="text-cyan-600 dark:text-cyan-400 font-semibold">{state.stream ? `${state.stream} • ` : ''}{state.subject} • {selectedTopic?.name}</span>
            <br className="sm:hidden" />
            <span className="hidden sm:inline"> from </span>
            <span className="text-cyan-600 dark:text-cyan-400 font-semibold">{selectedChapter?.name}</span>
          </p>
        )}
      </div>
      
      <AnimatePresence>
        {showDailyGoalTracker && (
          <DailyGoalTracker onClose={() => setShowDailyGoalTracker(false)} />
        )}
      </AnimatePresence>
    </motion.main>
  );
};
