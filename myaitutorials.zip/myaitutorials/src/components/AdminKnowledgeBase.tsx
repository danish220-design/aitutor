import React, { useState, useEffect } from 'react';
import { BookOpen, Plus, Trash2, Loader2, Search, Filter, MessageSquare, Mic, Play, Pause } from 'lucide-react';
import { sheetsService } from '../services/sheetsService';
import { syllabus } from '../data/syllabus';

export const AdminKnowledgeBase: React.FC = () => {
  const [items, setItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSubject, setFilterSubject] = useState('All');

  const [newEntry, setNewEntry] = useState({
    question: '',
    answer_text: '',
    answer_audio: '',
    subject: 'English',
    class_level: '10',
    stream: ''
  });

  const [playingId, setPlayingId] = useState<string | null>(null);
  const [audio, setAudio] = useState<HTMLAudioElement | null>(null);

  useEffect(() => {
    fetchKB();
  }, []);

  const fetchKB = async () => {
    try {
      const data = await sheetsService.getKnowledgeBase();
      setItems(data);
    } catch (error) {
      console.error("Failed to fetch KB", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await sheetsService.addToKnowledgeBase(newEntry);
      setNewEntry({ question: '', answer_text: '', answer_audio: '', subject: 'English', class_level: '10', stream: '' });
      setShowAddForm(false);
      await fetchKB();
    } catch (error) {
      console.error("Failed to add to KB", error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this entry?')) return;
    try {
      await sheetsService.deleteFromKnowledgeBase(id);
      await fetchKB();
    } catch (error) {
      console.error("Failed to delete from KB", error);
    }
  };

  const playAudio = (base64: string, id: string) => {
    if (playingId === id) {
      audio?.pause();
      setPlayingId(null);
      return;
    }
    
    if (audio) audio.pause();
    
    const newAudio = new Audio(`data:audio/wav;base64,${base64}`);
    newAudio.onended = () => setPlayingId(null);
    newAudio.play();
    setAudio(newAudio);
    setPlayingId(id);
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = item.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         item.answer_text.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = filterSubject === 'All' || item.subject === filterSubject;
    return matchesSearch && matchesSubject;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 text-cyan-500 animate-spin" />
      </div>
    );
  }

  const getAvailableSubjects = () => {
    const { class_level, stream } = newEntry;
    if (!class_level || !syllabus[class_level as keyof typeof syllabus]) return [];
    
    if (class_level === '11' || class_level === '12') {
      const classData = syllabus[class_level as '11' | '12'];
      if (!stream || !classData[stream as keyof typeof classData]) return [];
      return Object.keys(classData[stream as keyof typeof classData]);
    }
    
    return Object.keys(syllabus[class_level as '9' | '10']);
  };

  const availableSubjects = getAvailableSubjects();

  const allSubjects = Array.from(new Set(
    Object.values(syllabus).flatMap(classData => {
      // Check if it's a class with streams (11, 12)
      if (classData['Science'] || classData['Arts'] || classData['Commerce']) {
        return Object.values(classData).flatMap(streamData => Object.keys(streamData));
      }
      // It's a class without streams (9, 10)
      return Object.keys(classData);
    })
  )).sort();

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <BookOpen className="w-6 h-6 text-cyan-500" />
          <h3 className="text-xl font-bold text-slate-900 dark:text-white">Knowledge Base (FAQ)</h3>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="w-full sm:w-auto radium-btn radium-btn-cyan px-6 py-3 rounded-2xl font-bold flex items-center justify-center gap-2"
        >
          {showAddForm ? 'Cancel' : <><Plus className="w-5 h-5" /> Add New Entry</>}
        </button>
      </div>

      {showAddForm && (
        <form onSubmit={handleAdd} className="p-8 rounded-[2.5rem] bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 space-y-6 animate-in slide-in-from-top duration-300">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">Common Question</label>
              <input
                required
                value={newEntry.question}
                onChange={(e) => setNewEntry({ ...newEntry, question: e.target.value })}
                placeholder="e.g., What is a cell?"
                className="w-full px-6 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-cyan-500 outline-none transition-all"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">Class</label>
                <select
                  value={newEntry.class_level}
                  onChange={(e) => {
                    const newClass = e.target.value;
                    const isHigher = newClass === '11' || newClass === '12';
                    const newStream = isHigher ? 'Science' : '';
                    
                    let newSubject = '';
                    if (isHigher) {
                      newSubject = Object.keys(syllabus[newClass as '11' | '12'][newStream as 'Science'])[0];
                    } else {
                      newSubject = Object.keys(syllabus[newClass as '9' | '10'])[0];
                    }
                    
                    setNewEntry({ ...newEntry, class_level: newClass, stream: newStream, subject: newSubject });
                  }}
                  className="w-full px-6 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-cyan-500 outline-none transition-all"
                >
                  {['9', '10', '11', '12'].map(c => <option key={c} value={c}>Class {c}</option>)}
                </select>
              </div>
              {(newEntry.class_level === '11' || newEntry.class_level === '12') && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">Stream</label>
                  <select
                    value={newEntry.stream}
                    onChange={(e) => {
                      const newStream = e.target.value;
                      const newSubject = Object.keys(syllabus[newEntry.class_level as '11' | '12'][newStream as 'Science' | 'Arts' | 'Commerce'])[0];
                      setNewEntry({ ...newEntry, stream: newStream, subject: newSubject });
                    }}
                    className="w-full px-6 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-cyan-500 outline-none transition-all"
                  >
                    {['Science', 'Arts', 'Commerce'].map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              )}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">Subject</label>
                <select
                  value={newEntry.subject}
                  onChange={(e) => setNewEntry({ ...newEntry, subject: e.target.value })}
                  className="w-full px-6 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-cyan-500 outline-none transition-all"
                >
                  {availableSubjects.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">AI Answer (Text)</label>
            <textarea
              required
              rows={4}
              value={newEntry.answer_text}
              onChange={(e) => setNewEntry({ ...newEntry, answer_text: e.target.value })}
              placeholder="The detailed explanation that the AI should give..."
              className="w-full px-6 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-cyan-500 outline-none transition-all resize-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">AI Answer (Voice Audio Base64 - Optional)</label>
            <textarea
              rows={2}
              value={newEntry.answer_audio}
              onChange={(e) => setNewEntry({ ...newEntry, answer_audio: e.target.value })}
              placeholder="Paste base64 audio string here to reuse a recorded voice..."
              className="w-full px-6 py-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-cyan-500 outline-none transition-all resize-none font-mono text-xs"
            />
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className="radium-btn radium-btn-cyan w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            Save to Knowledge Base
          </button>
        </form>
      )}

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search questions or answers..."
            className="w-full pl-14 pr-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
          />
        </div>
        <div className="flex items-center gap-2 px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
          <Filter className="w-5 h-5 text-slate-400" />
          <select
            value={filterSubject}
            onChange={(e) => setFilterSubject(e.target.value)}
            className="bg-transparent outline-none text-sm font-bold text-slate-600 dark:text-slate-300"
          >
            <option value="All">All Subjects</option>
            {allSubjects.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="grid gap-6">
        {filteredItems.length === 0 ? (
          <div className="text-center py-12 p-8 rounded-[2.5rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
            <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500">No entries found. Add some common questions to save on API costs!</p>
          </div>
        ) : (
          filteredItems.map((item) => (
            <div key={item.id} className="p-8 rounded-[2.5rem] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-cyan-500/50 transition-all group">
              <div className="flex items-start justify-between gap-6">
                <div className="space-y-4 flex-1">
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 rounded-full bg-cyan-50 dark:bg-cyan-900/20 text-[10px] font-bold text-cyan-600 dark:text-cyan-400 uppercase tracking-widest">
                      {item.subject} • Class {item.class_level} {item.stream ? `• ${item.stream}` : ''}
                    </span>
                    <span className="text-[10px] text-slate-400 uppercase tracking-widest">
                      {new Date(item.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <h4 className="text-lg font-bold text-slate-900 dark:text-white leading-snug">
                    {item.question}
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                    {item.answer_text}
                  </p>
                  {item.answer_audio && (
                    <button
                      onClick={() => playAudio(item.answer_audio, item.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs font-bold text-cyan-600 dark:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-900/20 transition-all"
                    >
                      {playingId === item.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      {playingId === item.id ? 'Playing Voice...' : 'Play Recorded Voice'}
                    </button>
                  )}
                </div>
                <button
                  onClick={() => handleDelete(item.id)}
                  className="p-3 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const Save = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v13a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
);
