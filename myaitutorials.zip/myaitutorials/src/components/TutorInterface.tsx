/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, BookOpen, GraduationCap, Languages, ArrowRight, Volume2, VolumeX, Trash2, History, Save, FileText, Sparkles, HelpCircle, Settings, Activity, CheckCircle2, Zap, Video, X, Timer, Loader2, Target, Layers, ChevronDown, ChevronUp, MessageSquare, WifiOff, Download, CloudOff, Menu } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GeminiMiddleGroundService } from '../services/geminiMiddleGround';
import { GoogleGenAI, Type } from "@google/genai";
import Markdown from 'react-markdown';
import { Language, ClassLevel, Flashcard, OfflineStudyPack } from '../types';
import { syllabus } from '../data/syllabus';
import { RealisticIndianAvatar, AvatarMood } from './RealisticIndianAvatar';
import { VideoGenerator } from './VideoGenerator';
import { PomodoroTimer } from './PomodoroTimer';
import { Flashcards } from './Flashcards';
import { VideoGenerationModal } from './VideoGenerationModal';
import { DailyGoalTracker } from './DailyGoalTracker';
import { sheetsService } from '../services/sheetsService';

interface TutorInterfaceProps {
  language: Language;
  classLevel: ClassLevel;
  stream?: string;
  subject: string;
  chapterName?: string;
  topicName?: string;
  onBack: () => void;
  freeQuestionsLeft: number;
  setFreeQuestionsLeft: React.Dispatch<React.SetStateAction<number>>;
  setShowSubscriptionModal: (show: boolean) => void;
  user?: any;
}

export const TutorInterface: React.FC<TutorInterfaceProps> = ({ 
  language, 
  classLevel, 
  stream, 
  subject, 
  chapterName, 
  topicName, 
  onBack,
  freeQuestionsLeft,
  setFreeQuestionsLeft,
  setShowSubscriptionModal,
  user
}) => {
  const [isConnecting, setIsConnecting] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1.0);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [transcription, setTranscription] = useState<string>('');
  const [messages, setMessages] = useState<{ id?: string; text: string; isUser: boolean }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [showTopicSelector, setShowTopicSelector] = useState(true);
  const [showTopicDropdown, setShowTopicDropdown] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showRevisionNotes, setShowRevisionNotes] = useState(false);
  const [showQuestions, setShowQuestions] = useState(false);
  const [showPracticeTest, setShowPracticeTest] = useState(false);
  const [showSpeakingPractice, setShowSpeakingPractice] = useState(false);
  const [showFlashcards, setShowFlashcards] = useState(false);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showQuickSummary, setShowQuickSummary] = useState(false);
  const [showDailyGoalTracker, setShowDailyGoalTracker] = useState(false);
  const [showResponseHistory, setShowResponseHistory] = useState(false);
  const [showOfflinePacks, setShowOfflinePacks] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [isDownloadingPack, setIsDownloadingPack] = useState(false);
  const [offlinePacks, setOfflinePacks] = useState<OfflineStudyPack[]>(() => {
    const saved = localStorage.getItem('tutor_offline_packs');
    return saved ? JSON.parse(saved) : [];
  });
  const [selectedOfflinePack, setSelectedOfflinePack] = useState<OfflineStudyPack | null>(null);
  const [showDownloadToast, setShowDownloadToast] = useState<{ show: boolean; topicName: string }>({ show: false, topicName: '' });
  const [showVideoGenerator, setShowVideoGenerator] = useState(false);
  const [videoPrompt, setVideoPrompt] = useState<string>('');
  const [showTimer, setShowTimer] = useState(false);
  const [showVisualsSuggestion, setShowVisualsSuggestion] = useState(false);
  const [revisionNotes, setRevisionNotes] = useState<string | null>(null);
  const [quickSummary, setQuickSummary] = useState<string | null>(null);
  const [questions, setQuestions] = useState<string | null>(null);
  const [practiceTest, setPracticeTest] = useState<string | null>(null);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [speakingPracticePrompt, setSpeakingPracticePrompt] = useState<string | null>(null);
  const [speakingPracticeAnalysis, setSpeakingPracticeAnalysis] = useState<string | null>(null);
  const [speakingPracticeError, setSpeakingPracticeError] = useState<string | null>(null);
  const [isGeneratingNotes, setIsGeneratingNotes] = useState(false);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [isGeneratingQuestions, setIsGeneratingQuestions] = useState(false);
  const [isGeneratingTest, setIsGeneratingTest] = useState(false);
  const [isGeneratingFlashcards, setIsGeneratingFlashcards] = useState(false);
  const [isAnalyzingSpeaking, setIsAnalyzingSpeaking] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [audioQuality, setAudioQuality] = useState(() => {
    const saved = localStorage.getItem('tutor_audio_quality');
    return saved ? JSON.parse(saved) : {
      sampleRate: 16000,
      label: 'Standard (16kHz)'
    };
  });
  const [mood, setMood] = useState<AvatarMood>('neutral');
  const [isSpeakingModeOptimized, setIsSpeakingModeOptimized] = useState(() => {
    const saved = localStorage.getItem('tutor_speaking_optimized');
    return saved ? JSON.parse(saved) : false;
  });
  const [selectedModel, setSelectedModel] = useState(() => {
    const saved = localStorage.getItem('tutor_selected_model');
    return saved && saved.trim() !== '' ? saved : 'gemini-3-flash-preview';
  });

  // Load settings from Firebase if user is logged in
  useEffect(() => {
    const loadSettings = async () => {
      if (user) {
        try {
          const settings = await sheetsService.getUserSettings(user.uid);
          if (settings.audioQuality) setAudioQuality(settings.audioQuality);
          if (settings.isSpeakingModeOptimized !== undefined) setIsSpeakingModeOptimized(settings.isSpeakingModeOptimized);
          if (settings.selectedModel) setSelectedModel(settings.selectedModel);
        } catch (error) {
          console.error("Error loading user settings from Firebase", error);
        }
      }
    };
    loadSettings();
  }, [user]);

  // Persist settings to localStorage and Firebase
  useEffect(() => {
    localStorage.setItem('tutor_audio_quality', JSON.stringify(audioQuality));
    if (user) {
      sheetsService.saveUserSettings(user.uid, { audioQuality, isSpeakingModeOptimized, selectedModel });
    }
  }, [audioQuality, user]);

  useEffect(() => {
    localStorage.setItem('tutor_speaking_optimized', JSON.stringify(isSpeakingModeOptimized));
    if (user) {
      sheetsService.saveUserSettings(user.uid, { audioQuality, isSpeakingModeOptimized, selectedModel });
    }
  }, [isSpeakingModeOptimized, user]);

  useEffect(() => {
    localStorage.setItem('tutor_selected_model', selectedModel);
    if (user) {
      sheetsService.saveUserSettings(user.uid, { audioQuality, isSpeakingModeOptimized, selectedModel });
    }
  }, [selectedModel, user]);

  useEffect(() => {
    localStorage.setItem('tutor_offline_packs', JSON.stringify(offlinePacks));
  }, [offlinePacks]);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Detect mood from the last AI message with enhanced sentiment analysis
  useEffect(() => {
    const lastAiMessage = [...messages].reverse().find(m => !m.isUser);
    
    // If AI is currently generating or connecting, show thinking mood
    if (isConnecting || isGeneratingNotes || isGeneratingSummary || isGeneratingQuestions || isGeneratingTest || isGeneratingFlashcards || isAnalyzingSpeaking) {
      setMood('thinking');
      return;
    }

    if (lastAiMessage) {
      const text = lastAiMessage.text.toLowerCase();
      
      // Keywords for happy mood (pure joy/celebration)
      const happyKeywords = [
        '😊', 'awesome', 'wonderful', 'congratulations', 'fantastic', 
        'brilliant', 'bravo', 'cheers', 'proud', 'amazing', 'superb',
        'celebrate', 'victory', 'success', 'excellent news'
      ];

      // Keywords for encouraging mood (supportive/guiding)
      const encouragingKeywords = [
        'great', 'excellent', 'good', 'happy', 'welcome', 'well done', 'perfect', 
        'nice', 'spot on', 'exactly', 'correct', 'keep it up', 'keep going',
        'you can do it', 'almost there', 'good job', 'helpful', 'support',
        'don\'t worry', 'easy', 'simple', 'clear', 'understand'
      ];
      
      // Keywords for serious/focused/complex mood
      const seriousKeywords = [
        'important', 'careful', 'note', 'complex', 'difficult', 'warning', 
        'attention', 'focus', 'remember', 'critical', 'danger', 'essential',
        'fundamental', 'crucial', 'significant', 'detailed', 'rigorous',
        'precise', 'technical', 'advanced', 'theory', 'mechanism', 'process',
        'structure', 'function', 'analyze', 'examine', 'consider', 'law',
        'principle', 'definition', 'exam', 'board', 'marks', 'score'
      ];

      // Keywords for surprised mood
      const surprisedKeywords = [
        'wow', 'unbelievable', 'really', 'unexpected', 'surprising', 'curious',
        'interesting!', 'oh!', 'wait', 'did you know', 'actually'
      ];

      // Check for surprised sentiment (including punctuation)
      if (surprisedKeywords.some(k => text.includes(k)) || text.includes('!!!') || text.includes('?!!')) {
        setMood('surprised');
      }
      // Check for happy sentiment
      else if (happyKeywords.some(k => text.includes(k))) {
        setMood('happy');
      } 
      // Check for encouraging sentiment
      else if (encouragingKeywords.some(k => text.includes(k))) {
        setMood('encouraging');
      }
      // Then check for serious/complex sentiment
      // Also consider long, detailed explanations as 'serious'
      else if (seriousKeywords.some(k => text.includes(k)) || (text.length > 200 && text.split(' ').length > 35)) {
        setMood('serious');
      } 
      // Default to neutral
      else {
        setMood('neutral');
      }
    } else {
      setMood('neutral');
    }
  }, [messages, isConnecting, isGeneratingNotes, isGeneratingSummary, isGeneratingQuestions, isGeneratingTest, isGeneratingFlashcards, isAnalyzingSpeaking]);
  // Reset mood to neutral after AI stops speaking for a short duration
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    if (!isAiSpeaking) {
      timeoutId = setTimeout(() => {
        setMood('neutral');
      }, 3000); // 3 seconds after speaking ends
    }
    return () => clearTimeout(timeoutId);
  }, [isAiSpeaking]);

  const [showSettings, setShowSettings] = useState(false);
  const [topicSearchQuery, setTopicSearchQuery] = useState('');
  const [collapsedChapters, setCollapsedChapters] = useState<Set<string>>(new Set());

  const toggleChapter = (chapterId: string) => {
    setCollapsedChapters(prev => {
      const newSet = new Set(prev);
      if (newSet.has(chapterId)) {
        newSet.delete(chapterId);
      } else {
        newSet.add(chapterId);
      }
      return newSet;
    });
  };
  
  const hasStreams = classLevel === '11' || classLevel === '12';
  const selectedSyllabus = hasStreams && stream 
    ? (syllabus[classLevel][stream][subject] || [])
    : (syllabus[classLevel][subject] || []);

  const [activeChapterId, setActiveChapterId] = useState<string | undefined>(
    selectedSyllabus.find(ch => ch.name === chapterName)?.id
  );
  const [activeTopicId, setActiveTopicId] = useState<string | undefined>(
    selectedSyllabus.find(ch => ch.name === chapterName)?.topics.find(t => t.name === topicName)?.id
  );
  const [activeSubject, setActiveSubject] = useState<string>(subject);
  
  const serviceRef = useRef<GeminiMiddleGroundService | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const currentChapter = selectedSyllabus.find(ch => ch.id === activeChapterId);
  const currentTopic = currentChapter?.topics.find(t => t.id === activeTopicId);

  const filteredSyllabus = selectedSyllabus.map(chapter => {
    const filteredTopics = chapter.topics.filter(topic => 
      topic.name.toLowerCase().includes(topicSearchQuery.toLowerCase()) ||
      chapter.name.toLowerCase().includes(topicSearchQuery.toLowerCase())
    );
    return { ...chapter, topics: filteredTopics };
  }).filter(chapter => chapter.topics.length > 0);

  useEffect(() => {
    const service = new GeminiMiddleGroundService(
      (text, isUser) => {
        if (isUser) {
          const lowerText = text.toLowerCase();
          if (lowerText.includes('open settings') || lowerText.includes('tutor settings')) {
            setShowSettings(true);
          }
          
          setFreeQuestionsLeft(prev => {
            const newCount = Math.max(0, prev - 1);
            if (newCount === 0) {
              setShowSubscriptionModal(true);
              setIsListening(false);
              serviceRef.current?.setMicMute(true);
            }
            return newCount;
          });
        }
        if (!isUser) {
          const lowerText = text.toLowerCase();
          if (lowerText.includes('visuals button') || lowerText.includes('click the visuals') || lowerText.includes('visual aid')) {
            setShowVisualsSuggestion(true);
            // Auto-hide after 10 seconds
            setTimeout(() => setShowVisualsSuggestion(false), 10000);
          }
        }
        setMessages(prev => [...prev, { id: crypto.randomUUID(), text, isUser }]);
      },
      (isPlaying) => {
        setIsAiSpeaking(isPlaying);
      }
    );
    serviceRef.current = service;

    const startSession = async () => {
      if (isOffline) {
        setIsConnecting(false);
        setIsConnected(false);
        return;
      }
      setError(null);
      setIsConnecting(true);
      try {
        await service.connect(language, classLevel, activeSubject, currentChapter?.name, currentTopic?.name, selectedModel);
        setIsConnected(true);
        setIsConnecting(false);
        
        // Add initial greeting if no messages
        if (messages.length === 0) {
          const greeting = `Hello! I'm your ${activeSubject} tutor. I'm ready to help you with ${currentTopic?.name || 'your studies'}. What would you like to learn about?`;
          setMessages([{ id: crypto.randomUUID(), text: greeting, isUser: false }]);
        }
        if (freeQuestionsLeft > 0) {
          setIsListening(true);
        } else {
          setIsListening(false);
          service.setMicMute(true);
          setShowSubscriptionModal(true);
        }
        // Apply initial volume/mute settings
        service.setVolume(volume);
        service.setMute(isMuted);
        service.setMicMute(false);
      } catch (error: any) {
        console.error("Failed to connect to Gemini service:", error);
        setIsConnecting(false);
        setError("Failed to connect to the tutor. Please check your API key in Admin Settings.");
      }
    };

    startSession();

    return () => {
      service.disconnect();
    };
  }, [language, classLevel, activeSubject, activeChapterId, activeTopicId, selectedModel]);

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isOffline) return;
    
    if (freeQuestionsLeft <= 0) {
      setShowSubscriptionModal(true);
      return;
    }

    const lowerText = chatInput.toLowerCase();
    if (lowerText.includes('open settings') || lowerText.includes('tutor settings')) {
      setShowSettings(true);
    }
    
    setFreeQuestionsLeft(prev => {
      const newCount = Math.max(0, prev - 1);
      if (newCount === 0) {
        setShowSubscriptionModal(true);
        setIsListening(false);
        serviceRef.current?.setMicMute(true);
      }
      return newCount;
    });

    setMessages(prev => [...prev, { id: crypto.randomUUID(), text: chatInput, isUser: true }]);
    serviceRef.current?.handleUserMessage(chatInput);
    setChatInput('');
  };

  const toggleListening = () => {
    if (isOffline) return;
    if (freeQuestionsLeft <= 0) {
      setShowSubscriptionModal(true);
      return;
    }
    const newListening = !isListening;
    setIsListening(newListening);
    serviceRef.current?.setMicMute(!newListening);
  };

  const toggleMute = () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    serviceRef.current?.setMute(newMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    serviceRef.current?.setVolume(newVolume);
  };

  const [historyList, setHistoryList] = useState<any[]>([]);

  const fetchHistory = async () => {
    if (user) {
      try {
        const sessions = await sheetsService.getSessions(user.uid);
        setHistoryList(sessions.sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
      } catch (error) {
        console.error("Error fetching history from Sheets", error);
      }
    } else {
      const index = JSON.parse(localStorage.getItem('tutor_history_index') || '[]');
      const localHistory = index.map((key: string) => {
        const data = localStorage.getItem(`tutor_session_${key}`);
        return data ? JSON.parse(data).metadata : null;
      }).filter(Boolean).sort((a: any, b: any) => b.timestamp - a.timestamp);
      setHistoryList(localHistory);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [user]);

  const clearChat = async () => {
    setMessages([]);
    if (activeChapterId && activeTopicId && currentTopic) {
      if (user) {
        try {
          await sheetsService.deleteSession(user.uid, currentTopic.name);
          fetchHistory();
        } catch (error) {
          console.error("Error deleting session from Sheets", error);
        }
      } else {
        localStorage.removeItem(`tutor_session_${classLevel}_${activeChapterId}_${activeTopicId}`);
        fetchHistory();
      }
    }
  };

  // Auto-save messages
  useEffect(() => {
    const saveSession = async () => {
      if (messages.length > 0 && activeChapterId && activeTopicId && currentTopic && currentChapter) {
        const sessionData = {
          uid: user?.uid || 'anonymous',
          classLevel,
          language,
          subject: activeSubject,
          chapterId: activeChapterId,
          chapterName: currentChapter.name,
          topicId: activeTopicId,
          topicName: currentTopic.name,
          messages
        };

        if (user) {
          try {
            await sheetsService.saveSession(sessionData);
          } catch (error) {
            console.error("Error saving session to Sheets", error);
          }
        } else {
          const localData = {
            messages,
            metadata: {
              classLevel,
              chapterId: activeChapterId,
              chapterName: currentChapter.name,
              topicId: activeTopicId,
              topicName: currentTopic.name,
              language,
              timestamp: Date.now()
            }
          };
          localStorage.setItem(`tutor_session_${classLevel}_${activeChapterId}_${activeTopicId}`, JSON.stringify(localData));
          
          const historyIndex = JSON.parse(localStorage.getItem('tutor_history_index') || '[]');
          const sessionKey = `${classLevel}_${activeChapterId}_${activeTopicId}`;
          if (!historyIndex.includes(sessionKey)) {
            localStorage.setItem('tutor_history_index', JSON.stringify([...historyIndex, sessionKey]));
          }
        }
      }
    };
    saveSession();
  }, [messages, activeChapterId, activeTopicId, classLevel, currentChapter, currentTopic, language, user, activeSubject]);

  const loadSavedSession = async (sessionKey: string) => {
    if (user) {
      try {
        const sessions = await sheetsService.getSessions(user.uid);
        const session = sessions.find((s: any) => `${s.classLevel}_${s.chapterId}_${s.topicId}` === sessionKey) as any;
        if (session) {
          setMessages(session.messages.map((m: any) => ({ ...m, id: m.id || crypto.randomUUID() })));
          setActiveChapterId(session.chapterId);
          setActiveTopicId(session.topicId);
          setShowHistory(false);
        }
      } catch (error) {
        console.error("Error loading session from Sheets", error);
      }
    } else {
      const savedData = localStorage.getItem(`tutor_session_${sessionKey}`);
      if (savedData) {
        const { messages: savedMessages, metadata } = JSON.parse(savedData);
        setMessages(savedMessages.map((m: any) => ({ ...m, id: m.id || crypto.randomUUID() })));
        setActiveChapterId(metadata.chapterId);
        setActiveTopicId(metadata.topicId);
        setShowHistory(false);
      }
    }
  };

  const completedTopicIds = new Set(historyList.map((h: any) => h.topicId));

  const generateRevisionNotes = async () => {
    if (!currentTopic || !currentChapter) return;
    
    setIsGeneratingNotes(true);
    setShowRevisionNotes(true);
    setRevisionNotes(null);

    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: `Generate Exam Revision Notes.
        
Payload Details:
- Class: ${classLevel}
- Subject: ${subject}
- Chapter: ${currentChapter.name}
- Topic: ${currentTopic.name}
- Language: ${language}
- Mode: Revision Notes Generation

Style Guidelines:
- Use a clear structure: Introduction, Key Points, and Summary.
- Highlight important keywords and definitions.
- Use a point-wise format suitable for school exams.
- Keep it concise, memory-friendly, and useful for quick revision.
- Include important formulas or diagrams descriptions (if applicable).
- Format the output in clean Markdown.
- IMPORTANT FORMATTING RULES:
  - Use rich Markdown formatting to improve readability.
  - Use bulleted or numbered lists for steps, features, or multiple points.
  - Use code blocks (\`\`\`) for any code snippets, formulas, or structured data.
  - Use bold text for emphasis on key terms.`,
      });
      
      setRevisionNotes(response.text || "Failed to generate notes.");
    } catch (error) {
      console.error("Error generating revision notes:", error);
      setRevisionNotes("Sorry, I couldn't generate the revision notes at this time. Please try again later.");
    } finally {
      setIsGeneratingNotes(false);
    }
  };

  const generateQuickSummary = async () => {
    if (!currentTopic || !currentChapter) return;
    
    setIsGeneratingSummary(true);
    setShowQuickSummary(true);
    setQuickSummary(null);

    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: `Generate a Quick 1-minute Summary.
        
Topic: ${currentTopic.name}
Chapter: ${currentChapter.name}
Subject: ${subject}
Class: ${classLevel}
Language: ${language}

Task:
- Summarize the core concept in exactly 3-5 bullet points.
- Use simple language suitable for quick reading.
- Focus on what's most likely to be asked in exams.
- Format the output in clean Markdown.
- IMPORTANT FORMATTING RULES:
  - Use rich Markdown formatting to improve readability.
  - Use bulleted or numbered lists for steps, features, or multiple points.
  - Use code blocks (\`\`\`) for any code snippets, formulas, or structured data.
  - Use bold text for emphasis on key terms.`,
      });
      
      setQuickSummary(response.text || "Failed to generate summary.");
    } catch (error) {
      console.error("Error generating quick summary:", error);
      setQuickSummary("Sorry, I couldn't generate the summary at this time. Please try again later.");
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  const generateQuestions = async () => {
    if (!currentTopic || !currentChapter) return;
    
    setIsGeneratingQuestions(true);
    setShowQuestions(true);
    setQuestions(null);

    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: `Generate Important Exam Questions.
        
Payload Details:
- Class: ${classLevel}
- Subject: ${subject}
- Chapter: ${currentChapter.name}
- Topic: ${currentTopic.name}
- Language: ${language}
- Mode: Question Generation

Style Guidelines:
- Use proper West Bengal Board marks-friendly format (e.g., 2+3, 1+4).
- Include:
  - 5 short questions (1-2 marks)
  - 3 medium questions (3-5 marks)
  - 2 long questions (6+ marks)
- Provide model answer structures or key points for each question.
- Keep them syllabus-focused and relevant for board exams.
- Format the output in clean Markdown.
- IMPORTANT FORMATTING RULES:
  - Use rich Markdown formatting to improve readability.
  - Use bulleted or numbered lists for steps, features, or multiple points.
  - Use code blocks (\`\`\`) for any code snippets, formulas, or structured data.
  - Use bold text for emphasis on key terms.`,
      });
      
      setQuestions(response.text || "Failed to generate questions.");
    } catch (error) {
      console.error("Error generating questions:", error);
      setQuestions("Sorry, I couldn't generate the questions at this time. Please try again later.");
    } finally {
      setIsGeneratingQuestions(false);
    }
  };

  const downloadHtmlPack = (pack: OfflineStudyPack) => {
    const simpleMarkdownToHtml = (md: string) => {
      let html = md
        .replace(/^### (.*$)/gim, '<h3>$1</h3>')
        .replace(/^## (.*$)/gim, '<h2>$1</h2>')
        .replace(/^# (.*$)/gim, '<h1>$1</h1>')
        .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/gim, '<em>$1</em>')
        .replace(/\n\n/gim, '</p><p>')
        .replace(/\n/gim, '<br>');
      return `<p>${html}</p>`;
    };

    const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${pack.topicName} - Offline Study Pack</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 20px; color: #333; background: #f8fafc; }
    .container { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
    h1 { color: #4f46e5; margin-top: 0; }
    h2 { color: #4338ca; border-bottom: 2px solid #e0e7ff; padding-bottom: 8px; margin-top: 30px; }
    h3 { color: #3730a3; }
    .qa-card { background: #f1f5f9; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 16px; }
    .question { font-weight: bold; color: #1e293b; margin-top: 0; font-size: 1.1em; }
    .answer { color: #475569; margin-bottom: 0; }
    .meta { color: #64748b; font-size: 0.9em; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 20px; }
    .footer { margin-top: 40px; text-align: center; color: #94a3b8; font-size: 0.8em; }
  </style>
</head>
<body>
  <div class="container">
    <div class="meta">${subject} • Class ${classLevel} • ${pack.chapterName}</div>
    <h1>${pack.topicName}</h1>
    
    <h2>Explanation</h2>
    <div class="explanation">
      ${simpleMarkdownToHtml(pack.explanation)}
    </div>

    <h2>Questions & Answers</h2>
    ${pack.qa.map(item => `
      <div class="qa-card">
        <p class="question">Q: ${item.question}</p>
        <p class="answer">A: ${simpleMarkdownToHtml(item.answer)}</p>
      </div>
    `).join('')}
    
    <div class="footer">
      Generated by myaitutorials.com • Downloaded on ${new Date().toLocaleDateString()}
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pack.topicName.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_study_pack.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadSpecificStudyPack = async (chapter: any, topic: any) => {
    if (!topic || !chapter) return;
    
    setIsDownloadingPack(true);
    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY! });
      
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: `Create an Offline Study Pack for:
Topic: ${topic.name}
Chapter: ${chapter.name}
Subject: ${subject}
Class: ${classLevel}
Language: ${language}

Task:
1. Provide a comprehensive explanation of the topic (approx 500 words).
2. Provide 5 important Questions and their detailed Answers.

Format the response as a JSON object with this structure:
{
  "explanation": "markdown string",
  "qa": [
    { "question": "string", "answer": "string" }
  ]
}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              explanation: { type: Type.STRING },
              qa: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    answer: { type: Type.STRING }
                  },
                  required: ["question", "answer"]
                }
              }
            },
            required: ["explanation", "qa"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      const newPack: OfflineStudyPack = {
        topicId: topic.id,
        topicName: topic.name,
        chapterName: chapter.name,
        explanation: data.explanation || "No explanation provided.",
        qa: data.qa || [],
        timestamp: Date.now()
      };

      setOfflinePacks(prev => {
        const filtered = prev.filter(p => p.topicId !== newPack.topicId);
        return [...filtered, newPack];
      });

      // Generate standalone HTML file for true offline access
      const simpleMarkdownToHtml = (md: string) => {
        let html = md
          .replace(/^### (.*$)/gim, '<h3>$1</h3>')
          .replace(/^## (.*$)/gim, '<h2>$1</h2>')
          .replace(/^# (.*$)/gim, '<h1>$1</h1>')
          .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
          .replace(/\*(.*?)\*/gim, '<em>$1</em>')
          .replace(/\n\n/gim, '</p><p>')
          .replace(/\n/gim, '<br>');
        return `<p>${html}</p>`;
      };

      const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${topic.name} - Offline Study Pack</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 20px; color: #333; background: #f8fafc; }
    .container { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
    h1 { color: #4f46e5; margin-top: 0; }
    h2 { color: #4338ca; border-bottom: 2px solid #e0e7ff; padding-bottom: 8px; margin-top: 30px; }
    h3 { color: #3730a3; }
    .qa-card { background: #f1f5f9; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 16px; }
    .question { font-weight: bold; color: #1e293b; margin-top: 0; font-size: 1.1em; }
    .answer { color: #475569; margin-bottom: 0; }
    .meta { color: #64748b; font-size: 0.9em; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 20px; }
    .footer { margin-top: 40px; text-align: center; color: #94a3b8; font-size: 0.8em; }
  </style>
</head>
<body>
  <div class="container">
    <div class="meta">${subject} • Class ${classLevel} • ${chapter.name}</div>
    <h1>${topic.name}</h1>
    
    <h2>Explanation</h2>
    <div class="explanation">
      ${simpleMarkdownToHtml(newPack.explanation)}
    </div>

    <h2>Questions & Answers</h2>
    ${newPack.qa.map(item => `
      <div class="qa-card">
        <p class="question">Q: ${item.question}</p>
        <p class="answer">A: ${simpleMarkdownToHtml(item.answer)}</p>
      </div>
    `).join('')}
    
    <div class="footer">
      Generated by myaitutorials.com • Downloaded on ${new Date().toLocaleDateString()}
    </div>
  </div>
</body>
</html>`;

      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${topic.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_study_pack.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setShowDownloadToast({ show: true, topicName: topic.name });
      setTimeout(() => setShowDownloadToast({ show: false, topicName: '' }), 5000);
    } catch (error) {
      console.error("Error downloading study pack:", error);
      alert("Failed to download study pack. Please check your internet connection and try again.");
    } finally {
      setIsDownloadingPack(false);
    }
  };

  const downloadStudyPack = async () => {
    if (!currentTopic || !currentChapter) return;
    await downloadSpecificStudyPack(currentChapter, currentTopic);
  };

  const generatePracticeTest = async () => {
    if (!currentTopic || !currentChapter) return;
    
    setIsGeneratingTest(true);
    setShowPracticeTest(true);
    setPracticeTest(null);

    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: `Generate Practice Test.
        
Payload Details:
- Class: ${classLevel}
- Subject: ${subject}
- Chapter: ${currentChapter.name}
- Topic: ${currentTopic.name}
- Language: ${language}
- Mode: Practice Test Generation

Format:
- 5 Multiple Choice Questions (MCQs)
- 3 Short-answer questions (2-3 marks)
- 2 Descriptive questions (5-8 marks)

Guidelines:
- Use proper West Bengal Board exam style.
- Include clear structure and important keywords.
- Provide the answers separately at the end of the document.
- Format the output in clean Markdown.
- IMPORTANT FORMATTING RULES:
  - Use rich Markdown formatting to improve readability.
  - Use bulleted or numbered lists for steps, features, or multiple points.
  - Use code blocks (\`\`\`) for any code snippets, formulas, or structured data.
  - Use bold text for emphasis on key terms.`,
      });
      
      setPracticeTest(response.text || "Failed to generate practice test.");
    } catch (error) {
      console.error("Error generating practice test:", error);
      setPracticeTest("Sorry, I couldn't generate the practice test at this time. Please try again later.");
    } finally {
      setIsGeneratingTest(false);
    }
  };

  const generateFlashcards = async () => {
    if (!currentTopic || !currentChapter) return;
    
    setIsGeneratingFlashcards(true);
    setFlashcards([]);

    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: `Generate 10 educational flashcards for the following topic.
        
Topic: ${currentTopic.name}
Chapter: ${currentChapter.name}
Subject: ${subject}
Class: ${classLevel}
Language: ${language}

Each flashcard should have a "term" (key concept or word) and a "definition" (clear, simple explanation).
Focus on important terms for West Bengal Board exams.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                term: { type: Type.STRING },
                definition: { type: Type.STRING }
              },
              required: ["term", "definition"]
            }
          }
        }
      });
      
      const data = JSON.parse(response.text || "[]");
      const formattedCards = data.map((item: any, index: number) => ({
        id: `card-${Date.now()}-${index}`,
        term: item.term,
        definition: item.definition,
        isLearned: false
      }));
      
      setFlashcards(formattedCards);
      setShowFlashcards(true);
    } catch (error) {
      console.error("Error generating flashcards:", error);
      alert("Failed to generate flashcards. Please try again.");
    } finally {
      setIsGeneratingFlashcards(false);
    }
  };

  const startSpeakingPractice = async () => {
    if (!currentTopic || !currentChapter) return;
    
    setIsAnalyzingSpeaking(true);
    setShowSpeakingPractice(true);
    setSpeakingPracticePrompt(null);
    setSpeakingPracticeAnalysis(null);
    setSpeakingPracticeError(null);

    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: `Generate a Speaking Practice Prompt.
        
Payload Details:
- Class: ${classLevel}
- Subject: ${subject}
- Chapter: ${currentChapter.name}
- Topic: ${currentTopic.name}
- Language: ${language}
- Mode: Speaking Practice Prompt Generation

Task:
- Provide a short, relevant paragraph or a set of 3 sentences for the student to read aloud.
- The content should be related to the current topic: ${currentTopic.name}.
- Keep it challenging but suitable for Class ${classLevel}.

Format:
- Just the prompt text, no extra commentary.`,
      });
      
      setSpeakingPracticePrompt(response.text || "Failed to generate prompt.");
    } catch (error) {
      console.error("Error generating speaking prompt:", error);
      setSpeakingPracticePrompt("Sorry, I couldn't generate the prompt at this time. Please try again later.");
    } finally {
      setIsAnalyzingSpeaking(false);
    }
  };

  const analyzeSpeakingResponse = async (userTranscription: string) => {
    if (!speakingPracticePrompt) return;
    
    setIsAnalyzingSpeaking(true);
    setSpeakingPracticeAnalysis(null);
    setSpeakingPracticeError(null);

    try {
      const { apiKey } = await sheetsService.getGeminiKey();
      const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: `Analyze Speaking Practice Response.
        
Original Prompt: "${speakingPracticePrompt}"
User Transcription: "${userTranscription}"

Task:
- Compare the transcription with the prompt.
- Analyze for:
  1. Pronunciation accuracy (identify missed or mispronounced words).
  2. Fluency (flow, pauses, rhythm).
  3. Overall clarity.
- Provide a score out of 10.
- Give constructive feedback on how to improve.
- Keep the tone encouraging and supportive.

Format:
- Format the output in clean Markdown.
- IMPORTANT FORMATTING RULES:
  - Use rich Markdown formatting to improve readability.
  - Use bulleted or numbered lists for steps, features, or multiple points.
  - Use code blocks (\`\`\`) for any code snippets, formulas, or structured data.
  - Use bold text for emphasis on key terms.`,
      });
      
      setSpeakingPracticeAnalysis(response.text || "Failed to analyze response.");
    } catch (error) {
      console.error("Error analyzing speaking response:", error);
      setSpeakingPracticeAnalysis("Sorry, I couldn't analyze your response at this time. Please try again later.");
    } finally {
      setIsAnalyzingSpeaking(false);
    }
  };

  return (
    <div className="flex h-full w-full max-w-7xl mx-auto p-4 sm:p-6 bg-[#F8FAFC] dark:bg-[#020617] text-slate-900 dark:text-slate-100 transition-colors duration-300 relative overflow-hidden gap-6">
      {/* Background Glows */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-cyan-500/5 dark:bg-cyan-500/10 blur-[120px] rounded-full" />
        <div className="absolute -bottom-[10%] -right-[10%] w-[40%] h-[40%] bg-purple-500/5 dark:bg-purple-500/10 blur-[120px] rounded-full" />
      </div>

      {/* Left Column: Main Interaction Area */}
      <div className="flex-1 flex flex-col h-full relative min-w-0 z-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 md:mb-8 z-10">
          <button 
            onClick={onBack}
            className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors flex items-center gap-2 w-fit"
          >
            <ArrowRight className="rotate-180 w-4 h-4" />
            <span className="text-sm font-medium">Change Settings</span>
          </button>
          <div className="flex items-center gap-2 sm:gap-4 overflow-x-auto scrollbar-hide pb-1 max-w-full">
            <div className="flex items-center gap-2 bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-cyan-100 dark:border-cyan-900/30 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium text-cyan-600 dark:text-cyan-400 shadow-sm dark:shadow-[0_0_10px_rgba(0,240,255,0.1)]">
              <Languages className="w-3 h-3" />
              {language}
            </div>
            <div className="flex items-center gap-2 bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-purple-100 dark:border-purple-900/30 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium text-purple-600 dark:text-purple-400 shadow-sm dark:shadow-[0_0_10px_rgba(189,0,255,0.1)]">
              <BookOpen className="w-3 h-3" />
              {activeSubject}
            </div>
            <div className="flex items-center gap-2 bg-cyan-100 dark:bg-cyan-900/30 border border-cyan-100 dark:border-cyan-900/30 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium text-cyan-600 dark:text-cyan-400 shadow-sm dark:shadow-[0_0_10px_rgba(0,240,255,0.1)]">
              <GraduationCap className="w-3 h-3" />
              Class {classLevel}
            </div>
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden flex items-center gap-2 bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white transition-all shadow-sm"
            >
              <Menu className="w-4 h-4" />
              Menu
            </button>
          <button
            onClick={downloadStudyPack}
            disabled={isDownloadingPack || isOffline}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium transition-all shadow-sm radium-btn ${
              isDownloadingPack 
                ? 'bg-slate-100 dark:bg-slate-800 text-slate-400' 
                : 'bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-900/30 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/40'
            } disabled:opacity-50`}
            title="Download for Offline Access"
          >
            {isDownloadingPack ? <Loader2 className="w-3 h-3 animate-spin" /> : <Download className="w-3 h-3" />}
            {isDownloadingPack ? 'Downloading...' : 'Offline Pack'}
          </button>
          {/* Free questions UI removed */}
          <button
            onClick={() => {
              setShowVideoGenerator(true);
              setShowVisualsSuggestion(false);
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium transition-all shadow-sm radium-btn relative ${
              showVisualsSuggestion 
                ? 'bg-cyan-600 text-white border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.5)] animate-bounce' 
                : 'bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 text-cyan-600 dark:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-900/20'
            }`}
            title="Generate Visual Aid"
          >
            <Video className="w-3 h-3" />
            Visuals
            {showVisualsSuggestion && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute -top-10 left-1/2 -translate-x-1/2 bg-cyan-600 text-white text-[10px] px-2 py-1 rounded-lg whitespace-nowrap shadow-lg"
              >
                AI Suggests Visuals!
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-cyan-600 rotate-45" />
              </motion.div>
            )}
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className="flex items-center gap-2 bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white transition-all shadow-sm radium-btn"
          >
            <Settings className="w-3 h-3" />
            Settings
          </button>
          <button
            onClick={() => setShowTimer(!showTimer)}
            className={`flex items-center gap-2 backdrop-blur-md border px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium transition-all shadow-sm radium-btn ${
              showTimer 
                ? 'bg-red-500 border-red-400 text-white shadow-red-500/20' 
                : 'bg-white/60 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-600 dark:hover:text-red-400'
            }`}
            title="Study Timer"
          >
            <Timer className="w-3 h-3" />
            Timer
          </button>
          <button
            onClick={() => setShowDailyGoalTracker(true)}
            className="flex items-center gap-2 bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-emerald-100 dark:border-emerald-900/30 px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-medium text-emerald-600 dark:text-emerald-400 shadow-sm dark:shadow-[0_0_10px_rgba(16,185,129,0.1)] radium-btn"
            title="Daily Goals"
          >
            <Target className="w-3 h-3" />
            Goals
          </button>
          {isAiSpeaking && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-900/30 backdrop-blur-sm px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-bold text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/30 shadow-sm dark:shadow-[0_0_10px_rgba(0,255,159,0.2)]"
            >
              <div className="flex gap-0.5 items-center h-2">
                <div className="w-0.5 h-full bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-0.5 h-1.5 bg-emerald-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-0.5 h-full bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="uppercase tracking-tighter">AI Speaking</span>
            </motion.div>
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col relative overflow-hidden min-h-0">
        <AnimatePresence>
          {showTimer && (
            <motion.div 
              initial={{ opacity: 0, x: 20, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 20, scale: 0.95 }}
              className="absolute top-0 right-0 z-40 p-2"
            >
              <PomodoroTimer onClose={() => setShowTimer(false)} />
            </motion.div>
          )}
        </AnimatePresence>
        <div className={`${messages.length > 0 ? 'flex-1 opacity-100' : 'h-0 opacity-0 pointer-events-none'} overflow-y-auto mb-6 space-y-4 scrollbar-hide px-1 transition-all duration-500`}>
          <AnimatePresence>
            {isOffline && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 p-3 rounded-xl text-xs font-medium flex items-center gap-2 mb-4"
              >
                <WifiOff className="w-4 h-4" />
                <span>Offline Mode: AI features are disabled. You can still access your downloaded Study Packs.</span>
              </motion.div>
            )}
          </AnimatePresence>
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id || Math.random().toString(36).substr(2, 9)}
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[90%] sm:max-w-[85%] p-4 rounded-2xl text-sm sm:text-base leading-relaxed glass-card ${
                    msg.isUser
                      ? 'bg-blue-500 border-blue-400 text-white rounded-tr-none shadow-blue-500/20'
                      : 'bg-white/80 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 rounded-tl-none'
                  }`}
                >
                  <Markdown>{msg.text}</Markdown>
                  
                  {!msg.isUser && (
                    <div className="mt-4 flex items-center gap-2">
                      <button
                        onClick={() => {
                          setVideoPrompt(`A detailed educational visualization explaining: ${msg.text.substring(0, 300)}...`);
                          setShowVideoGenerator(true);
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-50 dark:bg-cyan-900/20 text-cyan-600 dark:text-cyan-400 rounded-xl text-[10px] font-bold uppercase tracking-wider hover:bg-cyan-100 dark:hover:bg-cyan-900/40 transition-all border border-cyan-100 dark:border-cyan-900/30"
                      >
                        <Video className="w-3 h-3" />
                        Generate Visual Aid
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
            {isAiSpeaking && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm border border-slate-200 dark:border-slate-700 p-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-1">
                  <div className="w-1 h-3 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-1 h-5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-1 h-3 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 ml-2 font-medium uppercase tracking-widest">AI Speaking</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <div ref={messagesEndRef} />
        </div>

        <AnimatePresence mode="wait">
          {error ? (
            <motion.div
              key="error"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="text-center max-w-sm p-8 bg-red-50 dark:bg-red-900/10 rounded-3xl border border-red-100 dark:border-red-900/30 shadow-lg"
            >
              <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <MicOff className="w-8 h-8" />
              </div>
              <h3 className="font-display text-xl font-bold text-red-900 dark:text-red-400 mb-2">Audio Error</h3>
              <p className="text-red-700 dark:text-red-300 text-sm mb-8 leading-relaxed">
                {error}
              </p>
              <div className="flex flex-col gap-3">
                <button
                  onClick={() => window.location.reload()}
                  className="bg-red-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-red-700 transition-colors shadow-lg shadow-red-200 dark:shadow-red-900/20"
                >
                  Retry Connection
                </button>
                <button
                  onClick={onBack}
                  className="text-red-600 dark:text-red-400 text-sm font-medium hover:underline"
                >
                  Go Back
                </button>
              </div>
            </motion.div>
          ) : isConnecting ? (
            <motion.div
              key="connecting"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <div className="w-16 h-16 border-4 border-blue-200 dark:border-blue-900/30 border-t-blue-600 dark:border-t-blue-400 rounded-full animate-spin mx-auto mb-4" />
              <p className="font-display text-2xl font-semibold text-slate-600 dark:text-slate-400">Preparing your lesson...</p>
            </motion.div>
          ) : (
            <motion.div
              key="active"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="w-full h-full flex flex-col"
            >
              <div className="flex-1 flex flex-col items-center justify-center">
                <div className="relative mb-12">
                  <AnimatePresence>
                    {isListening && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute -top-8 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-red-900/20 text-red-400 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border border-red-500/30 shadow-[0_0_10px_rgba(239,68,68,0.2)] z-10"
                      >
                        <motion.div
                          animate={{ opacity: [1, 0.4, 1] }}
                          transition={{ repeat: Infinity, duration: 1.5 }}
                          className="w-1.5 h-1.5 rounded-full bg-red-400"
                        />
                        Live
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <motion.div
                    animate={{
                      scale: isListening ? [1, 1.2, 1] : 1,
                      opacity: isListening ? [0.3, 0.6, 0.3] : 0.3
                    }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="absolute inset-0 bg-cyan-600 rounded-full blur-3xl"
                  />
                  <div className="relative w-48 h-48 bg-slate-900 rounded-full shadow-2xl flex items-center justify-center border border-cyan-500/30 overflow-hidden shadow-[0_0_30px_rgba(0,240,255,0.2)]">
                    <RealisticIndianAvatar isSpeaking={isAiSpeaking} mood={mood} isOptimized={isSpeakingModeOptimized} />
                  </div>

                  {/* Speaking Mode Toggle */}
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-3 px-4 py-2 bg-slate-800/80 backdrop-blur-sm rounded-full border border-slate-700 shadow-sm whitespace-nowrap z-20">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Speaking Mode</span>
                    <button 
                      onClick={() => !isOffline && setIsSpeakingModeOptimized(!isSpeakingModeOptimized)}
                      disabled={isOffline}
                      className={`w-8 h-4 rounded-full relative transition-colors duration-300 ${isOffline ? 'bg-slate-700 cursor-not-allowed' : isSpeakingModeOptimized ? 'bg-cyan-600' : 'bg-slate-600'}`}
                      title={isOffline ? "Disabled in Offline Mode" : isSpeakingModeOptimized ? "Optimized for bandwidth (minimal movement)" : "Full movement mode"}
                    >
                      <motion.div 
                        animate={{ x: isSpeakingModeOptimized ? 18 : 2 }}
                        className="absolute top-0.5 w-3 h-3 bg-white rounded-full shadow-sm"
                      />
                    </button>
                  </div>
                </div>

                <div className="text-center max-w-md mb-8 z-10">
                  <h2 className="font-display text-3xl font-bold text-slate-900 dark:text-white mb-4 dark:radium-text-cyan">How can I help you today?</h2>
                  <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                    Ask me about any topic in your West Bengal Board syllabus. I can explain concepts, solve problems, or help with exam preparation.
                  </p>
                </div>

                <div className="w-full max-w-md relative mb-8 z-10">
                  <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700 h-32 overflow-y-auto scrollbar-hide">
                    <AnimatePresence initial={false}>
                      {messages.length === 0 ? (
                        <p className="text-slate-500 text-sm text-center italic">Transcript will appear here...</p>
                      ) : (
                        messages.map((msg) => (
                          <motion.div
                            key={msg.id || Math.random().toString(36).substr(2, 9)}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={`mb-2 text-sm ${msg.isUser ? 'text-cyan-400 font-medium' : 'text-slate-300'}`}
                          >
                            <span className="opacity-50 mr-2">{msg.isUser ? 'You:' : 'Tutor:'}</span>
                            {msg.text}
                          </motion.div>
                        ))
                      )}
                    </AnimatePresence>
                  </div>
                  {messages.length > 0 && (
                    <button
                      onClick={clearChat}
                      title="Clear Chat"
                      className="absolute -top-2 -right-2 w-8 h-8 bg-slate-800 rounded-full shadow-md border border-slate-700 flex items-center justify-center text-slate-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-auto flex flex-col items-center gap-4 w-full max-w-2xl mx-auto pb-4 sm:pb-8 z-10 px-4">
                <div className="flex justify-center items-center gap-4 sm:gap-6 w-full">
                  <button
                    onClick={() => {
                      setVideoPrompt(currentTopic ? `A detailed educational visualization explaining ${currentTopic.name}` : '');
                      setShowVideoGenerator(true);
                    }}
                    className="w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center bg-white/10 dark:bg-slate-800/40 backdrop-blur-md border border-white/20 dark:border-slate-700 text-cyan-400 hover:bg-white/20 dark:hover:bg-slate-700 transition-all shadow-lg radium-btn"
                    title="Request Visual Aid"
                  >
                    <Video className="w-5 h-5 sm:w-6 sm:h-6" />
                  </button>

                  <button
                    onClick={() => !isOffline && toggleListening()}
                    disabled={isOffline}
                    title={isOffline ? "Microphone disabled in offline mode" : isListening ? "Mute Microphone" : "Unmute Microphone"}
                    className={`w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center transition-all shadow-lg ${
                      isOffline ? 'bg-slate-900 text-slate-700 border-slate-800 cursor-not-allowed' :
                      isListening ? 'bg-cyan-600 text-white shadow-[0_0_20px_rgba(0,240,255,0.4)] border-cyan-400' : 'bg-slate-800 text-slate-500 border border-slate-700 hover:border-cyan-500 hover:text-cyan-400'
                    }`}
                  >
                    {isOffline ? <MicOff className="w-6 h-6 sm:w-8 sm:h-8" /> : isListening ? <Mic className="w-6 h-6 sm:w-8 sm:h-8" /> : <MicOff className="w-6 h-6 sm:w-8 sm:h-8" />}
                  </button>
                  
                  <div className="relative flex items-center">
                    <AnimatePresence>
                      {showVolumeSlider && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8, x: 20 }}
                          animate={{ opacity: 1, scale: 1, x: 0 }}
                          exit={{ opacity: 0, scale: 0.8, x: 20 }}
                          className="absolute bottom-20 right-0 bg-slate-900/95 backdrop-blur-xl p-4 rounded-2xl shadow-xl border border-slate-800 w-12 h-48 flex flex-col items-center gap-4 z-[60]"
                        >
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.01"
                            value={volume}
                            onChange={handleVolumeChange}
                            className="w-32 -rotate-90 origin-center accent-cyan-600 cursor-pointer"
                            style={{ marginTop: '64px' }}
                          />
                          <span className="text-[10px] font-bold text-slate-500 mt-auto">
                            {Math.round(volume * 100)}%
                          </span>
                        </motion.div>
                      )}
                    </AnimatePresence>
                    
                    <div className="flex bg-slate-800 rounded-full shadow-lg border border-slate-700 overflow-hidden">
                      <button
                        onClick={toggleMute}
                        title={isMuted ? "Unmute AI" : "Mute AI"}
                        className={`w-14 h-14 sm:w-16 sm:h-16 flex items-center justify-center transition-all ${
                          isMuted ? 'text-red-400 bg-red-900/20' : 'text-slate-300 hover:bg-slate-700 hover:text-cyan-400'
                        }`}
                      >
                        {isMuted ? <VolumeX className="w-5 h-5 sm:w-6 sm:h-6" /> : <Volume2 className="w-5 h-5 sm:w-6 sm:h-6" />}
                      </button>
                      <div className="w-[1px] h-8 bg-slate-700 self-center" />
                      <button
                        onClick={() => setShowVolumeSlider(!showVolumeSlider)}
                        className={`w-10 h-14 sm:w-12 sm:h-16 flex items-center justify-center transition-all hover:bg-slate-700 ${
                          showVolumeSlider ? 'text-cyan-400' : 'text-slate-500 hover:text-cyan-400'
                        }`}
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-current" />
                      </button>
                    </div>
                  </div>
                </div>
                
                <form onSubmit={handleChatSubmit} className="w-full relative mt-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder={isOffline ? "Chat disabled in offline mode" : "Type your message..."}
                    disabled={isOffline}
                    className="w-full bg-slate-800/80 border border-slate-700 rounded-full pl-6 pr-14 py-3 sm:py-4 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all shadow-lg backdrop-blur-md disabled:opacity-50 disabled:cursor-not-allowed"
                  />
                  <button
                    type="submit"
                    disabled={!chatInput.trim() || isOffline}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 sm:p-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-700 disabled:text-slate-500 text-white rounded-full transition-colors"
                  >
                    <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
                  </button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      </div>

      {/* Right Column: Sidebar */}
      <div className={`fixed inset-y-0 right-0 w-80 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-l border-slate-200 dark:border-slate-800 shadow-2xl z-50 transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 lg:w-96 lg:bg-transparent lg:dark:bg-transparent lg:border-none lg:shadow-none lg:z-10 flex flex-col gap-6 p-6 lg:p-0 overflow-y-auto ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex items-center justify-between lg:hidden mb-2">
          <h3 className="font-bold text-slate-800 dark:text-slate-200">Menu</h3>
          <button onClick={() => setIsSidebarOpen(false)} className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Buttons Grid */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              setShowTopicSelector(!showTopicSelector);
              setShowHistory(false);
            }}
            className={`flex flex-col items-center justify-center gap-1 p-3 rounded-xl border transition-all text-xs font-medium radium-btn ${
              showTopicSelector ? 'bg-cyan-600 text-white border-cyan-400 shadow-lg dark:shadow-[0_0_15px_rgba(0,240,255,0.3)]' : 'bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-cyan-500/50 hover:text-cyan-600 dark:hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Topics</span>
          </button>
          <button
            onClick={() => {
              setShowHistory(!showHistory);
              setShowTopicSelector(false);
            }}
            className={`flex flex-col items-center justify-center gap-1 p-3 rounded-xl border transition-all text-xs font-medium radium-btn ${
              showHistory ? 'bg-purple-600 text-white border-purple-400 shadow-lg dark:shadow-[0_0_15px_rgba(189,0,255,0.3)]' : 'bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-purple-500/50 hover:text-purple-600 dark:hover:text-white'
            }`}
          >
            <History className="w-4 h-4" />
            <span>History</span>
          </button>
          <button
            onClick={generateRevisionNotes}
            className="flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-amber-500/50 hover:text-amber-600 dark:hover:text-white hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-all text-xs font-medium radium-btn"
          >
            <FileText className="w-4 h-4" />
            <span>Notes</span>
          </button>
          <button
            onClick={generateQuickSummary}
            className="flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-blue-500/50 hover:text-blue-600 dark:hover:text-white hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all text-xs font-medium radium-btn"
          >
            <Zap className="w-4 h-4" />
            <span>Summary</span>
          </button>
          <button
            onClick={generateQuestions}
            className="flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-cyan-500/50 hover:text-cyan-600 dark:hover:text-white hover:bg-cyan-50 dark:hover:bg-cyan-900/20 transition-all text-xs font-medium radium-btn"
          >
            <HelpCircle className="w-4 h-4" />
            <span>Quiz</span>
          </button>
          <button
            onClick={generatePracticeTest}
            className="flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-purple-500/50 hover:text-purple-600 dark:hover:text-white hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-all text-xs font-medium radium-btn"
          >
            <Sparkles className="w-4 h-4" />
            <span>Test</span>
          </button>
          <button
            onClick={generateFlashcards}
            disabled={isGeneratingFlashcards}
            className="flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-emerald-500/50 hover:text-emerald-600 dark:hover:text-white hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-all text-xs font-medium radium-btn disabled:opacity-50"
          >
            {isGeneratingFlashcards ? <Loader2 className="w-4 h-4 animate-spin" /> : <Layers className="w-4 h-4" />}
            <span>Cards</span>
          </button>
          <button
            onClick={() => setShowVideoModal(true)}
            className="flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-purple-500/50 hover:text-purple-600 dark:hover:text-white hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-all text-xs font-medium radium-btn"
          >
            <Video className="w-4 h-4" />
            <span>Video</span>
          </button>
          <button
            onClick={startSpeakingPractice}
            className="flex flex-col items-center justify-center gap-1 p-3 rounded-xl bg-gradient-to-r from-cyan-600 to-purple-600 text-white hover:from-cyan-500 hover:to-purple-500 transition-all text-xs font-medium shadow-lg dark:shadow-[0_0_15px_rgba(0,240,255,0.2)] radium-btn"
          >
            <Mic className="w-4 h-4" />
            <span>Speak</span>
          </button>
          <button
            onClick={() => setShowResponseHistory(!showResponseHistory)}
            className={`flex flex-col items-center justify-center gap-1 p-3 rounded-xl border transition-all text-xs font-medium radium-btn ${
              showResponseHistory ? 'bg-indigo-600 text-white border-indigo-400 shadow-lg dark:shadow-[0_0_15px_rgba(99,102,241,0.3)]' : 'bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-indigo-500/50 hover:text-indigo-600 dark:hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Review</span>
          </button>
          <button
            onClick={() => setShowOfflinePacks(!showOfflinePacks)}
            className={`flex flex-col items-center justify-center gap-1 p-3 rounded-xl border transition-all text-xs font-medium radium-btn relative ${
              showOfflinePacks ? 'bg-indigo-600 text-white border-indigo-400 shadow-lg dark:shadow-[0_0_15px_rgba(99,102,241,0.3)]' : 'bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-indigo-500/50 hover:text-indigo-600 dark:hover:text-white'
            }`}
          >
            <WifiOff className="w-4 h-4" />
            <span>Offline</span>
            {offlinePacks.length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] flex items-center justify-center rounded-full border-2 border-white dark:border-slate-900 font-bold">
                {offlinePacks.length}
              </span>
            )}
          </button>
        </div>

        {/* Modals Container */}
        <div className="flex-1 relative overflow-y-auto bg-white/60 dark:bg-slate-800/60 backdrop-blur-md border border-slate-200 dark:border-slate-700 rounded-3xl p-4 shadow-sm">
        <AnimatePresence>
          {showSpeakingPractice && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative w-full h-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[90%] overflow-y-auto scrollbar-hide"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-cyan-100 dark:bg-cyan-900/30 rounded-xl flex items-center justify-center">
                    <Mic className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">Speaking Practice</h3>
                    <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{subject} • {currentTopic?.name}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowSpeakingPractice(false)}
                  className="text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                >
                  Close
                </button>
              </div>

              <div className="space-y-6">
                {isAnalyzingSpeaking && !speakingPracticePrompt ? (
                  <div className="py-12 flex flex-col items-center justify-center gap-4">
                    <div className="w-8 h-8 border-2 border-cyan-200 dark:border-cyan-900/30 border-t-cyan-600 dark:border-t-cyan-400 rounded-full animate-spin" />
                    <p className="font-medium text-slate-500 dark:text-slate-400">Generating your prompt...</p>
                  </div>
                ) : (
                  <>
                    <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
                      <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3">Read this aloud:</h4>
                      <p className="text-lg font-medium text-slate-800 dark:text-slate-200 leading-relaxed italic">
                        "{speakingPracticePrompt}"
                      </p>
                    </div>

                    <div className="flex flex-col items-center gap-4 py-4">
                      <p className="text-sm text-slate-500 dark:text-slate-400 text-center">
                        Click the microphone button below to start speaking. When you're done, click "Analyze Response".
                      </p>

                      {messages.filter(m => m.isUser).length > 0 && (
                        <div className="w-full bg-cyan-50/30 dark:bg-cyan-900/10 p-4 rounded-xl border border-cyan-100/50 dark:border-cyan-900/20 mb-2">
                          <h5 className="text-[10px] font-bold text-cyan-600 dark:text-cyan-400 uppercase tracking-widest mb-1">Your last recording:</h5>
                          <p className="text-sm text-slate-600 dark:text-slate-300 italic">
                            "{[...messages].reverse().find(m => m.isUser)?.text}"
                          </p>
                        </div>
                      )}

                      {speakingPracticeError && (
                        <motion.p 
                          initial={{ opacity: 0, y: -5 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-xs font-medium text-red-500 mb-2"
                        >
                          {speakingPracticeError}
                        </motion.p>
                      )}
                      
                      <div className="flex gap-3">
                        <button
                          onClick={startSpeakingPractice}
                          disabled={isAnalyzingSpeaking}
                          className="px-6 py-3 rounded-full font-bold text-sm transition-all border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
                        >
                          <History className="w-4 h-4" />
                          New Prompt
                        </button>

                        <button
                          onClick={() => {
                            const lastUserMsg = [...messages].reverse().find(m => m.isUser);
                            if (lastUserMsg) {
                              analyzeSpeakingResponse(lastUserMsg.text);
                            } else {
                              setSpeakingPracticeError("Please speak first so I can analyze your response!");
                            }
                          }}
                          disabled={isAnalyzingSpeaking || !speakingPracticePrompt}
                          className={`px-8 py-3 rounded-full font-bold text-sm transition-all shadow-lg flex items-center gap-2 radium-btn ${
                            isAnalyzingSpeaking 
                              ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed' 
                              : 'radium-btn-cyan'
                          }`}
                        >
                          {isAnalyzingSpeaking ? (
                            <>
                              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                              Analyzing...
                            </>
                          ) : (
                            <>
                              <Zap className="w-4 h-4" />
                              Analyze My Response
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {speakingPracticeAnalysis && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-emerald-50 dark:bg-emerald-900/20 p-6 rounded-2xl border border-emerald-100 dark:border-emerald-900/30"
                      >
                        <div className="flex items-center gap-2 mb-4">
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                          <h4 className="font-bold text-emerald-900 dark:text-emerald-100">AI Analysis Result</h4>
                        </div>
                        <div className="markdown-body text-slate-700 dark:text-slate-300">
                          <Markdown>{speakingPracticeAnalysis}</Markdown>
                        </div>
                      </motion.div>
                    )}
                  </>
                )}
              </div>
            </motion.div>
          )}

          {showVideoGenerator && (
            <VideoGenerator 
              onClose={() => setShowVideoGenerator(false)} 
              initialPrompt={videoPrompt || (currentTopic ? `A detailed educational visualization explaining ${currentTopic.name} from the chapter ${currentChapter?.name}` : '')}
            />
          )}

          <AnimatePresence>
            {showDownloadToast.show && (
              <motion.div
                initial={{ opacity: 0, y: 50, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 50, scale: 0.9 }}
                className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[200] bg-indigo-600 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 border border-indigo-400 min-w-[320px]"
              >
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center shrink-0">
                  <Download className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-sm">Download Complete!</p>
                  <p className="text-xs text-indigo-100 italic">"{showDownloadToast.topicName}" is now available offline.</p>
                </div>
                <button 
                  onClick={() => {
                    setShowOfflinePacks(true);
                    setShowDownloadToast({ show: false, topicName: '' });
                  }}
                  className="px-3 py-1.5 bg-white text-indigo-600 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-indigo-50 transition-colors"
                >
                  View
                </button>
                <button 
                  onClick={() => setShowDownloadToast({ show: false, topicName: '' })}
                  className="p-1 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {showFlashcards && (
              <Flashcards 
                cards={flashcards} 
                onClose={() => setShowFlashcards(false)} 
                topicName={currentTopic?.name}
                subject={activeSubject}
              />
            )}
          </AnimatePresence>

          <VideoGenerationModal
            isOpen={showVideoModal}
            onClose={() => setShowVideoModal(false)}
            subject={activeSubject}
            topicName={currentTopic?.name}
          />

          <AnimatePresence>
            {showDailyGoalTracker && (
              <DailyGoalTracker onClose={() => setShowDailyGoalTracker(false)} />
            )}
          </AnimatePresence>

          <AnimatePresence>
            {showQuickSummary && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[150] flex items-center justify-center p-4"
                onClick={() => setShowQuickSummary(false)}
              >
                <motion.div
                  initial={{ scale: 0.9, opacity: 0, y: 20 }}
                  animate={{ scale: 1, opacity: 1, y: 0 }}
                  exit={{ scale: 0.9, opacity: 0, y: 20 }}
                  className="glass-card rounded-[2.5rem] p-8 max-w-lg w-full max-h-[80vh] overflow-y-auto scrollbar-hide"
                  onClick={e => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/30 rounded-2xl shadow-sm">
                        <Zap className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">Quick Summary</h2>
                        <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">{currentTopic?.name}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setShowQuickSummary(false)}
                      className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>

                  {isGeneratingSummary ? (
                    <div className="py-12 flex flex-col items-center justify-center gap-4">
                      <div className="w-10 h-10 border-2 border-blue-200 dark:border-blue-900/30 border-t-blue-600 dark:border-t-blue-400 rounded-full animate-spin" />
                      <p className="font-medium text-slate-500 dark:text-slate-400">Condensing the topic for you...</p>
                    </div>
                  ) : (
                    <div className="markdown-body text-slate-700 dark:text-slate-300 leading-relaxed">
                      <Markdown>{quickSummary}</Markdown>
                    </div>
                  )}

                  <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-center">
                    <button
                      onClick={() => setShowQuickSummary(false)}
                      className="px-8 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-bold text-sm shadow-lg hover:opacity-90 transition-all"
                    >
                      Got it, thanks!
                    </button>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {showSettings && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="relative w-full h-full flex items-center justify-center"
              onClick={() => setShowSettings(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                className="glass-card rounded-3xl p-8 max-w-md w-full"
                onClick={e => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-slate-50 dark:bg-slate-700 rounded-xl shadow-sm">
                    <Settings className="w-5 h-5 text-slate-500 dark:text-slate-400" />
                  </div>
                  <h2 className="text-xl font-serif font-bold text-slate-900 dark:text-slate-100">Tutor Settings</h2>
                </div>
                  <button 
                    onClick={() => setShowSettings(false)}
                    className="text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                  >
                    Close
                  </button>
                </div>

                <div className="space-y-8">
                  <div>
                    <label className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-200 mb-4">
                      <Activity className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                      Audio Recording Quality
                    </label>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
                      Adjust the sample rate to manage bandwidth and audio fidelity. 
                      Lower rates use less data but may sound less clear.
                    </p>
                    <div className="grid grid-cols-1 gap-3">
                      {[
                        { rate: 8000, label: 'Low (8kHz)', desc: 'Minimal bandwidth, basic clarity' },
                        { rate: 16000, label: 'Standard (16kHz)', desc: 'Balanced performance (Recommended)' },
                        { rate: 24000, label: 'High (24kHz)', desc: 'Better fidelity, higher data usage' },
                        { rate: 48000, label: 'Ultra (48kHz)', desc: 'Crystal clear, maximum bandwidth' }
                      ].map((quality) => (
                        <button
                          key={quality.rate}
                          onClick={() => {
                            setAudioQuality({ sampleRate: quality.rate, label: quality.label });
                          }}
                          className={`flex flex-col items-start p-4 rounded-2xl border-2 transition-all ${
                            audioQuality.sampleRate === quality.rate
                              ? 'bg-cyan-50 dark:bg-cyan-900/20 border-cyan-500 text-cyan-700 dark:text-cyan-100 shadow-sm dark:shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                              : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-cyan-500/50 hover:bg-slate-50 dark:hover:bg-slate-700/80 hover:text-cyan-600 dark:hover:text-white'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full mb-1">
                            <span className="font-bold text-sm">{quality.label}</span>
                            {audioQuality.sampleRate === quality.rate && (
                              <div className="w-2 h-2 bg-cyan-500 dark:bg-cyan-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(0,240,255,0.8)]" />
                            )}
                          </div>
                          <span className={`text-[10px] ${audioQuality.sampleRate === quality.rate ? 'text-cyan-600 dark:text-cyan-400/80' : 'text-slate-400 dark:text-slate-500'}`}>
                            {quality.desc} • Bitrate: {Math.round(quality.rate * 16 / 1000)}kbps
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-200 mb-4">
                      <Activity className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                      AI Model
                    </label>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
                      Select the AI model for the tutor. Pro provides better reasoning, while Flash is faster.
                    </p>
                    <div className="grid grid-cols-1 gap-3">
                      {[
                        { id: 'gemini-3.1-flash-lite-preview', label: 'Gemini Flash Lite', desc: 'Fastest, good for basic questions' },
                        { id: 'gemini-3-flash-preview', label: 'Gemini Flash', desc: 'Balanced speed and reasoning' },
                        { id: 'gemini-3.1-pro-preview', label: 'Gemini Pro', desc: 'Best reasoning for complex topics' }
                      ].map((model) => (
                        <button
                          key={model.id}
                          onClick={() => setSelectedModel(model.id)}
                          className={`flex flex-col items-start p-4 rounded-2xl border-2 transition-all ${
                            selectedModel === model.id
                              ? 'bg-cyan-50 dark:bg-cyan-900/20 border-cyan-500 text-cyan-700 dark:text-cyan-100 shadow-sm dark:shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                              : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-cyan-500/50 hover:bg-slate-50 dark:hover:bg-slate-700/80 hover:text-cyan-600 dark:hover:text-white'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full mb-1">
                            <span className="font-bold text-sm">{model.label}</span>
                            {selectedModel === model.id && (
                              <div className="w-2 h-2 bg-cyan-500 dark:bg-cyan-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(0,240,255,0.8)]" />
                            )}
                          </div>
                          <span className={`text-[10px] ${selectedModel === model.id ? 'text-cyan-600 dark:text-cyan-400/80' : 'text-slate-400 dark:text-slate-500'}`}>
                            {model.desc}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-200 mb-4">
                      <Zap className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                      Speaking Mode (Optimization)
                    </label>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
                      Reduce avatar movement to conserve bandwidth and improve audio stability.
                    </p>
                    <button
                      onClick={() => setIsSpeakingModeOptimized(!isSpeakingModeOptimized)}
                      className={`flex items-center justify-between w-full p-4 rounded-2xl border-2 transition-all ${
                        isSpeakingModeOptimized
                          ? 'bg-cyan-50 dark:bg-cyan-900/20 border-cyan-500 text-cyan-700 dark:text-cyan-100 shadow-sm dark:shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-cyan-500/50 hover:bg-slate-50 dark:hover:bg-slate-700/80 hover:text-cyan-600 dark:hover:text-white'
                      }`}
                    >
                      <div className="flex flex-col items-start">
                        <span className="font-bold text-sm">
                          {isSpeakingModeOptimized ? 'Optimized Mode Active' : 'Full Movement Mode'}
                        </span>
                        <span className="text-[10px] opacity-70">
                          {isSpeakingModeOptimized ? 'Minimal movement for better performance' : 'Natural hand and neck movements'}
                        </span>
                      </div>
                      <div className={`w-10 h-5 rounded-full relative transition-colors duration-300 ${isSpeakingModeOptimized ? 'bg-cyan-600' : 'bg-slate-200 dark:bg-slate-600'}`}>
                        <motion.div 
                          animate={{ x: isSpeakingModeOptimized ? 22 : 2 }}
                          className="absolute top-1 w-3 h-3 bg-white rounded-full shadow-sm"
                        />
                      </div>
                    </button>
                  </div>
                </div>

                <div className="mt-10 pt-6 border-t border-slate-100 dark:border-slate-700">
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 text-center italic">
                    Changing quality settings will automatically reconnect your tutor session.
                  </p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showTopicSelector && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative w-full h-full glass-card rounded-3xl p-6 max-h-[80%] overflow-y-auto scrollbar-hide bg-white/95 dark:bg-slate-900/95 border-slate-200 dark:border-cyan-500/30 shadow-xl dark:shadow-[0_0_30px_rgba(0,240,255,0.2)]"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <BookOpen className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
                  <h3 className="font-serif text-xl font-bold text-slate-900 dark:text-white dark:radium-text-cyan">Lesson Topics</h3>
                </div>
                <button 
                  onClick={() => setShowTopicSelector(false)}
                  className="text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
                >
                  Close
                </button>
              </div>

              <div className="flex gap-2 overflow-x-auto pb-4 mb-6 scrollbar-hide">
                {Object.keys(syllabus[classLevel]).map((sub) => (
                  <button
                    key={sub}
                    onClick={() => {
                      setActiveSubject(sub);
                      setActiveChapterId(undefined);
                      setActiveTopicId(undefined);
                    }}
                    className={`px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition-all border shadow-sm ${
                      activeSubject === sub
                        ? 'bg-cyan-600 border-cyan-400 text-white shadow-md dark:shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-cyan-500 hover:text-cyan-600 dark:hover:text-white'
                    }`}
                  >
                    {sub}
                  </button>
                ))}
              </div>

              <div className="mb-6">
                <input
                  type="text"
                  placeholder="Search chapters or topics..."
                  value={topicSearchQuery}
                  onChange={(e) => setTopicSearchQuery(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl px-6 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all shadow-inner text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="space-y-8">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={`${activeSubject}-${topicSearchQuery}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="space-y-8"
                  >
                    {filteredSyllabus.map((chapter, index) => {
                      const isCollapsed = collapsedChapters.has(chapter.id) && !topicSearchQuery;
                      return (
                      <div key={`${chapter.id}-${index}`} className={`space-y-4 rounded-2xl p-2 transition-colors ${activeChapterId === chapter.id ? 'bg-blue-50/50 dark:bg-blue-900/10' : ''}`}>
                        <div 
                          onClick={() => toggleChapter(chapter.id)}
                          className={`flex items-center justify-between border-b pb-2 sticky top-0 backdrop-blur-md z-10 px-2 rounded-t-lg transition-colors cursor-pointer ${activeChapterId === chapter.id ? 'border-blue-200 dark:border-blue-800 bg-blue-50/80 dark:bg-blue-900/40' : 'border-slate-100 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 hover:bg-slate-50 dark:hover:bg-slate-800/80'}`}
                        >
                          <div className="flex items-center gap-3">
                            <span className={`text-[10px] font-bold uppercase tracking-[0.2em] ${activeChapterId === chapter.id ? 'text-blue-500 dark:text-blue-400' : 'text-slate-400 dark:text-slate-500'}`}>Chapter</span>
                            <h4 className={`font-display text-base font-semibold ${activeChapterId === chapter.id ? 'text-blue-700 dark:text-blue-300' : 'text-slate-700 dark:text-slate-300'}`}>
                              {chapter.name}
                            </h4>
                          </div>
                          <div className="text-slate-400">
                            {isCollapsed ? <ChevronDown className="w-5 h-5" /> : <ChevronUp className="w-5 h-5" />}
                          </div>
                        </div>
                        
                        <AnimatePresence initial={false}>
                          {!isCollapsed && (
                            <motion.div 
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="overflow-hidden"
                            >
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 px-2 pt-2">
                                {chapter.topics.map((topic, topicIndex) => {
                                  const isCompleted = completedTopicIds.has(topic.id);
                                  const isActive = activeTopicId === topic.id;
                                  
                                  return (
                          <div key={`${topic.id}-${topicIndex}`} className="relative group">
                            <button
                              onClick={() => {
                                setActiveChapterId(chapter.id);
                                setActiveTopicId(topic.id);
                                setShowTopicSelector(false);
                                setMessages([]); // Clear chat when topic changes
                                setTopicSearchQuery(''); // Reset search
                              }}
                              className={`w-full p-4 rounded-2xl text-left transition-all border btn-3d ${
                                isActive
                                  ? 'bg-blue-500 border-blue-400 text-white shadow-blue-500/20 scale-[1.02]'
                                  : isCompleted
                                    ? 'bg-emerald-50/20 dark:bg-emerald-900/10 border-emerald-100 dark:border-emerald-900/30 text-slate-700 dark:text-slate-300 hover:border-blue-200 dark:hover:border-blue-800 hover:bg-white/60 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-100'
                                    : 'bg-white/60 dark:bg-slate-800/60 border-slate-100 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-blue-200 dark:hover:border-blue-800 hover:bg-white/60 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-100'
                              }`}
                            >
                                      <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2 pr-8">
                                          {isCompleted && !isActive && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
                                          {isCompleted && isActive && <CheckCircle2 className="w-4 h-4 text-white shrink-0" />}
                                          <span className="text-sm font-medium leading-tight">{topic.name}</span>
                                        </div>
                                        {isActive && (
                                          <motion.div layoutId="tutor-active-topic" className="w-2 h-2 rounded-full bg-white shrink-0" />
                                        )}
                                      </div>
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                // Set active temporarily to download, then we'll download
                                // Actually, we need a modified download function that takes chapter/topic directly
                                // For now, we can just alert them to select it first, or we can modify the download function.
                                // Let's modify the download function to accept optional parameters.
                                downloadSpecificStudyPack(chapter, topic);
                              }}
                              disabled={isDownloadingPack || isOffline}
                              className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-xl transition-all ${
                                isActive ? 'text-white/70 hover:text-white hover:bg-white/20' : 'text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30'
                              } disabled:opacity-50`}
                              title="Download for Offline Access"
                            >
                              <Download className="w-4 h-4" />
                            </button>
                          </div>
                                  )})}
                                </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    )})}
                    {filteredSyllabus.length === 0 && (
                      <div className="text-center py-12 text-slate-400 italic">
                        No topics found matching "{topicSearchQuery}"
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
            </motion.div>
          )}

          {showResponseHistory && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative w-full h-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[80%] overflow-y-auto scrollbar-hide"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <MessageSquare className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">Response History</h3>
                </div>
                <button 
                  onClick={() => setShowResponseHistory(false)}
                  className="text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                >
                  Close
                </button>
              </div>

              <div className="space-y-4">
                {messages.filter(m => !m.isUser).length === 0 ? (
                  <div className="text-center py-12 text-slate-400 dark:text-slate-500 italic">
                    No AI responses yet. Start a conversation!
                  </div>
                ) : (
                  messages.filter(m => !m.isUser).map((msg, idx) => (
                    <div key={msg.id || idx} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700/50">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest">Response {idx + 1}</span>
                      </div>
                      <div className="text-sm text-slate-700 dark:text-slate-300 prose dark:prose-invert max-w-none">
                        <Markdown>{msg.text}</Markdown>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}

          {showHistory && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative w-full h-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[80%] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <History className="w-5 h-5 text-slate-800 dark:text-slate-200" />
                  <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">Previous Sessions</h3>
                </div>
                <button 
                  onClick={() => setShowHistory(false)}
                  className="text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                >
                  Close
                </button>
              </div>

              <div className="space-y-3">
                {historyList.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 dark:text-slate-500 italic">
                    No saved sessions found.
                  </div>
                ) : (
                  historyList.map((session: any) => (
                    <button
                      key={session.id || `${session.classLevel}_${session.chapterId}_${session.topicId}_${session.timestamp}`}
                      onClick={() => loadSavedSession(`${session.classLevel}_${session.chapterId}_${session.topicId}`)}
                      className="w-full group p-4 rounded-2xl text-left transition-all border bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-purple-300 dark:hover:border-purple-700 hover:bg-purple-50/50 dark:hover:bg-purple-900/20 flex items-center justify-between shadow-sm"
                    >
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Class {session.classLevel}</span>
                          <span className="text-slate-300 dark:text-slate-600">•</span>
                          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">{session.chapterName}</span>
                        </div>
                        <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">{session.topicName}</span>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500">
                          {new Date(session.timestamp).toLocaleDateString()} at {new Date(session.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-purple-600 dark:group-hover:text-purple-400 group-hover:translate-x-1 transition-all" />
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          )}

          {showRevisionNotes && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative w-full h-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[90%] overflow-y-auto scrollbar-hide"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">Revision Notes</h3>
                    <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{subject} • {currentTopic?.name}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowRevisionNotes(false)}
                  className="text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                >
                  Close
                </button>
              </div>

              <div className="prose prose-slate dark:prose-invert max-w-none">
                {isGeneratingNotes ? (
                  <div className="py-12 flex flex-col items-center justify-center gap-4">
                    <div className="w-8 h-8 border-2 border-amber-200 dark:border-amber-900/30 border-t-amber-600 dark:border-t-amber-400 rounded-full animate-spin" />
                    <p className="font-medium text-slate-500 dark:text-slate-400">Creating your study guide...</p>
                  </div>
                ) : (
                  <div className="markdown-body text-slate-700 dark:text-slate-300 leading-relaxed">
                    <Markdown>{revisionNotes || ""}</Markdown>
                  </div>
                )}
              </div>

              {!isGeneratingNotes && revisionNotes && (
                <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 italic">Generated by AI Tutor for West Bengal Board Exam Prep</p>
                  <button
                    onClick={() => {
                      const blob = new Blob([revisionNotes], { type: 'text/plain' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `${currentTopic?.name}_Revision_Notes.txt`;
                      a.click();
                    }}
                    className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                  >
                    <Save className="w-3 h-3" />
                    Download as Text
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {showQuestions && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative w-full h-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[90%] overflow-y-auto scrollbar-hide"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
                    <HelpCircle className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">Practice Questions</h3>
                    <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{subject} • {currentTopic?.name}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowQuestions(false)}
                  className="text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                >
                  Close
                </button>
              </div>

              <div className="prose prose-slate dark:prose-invert max-w-none">
                {isGeneratingQuestions ? (
                  <div className="py-12 flex flex-col items-center justify-center gap-4">
                    <div className="w-8 h-8 border-2 border-blue-200 dark:border-blue-900/30 border-t-blue-600 dark:border-t-blue-400 rounded-full animate-spin" />
                    <p className="font-medium text-slate-500 dark:text-slate-400">Preparing your practice set...</p>
                  </div>
                ) : (
                  <div className="markdown-body text-slate-700 dark:text-slate-300 leading-relaxed">
                    <Markdown>{questions || ""}</Markdown>
                  </div>
                )}
              </div>

              {!isGeneratingQuestions && questions && (
                <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 italic">Exam-oriented questions for West Bengal Board</p>
                  <button
                    onClick={() => {
                      const blob = new Blob([questions], { type: 'text/plain' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `${currentTopic?.name}_Practice_Questions.txt`;
                      a.click();
                    }}
                    className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                  >
                    <Save className="w-3 h-3" />
                    Download Questions
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {showPracticeTest && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative w-full h-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[90%] overflow-y-auto scrollbar-hide"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-800 dark:bg-slate-700 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">Mini Practice Test</h3>
                    <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{subject} • {currentTopic?.name}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowPracticeTest(false)}
                  className="text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                >
                  Close
                </button>
              </div>

              <div className="prose prose-slate dark:prose-invert max-w-none">
                {isGeneratingTest ? (
                  <div className="py-12 flex flex-col items-center justify-center gap-4">
                    <div className="w-8 h-8 border-2 border-slate-200 dark:border-slate-700 border-t-slate-800 dark:border-t-slate-400 rounded-full animate-spin" />
                    <p className="font-medium text-slate-500 dark:text-slate-400">Creating your custom test...</p>
                  </div>
                ) : (
                  <div className="markdown-body text-slate-700 dark:text-slate-300 leading-relaxed">
                    <Markdown>{practiceTest || ""}</Markdown>
                  </div>
                )}
              </div>

              {!isGeneratingTest && practiceTest && (
                <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 italic">Custom test with answers for West Bengal Board</p>
                  <button
                    onClick={() => {
                      const blob = new Blob([practiceTest], { type: 'text/plain' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `${currentTopic?.name}_Practice_Test.txt`;
                      a.click();
                    }}
                    className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                  >
                    <Save className="w-3 h-3" />
                    Download Test
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {showOfflinePacks && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative w-full h-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[90%] overflow-y-auto scrollbar-hide"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center">
                    <WifiOff className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">Offline Study Packs</h3>
                    <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Access material without internet</p>
                  </div>
                </div>
                <button 
                  onClick={() => {
                    setShowOfflinePacks(false);
                    setSelectedOfflinePack(null);
                  }}
                  className="text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                >
                  Close
                </button>
              </div>

              {selectedOfflinePack ? (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <button 
                      onClick={() => setSelectedOfflinePack(null)}
                      className="text-xs font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1 hover:underline"
                    >
                      ← Back to all packs
                    </button>
                    <button
                      onClick={() => downloadHtmlPack(selectedOfflinePack)}
                      className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      Save as HTML
                    </button>
                  </div>
                  
                  <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <h4 className="font-display text-2xl font-bold text-slate-900 dark:text-white mb-2">{selectedOfflinePack.topicName}</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 uppercase tracking-widest font-bold">{selectedOfflinePack.chapterName}</p>
                    
                    <div className="markdown-body text-slate-700 dark:text-slate-300 leading-relaxed mb-8">
                      <Markdown>{selectedOfflinePack.explanation}</Markdown>
                    </div>

                    <div className="space-y-4 pt-6 border-t border-slate-200 dark:border-slate-700">
                      <h5 className="font-display text-lg font-bold text-slate-900 dark:text-white">Q&A Section</h5>
                      {selectedOfflinePack.qa.map((item, idx) => (
                        <div key={idx} className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 shadow-sm">
                          <p className="font-bold text-slate-800 dark:text-slate-200 mb-2">Q: {item.question}</p>
                          <p className="text-sm text-slate-600 dark:text-slate-400">A: {item.answer}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {offlinePacks.length === 0 ? (
                    <div className="col-span-full py-12 text-center">
                      <CloudOff className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-4" />
                      <p className="text-slate-500 dark:text-slate-400 font-medium">No offline packs downloaded yet.</p>
                      <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Download topics while online to see them here.</p>
                    </div>
                  ) : (
                    offlinePacks.map((pack) => (
                      <button
                        key={pack.topicId}
                        onClick={() => setSelectedOfflinePack(pack)}
                        className="p-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 hover:bg-white dark:hover:bg-slate-800 hover:border-indigo-300 transition-all text-left group"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 transition-colors">{pack.topicName}</h4>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setOfflinePacks(prev => prev.filter(p => p.topicId !== pack.topicId));
                            }}
                            className="p-1 text-slate-300 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest font-bold">{pack.chapterName}</p>
                        <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-2">Downloaded: {new Date(pack.timestamp).toLocaleDateString()}</p>
                      </button>
                    ))
                  )}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      </div>

      <div className="absolute bottom-4 left-4 right-4 pointer-events-none z-10">
        <div className="max-w-md mx-auto bg-slate-900/80 backdrop-blur-sm rounded-2xl p-4 shadow-sm border border-slate-800 opacity-60">
          <p className="text-xs text-slate-500 text-center italic">
            "Education is the most powerful weapon which you can use to change the world."
          </p>
        </div>
      </div>
    </div>
  );
};
