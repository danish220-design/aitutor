import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Lock, Mail, UserPlus, LogIn, AlertCircle, Loader2, Settings, ExternalLink, CheckCircle2, XCircle } from 'lucide-react';
import { sheetsService } from '../services/sheetsService';

interface AdminAuthProps {
  onSuccess: () => void;
}

interface ConfigStatus {
  DATABASE_READY: boolean;
  JWT_SECRET: boolean;
}

export const AdminAuth: React.FC<AdminAuthProps> = ({ onSuccess }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [checkingAdmin, setCheckingAdmin] = useState(true);
  const [adminExists, setAdminExists] = useState(false);
  const [configStatus, setConfigStatus] = useState<ConfigStatus | null>(null);

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const configRes = await sheetsService.getConfigStatus();
        setConfigStatus(configRes);
        
        if (configRes.DATABASE_READY && configRes.JWT_SECRET) {
          const adminRes = await sheetsService.checkAdmin();
          setAdminExists(adminRes.exists);
          if (!adminRes.exists) {
            setIsRegistering(true);
          }
        } else {
          setIsRegistering(true);
        }
      } catch (err) {
        console.error("Error checking system status:", err);
      } finally {
        setCheckingAdmin(false);
      }
    };
    checkStatus();
  }, []);

  const isConfigComplete = configStatus?.DATABASE_READY;

  if (checkingAdmin) {
    return (
      <div className="flex flex-col items-center justify-center p-12">
        <Loader2 className="w-8 h-8 text-cyan-500 animate-spin mb-4" />
        <p className="text-slate-500 dark:text-slate-400 font-medium">Initializing database...</p>
      </div>
    );
  }

  const handleGoogleLogin = async () => {
    setError(null);
    setLoading(true);
    try {
      await sheetsService.loginWithGoogle(true);
      onSuccess();
    } catch (err: any) {
      console.error("Google Auth error:", err);
      let message = err.message || "An error occurred during Google authentication.";
      
      // Add helpful instructions for common errors
      if (message.includes("popup was closed")) {
        message = "Sign-in popup was blocked or closed. If you are using Safari or a strict browser, please open the app in a new tab to sign in.";
      } else if (message.includes("not authorized")) {
        message += `\n\nPlease add this URL to 'Authorized domains' in Firebase Console: ${window.location.origin}`;
      }
      
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (email !== 'danish220@gmail.com') {
        throw new Error("Unauthorized: Only danish220@gmail.com is allowed to access the Admin Control Center.");
      }
      if (isRegistering) {
        await sheetsService.adminSignup({ email, password, role: 'admin' });
        onSuccess();
      } else {
        await sheetsService.adminLogin({ email, password });
        onSuccess();
      }
    } catch (err: any) {
      console.error("Auth error:", err);
      setError(err.message || "An error occurred during authentication.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto p-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-cyan-100 dark:bg-cyan-900/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Lock className="w-8 h-8 text-cyan-600 dark:text-cyan-400" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
          {isRegistering ? 'Register Administrator' : 'Admin Login'}
        </h2>
        <p className="text-slate-500 dark:text-slate-400 mt-2">
          {isRegistering 
            ? 'Create the first administrator account to manage the platform.' 
            : 'Enter your credentials to access the dashboard.'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800 rounded-2xl flex flex-col gap-3 text-red-600 dark:text-red-400 text-sm">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <p>{error}</p>
            </div>
            {error.includes("new tab") && (
              <button
                type="button"
                onClick={() => window.open(window.location.href, '_blank')}
                className="ml-8 px-4 py-2 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 rounded-lg font-medium text-sm hover:bg-red-200 dark:hover:bg-red-900/60 transition-colors self-start"
              >
                Open in New Tab
              </button>
            )}
          </div>
        )}

        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="email" 
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@myaitutorials.com"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl pl-12 pr-5 py-4 outline-none focus:border-cyan-500 transition-colors"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Password</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl pl-12 pr-5 py-4 outline-none focus:border-cyan-500 transition-colors"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-4 rounded-2xl shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : isRegistering ? (
            <>
              <UserPlus className="w-5 h-5" />
              Register Admin
            </>
          ) : (
            <>
              <LogIn className="w-5 h-5" />
              Login to Dashboard
            </>
          )}
        </button>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-100 dark:border-slate-800"></div>
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-white dark:bg-slate-900 px-2 text-slate-400 font-bold tracking-widest">Or continue with</span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 disabled:opacity-50"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path
              fill="currentColor"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="currentColor"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="currentColor"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
            />
            <path
              fill="currentColor"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            />
          </svg>
          Sign in with Google
        </button>

        {!isRegistering && !adminExists && (
          <button
            type="button"
            onClick={() => setIsRegistering(true)}
            className="w-full py-2 text-sm text-cyan-600 dark:text-cyan-400 font-medium hover:underline"
          >
            No admin account? Register as first admin
          </button>
        )}
        
        {isRegistering && (
          <button
            type="button"
            onClick={() => setIsRegistering(false)}
            className="w-full py-2 text-sm text-cyan-600 dark:text-cyan-400 font-medium hover:underline"
          >
            {adminExists ? 'Already have an account? Login here' : 'Back to login'}
          </button>
        )}
      </form>
    </div>
  );
};
