export type Language = 'English' | 'Hinglish' | 'Bengali';
export type ClassLevel = '9' | '10' | '11' | '12';

export type AppView = 'landing' | 'setup' | 'tutor';

export interface Flashcard {
  id: string;
  term: string;
  definition: string;
  isLearned: boolean;
}

export interface DailyGoal {
  id: string;
  text: string;
  completed: boolean;
}

export interface OfflineStudyPack {
  topicId: string;
  topicName: string;
  chapterName: string;
  explanation: string;
  qa: { question: string; answer: string }[];
  timestamp: number;
}

export interface AppState {
  language: Language;
  classLevel: ClassLevel;
  stream?: string;
  subject?: string;
  chapterId?: string;
  topicId?: string;
  isStarted: boolean;
  view: AppView;
}

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}
